"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/backgroundRuntime/domains/tabWheelDomain.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/tabWheel.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());

  // src/lib/core/tabWheel/mouseGestureCore.ts
  var TABWHEEL_CLICK_ACTIONS = [
    "search",
    "nativeNewTab",
    "recentTab",
    "closeToRecent",
    "duplicateTab",
    "openSettings",
    "none"
  ];
  var DEFAULT_TABWHEEL_CLICK_ACTION_SETTINGS = {
    leftClickAction: "search",
    middleClickAction: "recentTab",
    rightClickAction: "closeToRecent"
  };
  var MOUSE_GESTURE_BUTTON_MECHANICS = [
    {
      button: 0,
      runPhase: "sessionStart",
      finishEvents: ["click"]
    },
    {
      button: 1,
      runPhase: "auxclick",
      finishEvents: ["auxclick"]
    },
    {
      button: 2,
      runPhase: "contextmenu",
      finishEvents: ["click", "auxclick", "contextmenu"]
    }
  ];
  function buildMouseGesturePolicies(clickActions) {
    const clickActionsByButton = [
      clickActions.leftClickAction,
      clickActions.middleClickAction,
      clickActions.rightClickAction
    ];
    return MOUSE_GESTURE_BUTTON_MECHANICS.flatMap((mechanics) => {
      const clickAction = clickActionsByButton[mechanics.button];
      if (clickAction === "none") return [];
      return [{ action: clickAction, ...mechanics }];
    });
  }
  var MOUSE_GESTURE_POLICIES = buildMouseGesturePolicies(DEFAULT_TABWHEEL_CLICK_ACTION_SETTINGS);

  // src/lib/common/contracts/tabWheel.ts
  var MAX_SCROLL_MEMORY_ENTRIES = 300;
  var MAX_MRU_TABS = 100;
  var TABWHEEL_STORAGE_KEYS = {
    settings: "tabWheelSettings",
    scrollMemory: "tabWheelScrollMemory",
    mruState: "tabWheelMruState"
  };
  var TABWHEEL_MODIFIER_KEYS = [
    "alt",
    "ctrl",
    "meta"
  ];
  var TABWHEEL_CYCLE_SCOPES = ["general", "mru"];
  var TABWHEEL_PRESETS = ["precise", "balanced", "fast", "custom"];
  var MIN_WHEEL_SENSITIVITY = 0.5;
  var MAX_WHEEL_SENSITIVITY = 2;
  var MIN_WHEEL_COOLDOWN_MS = 60;
  var MAX_WHEEL_COOLDOWN_MS = 400;
  var MIN_PAGE_SCROLL_SPEED_MULTIPLIER = 0.5;
  var MAX_PAGE_SCROLL_SPEED_MULTIPLIER = 3;
  var MIN_PAGE_SCROLL_VIEWPORT_CAP_RATIO = 0.1;
  var MAX_PAGE_SCROLL_VIEWPORT_CAP_RATIO = 1;
  var GOOGLE_SEARCH_URL_TEMPLATE = "https://www.google.com/search?q=%s";
  var MAX_SEARCH_QUERY_LENGTH = 512;
  var TABWHEEL_PRESET_VALUES = {
    precise: {
      wheelSensitivity: 0.8,
      wheelCooldownMs: 220,
      pageScrollSpeedMultiplier: 0.8,
      pageScrollViewportCapRatio: 0.35,
      wheelAcceleration: false,
      overshootGuard: true
    },
    balanced: {
      wheelSensitivity: 1,
      wheelCooldownMs: 160,
      pageScrollSpeedMultiplier: 1,
      pageScrollViewportCapRatio: 1,
      wheelAcceleration: false,
      overshootGuard: true
    },
    fast: {
      wheelSensitivity: 1.35,
      wheelCooldownMs: 90,
      pageScrollSpeedMultiplier: 1.4,
      pageScrollViewportCapRatio: 1,
      wheelAcceleration: true,
      overshootGuard: true
    }
  };
  var DEFAULT_TABWHEEL_SETTINGS = {
    invertScroll: false,
    gestureModifier: "alt",
    gestureWithShift: false,
    allowGesturesInEditableFields: true,
    ...DEFAULT_TABWHEEL_CLICK_ACTION_SETTINGS,
    cycleScope: "general",
    skipPinnedTabs: false,
    skipRestrictedPages: true,
    skipHiddenTabs: false,
    wrapAround: true,
    wheelPreset: "balanced",
    wheelSensitivity: 1,
    wheelCooldownMs: 160,
    pageScrollSpeedMultiplier: 1,
    pageScrollViewportCapRatio: 1,
    wheelAcceleration: false,
    horizontalWheel: true,
    overshootGuard: true
  };
  function normalizeModifierKey(value, fallback) {
    return TABWHEEL_MODIFIER_KEYS.includes(value) ? value : fallback;
  }
  function normalizeShiftRequirement(value) {
    return value === true;
  }
  function normalizeClickAction(value, fallback) {
    return TABWHEEL_CLICK_ACTIONS.includes(value) ? value : fallback;
  }
  function normalizeEnabledFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeNumberInRange(value, fallback, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.max(min, Math.min(max, numeric));
  }
  function normalizeSearchQuery(value) {
    if (typeof value !== "string") return "";
    return value.trim().replace(/\s+/g, " ").slice(0, MAX_SEARCH_QUERY_LENGTH);
  }
  function buildSearchUrl(query) {
    return GOOGLE_SEARCH_URL_TEMPLATE.replaceAll("%s", encodeURIComponent(normalizeSearchQuery(query)));
  }
  function normalizeTabWheelCycleScope(value) {
    return TABWHEEL_CYCLE_SCOPES.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.cycleScope;
  }
  function normalizeWheelPreset(value) {
    return TABWHEEL_PRESETS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.wheelPreset;
  }
  function detectTabWheelPreset(settings) {
    for (const preset of ["precise", "balanced", "fast"]) {
      const presetValues = TABWHEEL_PRESET_VALUES[preset];
      if (settings.wheelSensitivity === presetValues.wheelSensitivity && settings.wheelCooldownMs === presetValues.wheelCooldownMs && settings.pageScrollSpeedMultiplier === presetValues.pageScrollSpeedMultiplier && settings.pageScrollViewportCapRatio === presetValues.pageScrollViewportCapRatio && settings.wheelAcceleration === presetValues.wheelAcceleration && settings.overshootGuard === presetValues.overshootGuard) {
        return preset;
      }
    }
    return "custom";
  }
  function normalizeTabWheelSettings(value) {
    if (typeof value !== "object" || value === null) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
    const settings = value;
    const normalizedSettings = {
      invertScroll: settings.invertScroll === true,
      gestureModifier: normalizeModifierKey(
        settings.gestureModifier,
        DEFAULT_TABWHEEL_SETTINGS.gestureModifier
      ),
      gestureWithShift: normalizeShiftRequirement(settings.gestureWithShift),
      allowGesturesInEditableFields: normalizeEnabledFlag(
        settings.allowGesturesInEditableFields,
        DEFAULT_TABWHEEL_SETTINGS.allowGesturesInEditableFields
      ),
      leftClickAction: normalizeClickAction(
        settings.leftClickAction,
        value.openNativeNewTabOnLeftClick === true ? "nativeNewTab" : DEFAULT_TABWHEEL_SETTINGS.leftClickAction
      ),
      middleClickAction: normalizeClickAction(
        settings.middleClickAction,
        DEFAULT_TABWHEEL_SETTINGS.middleClickAction
      ),
      rightClickAction: normalizeClickAction(
        settings.rightClickAction,
        DEFAULT_TABWHEEL_SETTINGS.rightClickAction
      ),
      cycleScope: normalizeTabWheelCycleScope(settings.cycleScope),
      skipPinnedTabs: normalizeEnabledFlag(
        settings.skipPinnedTabs,
        DEFAULT_TABWHEEL_SETTINGS.skipPinnedTabs
      ),
      skipRestrictedPages: normalizeEnabledFlag(
        settings.skipRestrictedPages,
        DEFAULT_TABWHEEL_SETTINGS.skipRestrictedPages
      ),
      skipHiddenTabs: normalizeEnabledFlag(
        settings.skipHiddenTabs,
        DEFAULT_TABWHEEL_SETTINGS.skipHiddenTabs
      ),
      wrapAround: normalizeEnabledFlag(
        settings.wrapAround,
        DEFAULT_TABWHEEL_SETTINGS.wrapAround
      ),
      wheelPreset: normalizeWheelPreset(settings.wheelPreset),
      wheelSensitivity: normalizeNumberInRange(
        settings.wheelSensitivity,
        DEFAULT_TABWHEEL_SETTINGS.wheelSensitivity,
        MIN_WHEEL_SENSITIVITY,
        MAX_WHEEL_SENSITIVITY
      ),
      wheelCooldownMs: normalizeNumberInRange(
        settings.wheelCooldownMs,
        DEFAULT_TABWHEEL_SETTINGS.wheelCooldownMs,
        MIN_WHEEL_COOLDOWN_MS,
        MAX_WHEEL_COOLDOWN_MS
      ),
      pageScrollSpeedMultiplier: normalizeNumberInRange(
        settings.pageScrollSpeedMultiplier,
        DEFAULT_TABWHEEL_SETTINGS.pageScrollSpeedMultiplier,
        MIN_PAGE_SCROLL_SPEED_MULTIPLIER,
        MAX_PAGE_SCROLL_SPEED_MULTIPLIER
      ),
      pageScrollViewportCapRatio: normalizeNumberInRange(
        settings.pageScrollViewportCapRatio,
        DEFAULT_TABWHEEL_SETTINGS.pageScrollViewportCapRatio,
        MIN_PAGE_SCROLL_VIEWPORT_CAP_RATIO,
        MAX_PAGE_SCROLL_VIEWPORT_CAP_RATIO
      ),
      wheelAcceleration: normalizeEnabledFlag(
        settings.wheelAcceleration,
        DEFAULT_TABWHEEL_SETTINGS.wheelAcceleration
      ),
      horizontalWheel: normalizeEnabledFlag(
        settings.horizontalWheel,
        DEFAULT_TABWHEEL_SETTINGS.horizontalWheel
      ),
      overshootGuard: normalizeEnabledFlag(
        settings.overshootGuard,
        DEFAULT_TABWHEEL_SETTINGS.overshootGuard
      )
    };
    normalizedSettings.wheelPreset = settings.wheelPreset == null ? detectTabWheelPreset(normalizedSettings) : normalizedSettings.wheelPreset;
    return normalizedSettings;
  }
  async function loadTabWheelSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.settings);
      return normalizeTabWheelSettings(data[TABWHEEL_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
  }
  async function saveTabWheelSettings(settings) {
    await import_webextension_polyfill.default.storage.local.set({
      [TABWHEEL_STORAGE_KEYS.settings]: normalizeTabWheelSettings(settings)
    });
  }

  // src/lib/core/tabWheel/tabWheelCore.ts
  function resolveCycleTargetIndex(tabIndices, currentTabIndex, direction, wrapAround) {
    const candidates = tabIndices.slice().sort((left, right) => left - right);
    if (candidates.length === 0) return -1;
    if (candidates.length === 1) return candidates[0];
    if (direction === "next") {
      const nextIndex = candidates.find((index) => index > currentTabIndex);
      if (nextIndex != null) return nextIndex;
      return wrapAround ? candidates[0] : currentTabIndex;
    }
    for (let i = candidates.length - 1; i >= 0; i--) {
      if (candidates[i] < currentTabIndex) return candidates[i];
    }
    return wrapAround ? candidates[candidates.length - 1] : currentTabIndex;
  }

  // src/lib/common/utils/asyncFlow.ts
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function createInFlightMemo(task) {
    let inFlight = null;
    return () => {
      if (inFlight) return inFlight;
      inFlight = task().catch((error) => {
        inFlight = null;
        throw error;
      });
      return inFlight;
    };
  }
  function createWriteChain() {
    let chain = Promise.resolve();
    return {
      enqueue(task) {
        const scheduledWrite = chain.catch(() => {
        }).then(() => task());
        chain = scheduledWrite.catch(() => {
        });
        return scheduledWrite;
      }
    };
  }
  function createKeyedTaskQueue() {
    const tasksByKey = /* @__PURE__ */ new Map();
    return {
      run(key, task) {
        const previousTask = tasksByKey.get(key) ?? Promise.resolve();
        const result = previousTask.then(() => task());
        const settled = result.then(() => {
        }, () => {
        });
        tasksByKey.set(key, settled);
        void settled.then(() => {
          if (tasksByKey.get(key) === settled) {
            tasksByKey.delete(key);
          }
        });
        return result;
      }
    };
  }

  // src/lib/backgroundRuntime/domains/tabWheelDomain.ts
  var FALLBACK_CYCLE_LOCK_WINDOW_ID = 0;
  var MRU_CYCLE_SESSION_MS = 1400;
  var WINDOW_TABS_CACHE_TTL_MS = 350;
  var SCROLL_MEMORY_SAVE_DEBOUNCE_MS = 120;
  var GESTURE_TARGET_PROBE_TIMEOUT_MS = 320;
  var MAX_GESTURE_PROBE_ATTEMPTS = 4;
  var CONTENT_SCRIPT_UNAVAILABLE_CACHE_TTL_MS = 2500;
  var GESTURE_CONTENT_SCRIPT_READY_RETRY_DELAYS_MS = [0, 80, 180];
  var SCROLL_RESTORE_RETRY_DELAYS_MS = [0, 80, 220, 500, 900, 1500, 2400, 3600];
  var DISCARDED_SCROLL_RESTORE_RETRY_DELAYS_MS = [...SCROLL_RESTORE_RETRY_DELAYS_MS, 4e3];
  var DISCARDED_WAKE_CYCLE_HOLD_MS = 700;
  function windowKey(windowId) {
    return String(windowId);
  }
  function tabKey(tabId) {
    return String(tabId);
  }
  async function resolveWithTimeout(task, timeoutMs, fallback) {
    let timeoutId = null;
    const guardedTask = task.catch(() => fallback);
    const timeout = new Promise((resolve) => {
      timeoutId = setTimeout(() => resolve(fallback), timeoutMs);
    });
    try {
      return await Promise.race([guardedTask, timeout]);
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
    }
  }
  function normalizePageUrl(url) {
    if (!url) return null;
    try {
      const parsed = new URL(url);
      return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.href : null;
    } catch (_) {
      return null;
    }
  }
  var KNOWN_BROWSER_STORE_RESTRICTED_HOSTS = /* @__PURE__ */ new Set([
    "addons.mozilla.org",
    "chromewebstore.google.com"
  ]);
  function normalizeHostname(hostname) {
    return hostname.toLowerCase().replace(/^www\./, "");
  }
  function isKnownBrowserStoreRestrictedUrl(url) {
    if (!url) return false;
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return false;
      const hostname = normalizeHostname(parsed.hostname);
      if (KNOWN_BROWSER_STORE_RESTRICTED_HOSTS.has(hostname)) return true;
      return hostname === "chrome.google.com" && parsed.pathname.toLowerCase().startsWith("/webstore");
    } catch (_) {
      return false;
    }
  }
  function isPageGestureRestrictedUrl(url) {
    return !normalizePageUrl(url) || isKnownBrowserStoreRestrictedUrl(url);
  }
  function normalizeScroll(scrollX, scrollY) {
    return {
      scrollX: Math.max(0, Number(scrollX) || 0),
      scrollY: Math.max(0, Number(scrollY) || 0)
    };
  }
  function normalizeScrollRatio(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return 0;
    return Math.max(0, Math.min(1, numeric));
  }
  function normalizeScrollDimension(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return 0;
    return Math.max(0, numeric);
  }
  function normalizeScrollData(value) {
    const scroll = normalizeScroll(Number(value.scrollX), Number(value.scrollY));
    const scrollWidth = normalizeScrollDimension(value.scrollWidth);
    const scrollHeight = normalizeScrollDimension(value.scrollHeight);
    const viewportWidth = normalizeScrollDimension(value.viewportWidth);
    const viewportHeight = normalizeScrollDimension(value.viewportHeight);
    const maxScrollX = Math.max(0, scrollWidth - viewportWidth);
    const maxScrollY = Math.max(0, scrollHeight - viewportHeight);
    return {
      scrollX: scroll.scrollX,
      scrollY: scroll.scrollY,
      scrollRatioX: value.scrollRatioX == null ? maxScrollX > 0 ? Math.max(0, Math.min(1, scroll.scrollX / maxScrollX)) : 0 : normalizeScrollRatio(value.scrollRatioX),
      scrollRatioY: value.scrollRatioY == null ? maxScrollY > 0 ? Math.max(0, Math.min(1, scroll.scrollY / maxScrollY)) : 0 : normalizeScrollRatio(value.scrollRatioY),
      scrollWidth,
      scrollHeight,
      viewportWidth,
      viewportHeight
    };
  }
  function normalizeScrollMemoryEntry(rawEntry) {
    if (typeof rawEntry !== "object" || rawEntry === null) return null;
    const entry = rawEntry;
    const tabId = Number(entry.tabId);
    const windowId = Number(entry.windowId);
    const url = normalizePageUrl(entry.url);
    if (!Number.isInteger(tabId) || tabId <= 0) return null;
    if (!Number.isInteger(windowId) || windowId <= 0) return null;
    if (!url) return null;
    const scroll = normalizeScrollData(entry);
    return {
      tabId,
      windowId,
      url,
      scrollX: scroll.scrollX,
      scrollY: scroll.scrollY,
      scrollRatioX: scroll.scrollRatioX,
      scrollRatioY: scroll.scrollRatioY,
      scrollWidth: scroll.scrollWidth,
      scrollHeight: scroll.scrollHeight,
      viewportWidth: scroll.viewportWidth,
      viewportHeight: scroll.viewportHeight,
      updatedAt: Number.isFinite(Number(entry.updatedAt)) ? Number(entry.updatedAt) : Date.now()
    };
  }
  function normalizeScrollMemory(rawValue) {
    if (typeof rawValue !== "object" || rawValue === null || Array.isArray(rawValue)) return {};
    const normalized = {};
    for (const [key, rawEntry] of Object.entries(rawValue)) {
      const entry = normalizeScrollMemoryEntry(rawEntry);
      if (!entry || key !== tabKey(entry.tabId)) continue;
      normalized[key] = entry;
    }
    return normalized;
  }
  function trimScrollMemory(memory) {
    const entries = Object.values(memory).sort((left, right) => right.updatedAt - left.updatedAt).slice(0, MAX_SCROLL_MEMORY_ENTRIES);
    return Object.fromEntries(entries.map((entry) => [tabKey(entry.tabId), entry]));
  }
  function normalizeMruState(rawValue) {
    if (typeof rawValue !== "object" || rawValue === null || Array.isArray(rawValue)) return {};
    const normalized = {};
    for (const [key, rawTabIds] of Object.entries(rawValue)) {
      const windowId = Number(key);
      if (!Number.isInteger(windowId) || windowId <= 0 || !Array.isArray(rawTabIds)) continue;
      const seenTabIds = /* @__PURE__ */ new Set();
      const tabIds = rawTabIds.map((value) => Number(value)).filter((tabId) => {
        if (!Number.isInteger(tabId) || tabId <= 0 || seenTabIds.has(tabId)) return false;
        seenTabIds.add(tabId);
        return true;
      }).slice(0, MAX_MRU_TABS);
      if (tabIds.length > 0) normalized[key] = tabIds;
    }
    return normalized;
  }
  function buildScrollMemoryEntry(tabId, windowId, url, scroll) {
    return {
      tabId,
      windowId,
      url,
      scrollX: scroll.scrollX,
      scrollY: scroll.scrollY,
      scrollRatioX: scroll.scrollRatioX,
      scrollRatioY: scroll.scrollRatioY,
      scrollWidth: scroll.scrollWidth,
      scrollHeight: scroll.scrollHeight,
      viewportWidth: scroll.viewportWidth,
      viewportHeight: scroll.viewportHeight,
      updatedAt: Date.now()
    };
  }
  function getTabIndex(tab) {
    return Number(tab.index) || 0;
  }
  function isRestrictedTab(tab) {
    return isPageGestureRestrictedUrl(tab.url);
  }
  function getBrowserDefaultSearchApi() {
    const searchApi = import_webextension_polyfill2.default.search;
    return typeof searchApi?.query === "function" ? searchApi : null;
  }
  function isCollapsedGroupTab(tab, collapsedTabGroupIds) {
    return tab.groupId != null && collapsedTabGroupIds.has(tab.groupId);
  }
  function getEligibleTabs(tabs, settings, collapsedTabGroupIds = /* @__PURE__ */ new Set()) {
    return tabs.filter((tab) => tab.id != null && (!settings.skipPinnedTabs || tab.pinned !== true) && (!settings.skipHiddenTabs || tab.hidden !== true && !isCollapsedGroupTab(tab, collapsedTabGroupIds)) && (!settings.skipRestrictedPages || !isRestrictedTab(tab))).sort((left, right) => getTabIndex(left) - getTabIndex(right));
  }
  function hasSameNumberList(left, right) {
    return left.length === right.length && left.every((value, index) => value === right[index]);
  }
  function createTabWheelDomain() {
    let scrollMemoryByTabId = {};
    let mruTabIdsByWindowId = {};
    const windowTabsCacheByWindowId = /* @__PURE__ */ new Map();
    const collapsedTabGroupIdsCacheByWindowId = /* @__PURE__ */ new Map();
    const contentScriptReadyUrlsByTabId = /* @__PURE__ */ new Map();
    const windowGestureTaskQueue = createKeyedTaskQueue();
    const mruStateWriteChain = createWriteChain();
    const mruCycleSessionsByWindowId = /* @__PURE__ */ new Map();
    const activeTabIdsByWindowId = /* @__PURE__ */ new Map();
    const scrollRestoreTokensByTabId = /* @__PURE__ */ new Map();
    const contentScriptUnavailableUrlsByTabId = /* @__PURE__ */ new Map();
    const discardedWakeHoldByWindowId = /* @__PURE__ */ new Map();
    let scrollRestoreSerial = 0;
    let scrollMemorySaveTimer = null;
    let scrollMemorySaveResolvers = [];
    let scrollMemoryWriteChain = Promise.resolve();
    let settingsCache = null;
    const ensureLoaded = createInFlightMemo(async () => {
      const stored = await import_webextension_polyfill2.default.storage.local.get([
        TABWHEEL_STORAGE_KEYS.scrollMemory,
        TABWHEEL_STORAGE_KEYS.mruState
      ]);
      scrollMemoryByTabId = normalizeScrollMemory(
        stored[TABWHEEL_STORAGE_KEYS.scrollMemory]
      );
      mruTabIdsByWindowId = normalizeMruState(stored[TABWHEEL_STORAGE_KEYS.mruState]);
    });
    async function getSettings() {
      if (settingsCache) return settingsCache;
      settingsCache = await loadTabWheelSettings();
      return settingsCache;
    }
    function updateSettingsCache(value) {
      settingsCache = normalizeTabWheelSettings(value);
    }
    async function persistScrollMemory() {
      scrollMemoryByTabId = trimScrollMemory(scrollMemoryByTabId);
      await import_webextension_polyfill2.default.storage.local.set({
        [TABWHEEL_STORAGE_KEYS.scrollMemory]: scrollMemoryByTabId
      });
    }
    function flushScrollMemorySave() {
      if (scrollMemorySaveTimer) {
        clearTimeout(scrollMemorySaveTimer);
        scrollMemorySaveTimer = null;
      }
      const resolvers = scrollMemorySaveResolvers;
      scrollMemorySaveResolvers = [];
      if (resolvers.length === 0) return scrollMemoryWriteChain.catch(() => {
      });
      scrollMemoryWriteChain = scrollMemoryWriteChain.catch(() => {
      }).then(() => persistScrollMemory());
      scrollMemoryWriteChain.then(() => {
        for (const pending of resolvers) pending.resolve();
      }).catch((error) => {
        for (const pending of resolvers) pending.reject(error);
      });
      return scrollMemoryWriteChain;
    }
    function saveScrollMemory() {
      const pendingSave = new Promise((resolve, reject) => {
        scrollMemorySaveResolvers.push({ resolve, reject });
      });
      if (scrollMemorySaveTimer) clearTimeout(scrollMemorySaveTimer);
      scrollMemorySaveTimer = setTimeout(() => {
        scrollMemorySaveTimer = null;
        void flushScrollMemorySave().catch(() => {
        });
      }, SCROLL_MEMORY_SAVE_DEBOUNCE_MS);
      return pendingSave;
    }
    function saveMruState() {
      return mruStateWriteChain.enqueue(() => import_webextension_polyfill2.default.storage.local.set({
        [TABWHEEL_STORAGE_KEYS.mruState]: mruTabIdsByWindowId
      }));
    }
    function queryTabsSafe(queryInfo) {
      return import_webextension_polyfill2.default.tabs.query(queryInfo).catch(() => null);
    }
    async function queryActiveTab(windowId) {
      const [activeTab] = await queryTabsSafe(
        windowId != null ? { active: true, windowId } : { active: true, currentWindow: true }
      ) ?? [];
      return activeTab?.id != null && activeTab.windowId != null ? activeTab : null;
    }
    async function resolveActiveTab(tab, windowId) {
      const fallbackWindowId = windowId ?? tab?.windowId;
      if (tab?.id != null && tab.windowId != null) {
        try {
          const currentTab = await import_webextension_polyfill2.default.tabs.get(tab.id);
          if (currentTab?.id != null && currentTab.windowId != null && currentTab.active === true) {
            return currentTab;
          }
          return await queryActiveTab(currentTab?.windowId ?? fallbackWindowId);
        } catch (_) {
          return await queryActiveTab(fallbackWindowId);
        }
      }
      return await queryActiveTab(windowId);
    }
    async function resolveCurrentWindowId(windowId) {
      if (windowId != null) return windowId;
      const [activeTab] = await queryTabsSafe({ active: true, currentWindow: true }) ?? [];
      return activeTab?.windowId ?? null;
    }
    function invalidateWindowTabsCache(windowId) {
      if (windowId == null) {
        windowTabsCacheByWindowId.clear();
        collapsedTabGroupIdsCacheByWindowId.clear();
        return;
      }
      windowTabsCacheByWindowId.delete(windowId);
      collapsedTabGroupIdsCacheByWindowId.delete(windowId);
    }
    async function getWindowTabs(windowId) {
      const cached = windowTabsCacheByWindowId.get(windowId);
      if (cached && cached.expiresAt > Date.now()) return cached.tabs;
      const tabs = await queryTabsSafe({ windowId });
      if (!tabs) return [];
      windowTabsCacheByWindowId.set(windowId, {
        tabs,
        expiresAt: Date.now() + WINDOW_TABS_CACHE_TTL_MS
      });
      return tabs;
    }
    function markContentScriptAvailable(tab, url) {
      if (tab.id == null) return;
      contentScriptReadyUrlsByTabId.set(tab.id, url);
      contentScriptUnavailableUrlsByTabId.delete(tab.id);
    }
    function markContentScriptUnavailable(tab, ttlMs = CONTENT_SCRIPT_UNAVAILABLE_CACHE_TTL_MS) {
      if (tab.id == null) return;
      contentScriptReadyUrlsByTabId.delete(tab.id);
      const url = normalizePageUrl(tab.url);
      if (!url) return;
      contentScriptUnavailableUrlsByTabId.set(tab.id, {
        url,
        expiresAt: Date.now() + ttlMs
      });
    }
    function isContentScriptKnownUnavailable(tab) {
      if (tab.id == null) return false;
      const url = normalizePageUrl(tab.url);
      const entry = contentScriptUnavailableUrlsByTabId.get(tab.id);
      if (!url || !entry || entry.url !== url) return false;
      if (entry.expiresAt > Date.now()) return true;
      contentScriptUnavailableUrlsByTabId.delete(tab.id);
      return false;
    }
    async function getCollapsedTabGroupIds(windowId, tabs, settings) {
      if (!settings.skipHiddenTabs) return /* @__PURE__ */ new Set();
      if (!tabs.some((tab) => tab.groupId != null && tab.groupId !== -1)) return /* @__PURE__ */ new Set();
      const cached = collapsedTabGroupIdsCacheByWindowId.get(windowId);
      if (cached && cached.expiresAt > Date.now()) return cached.collapsedTabGroupIds;
      const tabGroupsApi = import_webextension_polyfill2.default.tabGroups;
      if (typeof tabGroupsApi?.query !== "function") return /* @__PURE__ */ new Set();
      const collapsedGroups = await tabGroupsApi.query({ windowId, collapsed: true }).catch(() => []);
      const collapsedTabGroupIds = new Set(
        collapsedGroups.filter((group) => group.collapsed === true && Number.isInteger(group.id)).map((group) => group.id)
      );
      collapsedTabGroupIdsCacheByWindowId.set(windowId, {
        collapsedTabGroupIds,
        expiresAt: Date.now() + WINDOW_TABS_CACHE_TTL_MS
      });
      return collapsedTabGroupIds;
    }
    async function getGestureEligibleTabs(tabs, settings, windowId) {
      const collapsedTabGroupIds = await getCollapsedTabGroupIds(windowId, tabs, settings);
      const eligibleTabs = getEligibleTabs(tabs, settings, collapsedTabGroupIds);
      return settings.skipRestrictedPages ? eligibleTabs.filter((tab) => !isContentScriptKnownUnavailable(tab)) : eligibleTabs;
    }
    function beginScrollRestore(tabId) {
      const token = ++scrollRestoreSerial;
      scrollRestoreTokensByTabId.set(tabId, token);
      return token;
    }
    function cancelScrollRestore(tabId) {
      if (tabId == null) return;
      scrollRestoreTokensByTabId.set(tabId, ++scrollRestoreSerial);
    }
    function isScrollRestoreCurrent(tabId, token) {
      return scrollRestoreTokensByTabId.get(tabId) === token;
    }
    function getActiveDiscardedWakeHold(windowId, activeTabId) {
      const hold = discardedWakeHoldByWindowId.get(windowId);
      if (!hold) return null;
      if (hold.tabId !== activeTabId || hold.expiresAt <= Date.now()) {
        discardedWakeHoldByWindowId.delete(windowId);
        return null;
      }
      return hold;
    }
    function setDiscardedWakeHold(tab) {
      if (tab.id == null || tab.windowId == null || tab.discarded !== true) return;
      discardedWakeHoldByWindowId.set(tab.windowId, {
        tabId: tab.id,
        expiresAt: Date.now() + DISCARDED_WAKE_CYCLE_HOLD_MS
      });
    }
    function clearDiscardedWakeHoldForTab(tabId) {
      for (const [windowId, hold] of discardedWakeHoldByWindowId) {
        if (hold.tabId === tabId) discardedWakeHoldByWindowId.delete(windowId);
      }
    }
    async function reconcileMruWindow(windowId, tabs) {
      await ensureLoaded();
      const key = windowKey(windowId);
      const tabIds = new Set(tabs.map((tab) => tab.id).filter((tabId) => tabId != null));
      const current = mruTabIdsByWindowId[key] || [];
      const next = current.filter((tabId) => tabIds.has(tabId)).slice(0, MAX_MRU_TABS);
      if (hasSameNumberList(current, next)) return;
      if (next.length > 0) mruTabIdsByWindowId[key] = next;
      else delete mruTabIdsByWindowId[key];
      await saveMruState();
    }
    async function recordMruTab(tabId, windowId) {
      try {
        await ensureLoaded();
        if (!Number.isInteger(tabId) || tabId <= 0 || !Number.isInteger(windowId) || windowId <= 0) return;
        const key = windowKey(windowId);
        const current = mruTabIdsByWindowId[key] || [];
        const next = [tabId, ...current.filter((candidate) => candidate !== tabId)].slice(0, MAX_MRU_TABS);
        if (hasSameNumberList(current, next)) return;
        mruTabIdsByWindowId[key] = next;
        await saveMruState();
      } catch (error) {
        console.warn("[TabWheel] MRU recording failed:", error);
      }
    }
    function getMruOrderedTabs(windowId, eligibleTabs) {
      const eligibleById = /* @__PURE__ */ new Map();
      for (const tab of eligibleTabs) {
        if (tab.id != null) eligibleById.set(tab.id, tab);
      }
      const seenTabIds = /* @__PURE__ */ new Set();
      const ordered = [];
      for (const tabId of mruTabIdsByWindowId[windowKey(windowId)] || []) {
        const tab = eligibleById.get(tabId);
        if (!tab || seenTabIds.has(tabId)) continue;
        ordered.push(tab);
        seenTabIds.add(tabId);
      }
      for (const tab of eligibleTabs) {
        if (tab.id == null || seenTabIds.has(tab.id)) continue;
        ordered.push(tab);
        seenTabIds.add(tab.id);
      }
      return ordered;
    }
    function getTabIds(tabs) {
      return tabs.map((tab) => tab.id).filter((tabId) => tabId != null);
    }
    function hasSameNumberSet(left, right) {
      if (left.length !== right.length) return false;
      const rightValues = new Set(right);
      return left.every((value) => rightValues.has(value));
    }
    function resolveMruCycleSessionTabs(windowId, eligibleTabs) {
      const now = Date.now();
      const eligibleById = /* @__PURE__ */ new Map();
      for (const tab of eligibleTabs) {
        if (tab.id != null) eligibleById.set(tab.id, tab);
      }
      const eligibleTabIds = Array.from(eligibleById.keys());
      const existingSession = mruCycleSessionsByWindowId.get(windowId);
      if (existingSession && existingSession.expiresAt > now && hasSameNumberSet(existingSession.tabIds, eligibleTabIds)) {
        existingSession.expiresAt = now + MRU_CYCLE_SESSION_MS;
        return existingSession.tabIds.map((tabId) => eligibleById.get(tabId)).filter((tab) => tab != null);
      }
      const orderedTabs = getMruOrderedTabs(windowId, eligibleTabs);
      mruCycleSessionsByWindowId.set(windowId, {
        tabIds: getTabIds(orderedTabs),
        expiresAt: now + MRU_CYCLE_SESSION_MS
      });
      return orderedTabs;
    }
    function getCycleTabs(windowId, eligibleTabs, settings) {
      return settings.cycleScope === "mru" ? getMruOrderedTabs(windowId, eligibleTabs) : eligibleTabs;
    }
    async function saveCycleScope(cycleScope) {
      const settings = await getSettings();
      const nextSettings = { ...settings, cycleScope };
      await saveTabWheelSettings(nextSettings);
      settingsCache = nextSettings;
      return nextSettings;
    }
    async function sendStatus(tabId, message) {
      if (tabId == null) return;
      try {
        await import_webextension_polyfill2.default.tabs.sendMessage(tabId, { type: "TABWHEEL_STATUS", message });
      } catch (_) {
      }
    }
    async function executeContentScriptInTab(tabId, allFrames) {
      const runtimeBrowser = import_webextension_polyfill2.default;
      try {
        if (runtimeBrowser.scripting?.executeScript) {
          await runtimeBrowser.scripting.executeScript({
            target: { tabId, ...allFrames ? { allFrames: true } : {} },
            files: ["contentScript.js"]
          });
          return true;
        }
        if (runtimeBrowser.tabs.executeScript) {
          await runtimeBrowser.tabs.executeScript(tabId, {
            file: "contentScript.js",
            runAt: "document_start",
            ...allFrames ? { allFrames: true } : {}
          });
          return true;
        }
      } catch (_) {
        return false;
      }
      return false;
    }
    async function injectContentScriptIntoTab(tab) {
      if (tab.id == null || tab.discarded === true || isPageGestureRestrictedUrl(tab.url)) return "skipped";
      if (await executeContentScriptInTab(tab.id, true)) return "injected";
      return await executeContentScriptInTab(tab.id, false) ? "injected" : "failed";
    }
    async function activateExistingContentScripts() {
      const result = {
        attempted: 0,
        injected: 0,
        skipped: 0,
        failed: 0
      };
      const tabs = await import_webextension_polyfill2.default.tabs.query({});
      await Promise.all(tabs.map(async (tab) => {
        const activation = await injectContentScriptIntoTab(tab);
        if (activation === "skipped") {
          result.skipped += 1;
          return;
        }
        result.attempted += 1;
        if (activation === "injected") result.injected += 1;
        else result.failed += 1;
      }));
      return result;
    }
    async function ensureActiveTabContentScripts() {
      const windows = await import_webextension_polyfill2.default.windows.getAll().catch(() => []);
      await Promise.all(windows.map(async (win) => {
        if (win.id == null) return;
        const [activeTab] = await import_webextension_polyfill2.default.tabs.query({ active: true, windowId: win.id }).catch(() => []);
        if (!activeTab || activeTab.id == null) return;
        if (isPageGestureRestrictedUrl(activeTab.url) || activeTab.discarded === true) return;
        if (contentScriptReadyUrlsByTabId.get(activeTab.id) === normalizePageUrl(activeTab.url)) return;
        if (await pingContentScript(activeTab)) return;
        const injection = await injectContentScriptIntoTab(activeTab);
        if (injection !== "injected") return;
        await waitForContentScriptReady(activeTab, GESTURE_CONTENT_SCRIPT_READY_RETRY_DELAYS_MS);
      }));
    }
    async function ensureContentScriptForActiveTab(tabId) {
      const tab = await import_webextension_polyfill2.default.tabs.get(tabId).catch(() => null);
      if (!tab || tab.id == null) return;
      if (isPageGestureRestrictedUrl(tab.url) || tab.discarded === true) return;
      if (contentScriptReadyUrlsByTabId.get(tab.id) === normalizePageUrl(tab.url)) return;
      if (await pingContentScript(tab)) return;
      const injection = await injectContentScriptIntoTab(tab);
      if (injection !== "injected") return;
      await resolveWithTimeout(
        waitForContentScriptReady(tab, GESTURE_CONTENT_SCRIPT_READY_RETRY_DELAYS_MS),
        GESTURE_TARGET_PROBE_TIMEOUT_MS,
        false
      ).catch(() => {
      });
    }
    async function pingContentScript(tab) {
      if (tab.id == null) return false;
      const url = normalizePageUrl(tab.url);
      if (!url) return false;
      try {
        await import_webextension_polyfill2.default.tabs.sendMessage(tab.id, { type: "TABWHEEL_PING" });
        markContentScriptAvailable(tab, url);
        return true;
      } catch (_) {
        contentScriptReadyUrlsByTabId.delete(tab.id);
        return false;
      }
    }
    async function waitForContentScriptReady(tab, retryDelaysMs = [0, 90, 240, 450, 800]) {
      for (const delay of retryDelaysMs) {
        if (delay > 0) await sleep(delay);
        if (await pingContentScript(tab)) return true;
      }
      return false;
    }
    async function getScroll(tabId) {
      try {
        return await import_webextension_polyfill2.default.tabs.sendMessage(tabId, { type: "GET_SCROLL" });
      } catch (_) {
        return null;
      }
    }
    async function dismissTabWheelPanelById(tabId) {
      try {
        await import_webextension_polyfill2.default.tabs.sendMessage(tabId, { type: "TABWHEEL_DISMISS_PANEL" });
      } catch (_) {
      }
    }
    async function dismissTabWheelPanel(tab) {
      if (tab.id == null) return;
      await dismissTabWheelPanelById(tab.id);
    }
    async function resolveContentScriptStatus(tab) {
      if (!tab?.id) return "unavailable";
      if (isPageGestureRestrictedUrl(tab.url)) return "unavailable";
      if (isContentScriptKnownUnavailable(tab)) return "unavailable";
      const url = normalizePageUrl(tab.url);
      if (!url) return "unavailable";
      if (contentScriptReadyUrlsByTabId.get(tab.id) === url) return "ready";
      return await pingContentScript(tab) ? "ready" : "unavailable";
    }
    function markContentScriptReady(tab) {
      if (!tab?.id) return { ok: false, reason: "No sender tab" };
      if (isPageGestureRestrictedUrl(tab.url)) return { ok: false, reason: "Unsupported page" };
      const url = normalizePageUrl(tab.url);
      if (!url) return { ok: false, reason: "Unsupported page" };
      markContentScriptAvailable(tab, url);
      if (tab.active === true && tab.windowId != null) {
        activeTabIdsByWindowId.set(tab.windowId, tab.id);
        void recordMruTab(tab.id, tab.windowId);
      }
      return { ok: true };
    }
    async function ensurePageGestureAvailable(tab) {
      if (tab.id == null) return false;
      const tabId = tab.id;
      if (isPageGestureRestrictedUrl(tab.url)) {
        markContentScriptUnavailable(tab);
        return false;
      }
      const url = normalizePageUrl(tab.url);
      if (!url) return false;
      if (contentScriptReadyUrlsByTabId.get(tab.id) === url) {
        contentScriptUnavailableUrlsByTabId.delete(tab.id);
        return true;
      }
      const didBecomeReady = await resolveWithTimeout(
        (async () => {
          if (await pingContentScript(tab)) return true;
          const injection = await injectContentScriptIntoTab(tab);
          if (injection !== "injected") return false;
          const currentTab = await import_webextension_polyfill2.default.tabs.get(tabId).catch(() => tab);
          return await waitForContentScriptReady(currentTab, GESTURE_CONTENT_SCRIPT_READY_RETRY_DELAYS_MS);
        })(),
        GESTURE_TARGET_PROBE_TIMEOUT_MS,
        false
      );
      if (didBecomeReady) return true;
      markContentScriptUnavailable(tab);
      return false;
    }
    async function restoreScroll(tab) {
      if (tab.id == null) return false;
      const retryDelaysMs = tab.discarded === true ? DISCARDED_SCROLL_RESTORE_RETRY_DELAYS_MS : SCROLL_RESTORE_RETRY_DELAYS_MS;
      const restoreToken = beginScrollRestore(tab.id);
      const entry = scrollMemoryByTabId[tabKey(tab.id)];
      const currentUrl = normalizePageUrl(tab.url);
      if (!currentUrl || entry?.url !== currentUrl) return false;
      if (!entry) return false;
      for (const delay of retryDelaysMs) {
        if (!isScrollRestoreCurrent(tab.id, restoreToken)) return false;
        if (delay > 0) await sleep(delay);
        if (!isScrollRestoreCurrent(tab.id, restoreToken)) return false;
        try {
          await import_webextension_polyfill2.default.tabs.sendMessage(tab.id, {
            type: "SET_SCROLL",
            scrollX: entry.scrollX,
            scrollY: entry.scrollY,
            scrollRatioX: entry.scrollRatioX,
            scrollRatioY: entry.scrollRatioY,
            scrollWidth: entry.scrollWidth,
            scrollHeight: entry.scrollHeight,
            viewportWidth: entry.viewportWidth,
            viewportHeight: entry.viewportHeight
          });
          return true;
        } catch (_) {
        }
      }
      return false;
    }
    async function captureTabScroll(tab) {
      if (tab.id == null || tab.windowId == null) return;
      const url = normalizePageUrl(tab.url);
      if (!url) return;
      const scroll = await getScroll(tab.id);
      if (!scroll) return;
      const normalized = normalizeScrollData(scroll);
      scrollMemoryByTabId[tabKey(tab.id)] = buildScrollMemoryEntry(tab.id, tab.windowId, url, normalized);
      await saveScrollMemory();
    }
    function captureTabScrollUnlessWaking(tab) {
      if (tab.id == null || tab.windowId == null) return;
      if (getActiveDiscardedWakeHold(tab.windowId, tab.id)) return;
      void captureTabScroll(tab).catch(() => {
      });
    }
    async function getOverview(tab, windowId) {
      await ensureLoaded();
      const settings = await getSettings();
      const resolvedWindowId = await resolveCurrentWindowId(windowId ?? tab?.windowId);
      if (resolvedWindowId == null) {
        return {
          activeIndex: 0,
          tabCount: 0,
          cycleScope: settings.cycleScope,
          contentScriptStatus: "unavailable"
        };
      }
      const activeTab = await resolveActiveTab(tab, resolvedWindowId);
      const tabs = await getWindowTabs(resolvedWindowId);
      await reconcileMruWindow(resolvedWindowId, tabs);
      const eligibleTabs = await getGestureEligibleTabs(tabs, settings, resolvedWindowId);
      const scopeTabs = getCycleTabs(resolvedWindowId, eligibleTabs, settings);
      const activeIndex = activeTab ? scopeTabs.findIndex((candidate) => candidate.id === activeTab.id) : -1;
      const contentScriptStatus = await resolveContentScriptStatus(activeTab);
      return {
        activeIndex: activeIndex >= 0 ? activeIndex : 0,
        ...activeTab?.id != null ? { activeTabId: activeTab.id } : {},
        tabCount: scopeTabs.length,
        cycleScope: settings.cycleScope,
        contentScriptStatus
      };
    }
    function resolveStripTargetTab(activeTab, candidateTabs, direction, wrapAround) {
      const targetIndex = resolveCycleTargetIndex(
        candidateTabs.map(getTabIndex),
        getTabIndex(activeTab),
        direction,
        wrapAround
      );
      return candidateTabs.find((tab) => getTabIndex(tab) === targetIndex) || null;
    }
    function resolveMruCycleTargetTab(activeTab, candidateTabs, direction, wrapAround) {
      if (candidateTabs.length === 0) return null;
      const activePosition = candidateTabs.findIndex((candidate) => candidate.id === activeTab.id);
      if (activePosition < 0) return candidateTabs[0] || null;
      if (direction === "next") {
        const nextPosition = activePosition + 1;
        if (nextPosition < candidateTabs.length) return candidateTabs[nextPosition];
        return wrapAround ? candidateTabs[0] : activeTab;
      }
      const previousPosition = activePosition - 1;
      if (previousPosition >= 0) return candidateTabs[previousPosition];
      return wrapAround ? candidateTabs[candidateTabs.length - 1] : activeTab;
    }
    function resolveMostRecentTab(activeTab, windowId, eligibleTabs) {
      const eligibleById = /* @__PURE__ */ new Map();
      for (const tab of eligibleTabs) {
        if (tab.id != null) eligibleById.set(tab.id, tab);
      }
      for (const tabId of mruTabIdsByWindowId[windowKey(windowId)] || []) {
        if (tabId === activeTab.id) continue;
        const tab = eligibleById.get(tabId);
        if (tab) return tab;
      }
      return resolveStripTargetTab(activeTab, eligibleTabs, "prev", true);
    }
    function resolveCycleTargetTab(activeTab, candidateTabs, direction, settings) {
      return settings.cycleScope === "mru" ? resolveMruCycleTargetTab(activeTab, candidateTabs, direction, settings.wrapAround) : resolveStripTargetTab(activeTab, candidateTabs, direction, settings.wrapAround);
    }
    async function resolveAvailableCycleTargetTab(activeTab, candidateTabs, direction, settings) {
      let remainingTabs = candidateTabs;
      const maxAttempts = Math.min(candidateTabs.length, MAX_GESTURE_PROBE_ATTEMPTS);
      for (let attempts = 0; attempts < maxAttempts; attempts += 1) {
        const targetTab = resolveCycleTargetTab(activeTab, remainingTabs, direction, settings);
        if (!targetTab?.id || targetTab.id === activeTab.id) return null;
        if (!settings.skipRestrictedPages || await ensurePageGestureAvailable(targetTab)) return targetTab;
        remainingTabs = remainingTabs.filter((candidate) => candidate.id !== targetTab.id);
      }
      return null;
    }
    async function resolveMostRecentAvailableTab(activeTab, windowId, eligibleTabs, settings) {
      let remainingTabs = eligibleTabs;
      const maxAttempts = Math.min(eligibleTabs.length, MAX_GESTURE_PROBE_ATTEMPTS);
      for (let attempts = 0; attempts < maxAttempts; attempts += 1) {
        const targetTab = resolveMostRecentTab(activeTab, windowId, remainingTabs);
        if (!targetTab?.id) return null;
        if (!settings.skipRestrictedPages || await ensurePageGestureAvailable(targetTab)) return targetTab;
        remainingTabs = remainingTabs.filter((candidate) => candidate.id !== targetTab.id);
      }
      return null;
    }
    async function activateTab(targetTab, options = {}) {
      if (targetTab.id == null) return false;
      const didActivate = await import_webextension_polyfill2.default.tabs.update(targetTab.id, { active: true }).then(() => true).catch(() => false);
      if (!didActivate) return false;
      setDiscardedWakeHold(targetTab);
      if (targetTab.windowId != null) {
        await recordMruTab(targetTab.id, targetTab.windowId);
      }
      if (options.restoreScrollAsync === true) {
        void restoreScroll(targetTab).catch(() => {
        });
        return true;
      }
      await restoreScroll(targetTab);
      return true;
    }
    function runSerializedWindowTask(tab, windowId, task) {
      return windowGestureTaskQueue.run(
        windowId ?? tab?.windowId ?? FALLBACK_CYCLE_LOCK_WINDOW_ID,
        task
      );
    }
    async function cycleUnlocked(direction, tab) {
      await ensureLoaded();
      const activeTab = await resolveActiveTab(tab);
      if (!activeTab?.id || activeTab.windowId == null) {
        return { ok: false, reason: "No active tab" };
      }
      const settings = await getSettings();
      const tabs = await getWindowTabs(activeTab.windowId);
      await reconcileMruWindow(activeTab.windowId, tabs);
      const eligibleTabs = await getGestureEligibleTabs(tabs, settings, activeTab.windowId);
      if (eligibleTabs.length === 0) return { ok: false, reason: "No eligible tabs" };
      const candidateTabs = settings.cycleScope === "mru" ? resolveMruCycleSessionTabs(activeTab.windowId, eligibleTabs) : eligibleTabs;
      const targetTab = await resolveAvailableCycleTargetTab(activeTab, candidateTabs, direction, settings);
      if (!targetTab?.id) {
        return { ok: false, reason: "Edge of tab list" };
      }
      cancelScrollRestore(activeTab.id);
      captureTabScrollUnlessWaking(activeTab);
      await dismissTabWheelPanel(activeTab);
      const didActivate = await activateTab(targetTab, { restoreScrollAsync: true });
      if (!didActivate) return { ok: false, reason: "Tab no longer exists" };
      return { ok: true, tabId: targetTab.id };
    }
    async function cycle(direction, tab) {
      return await runSerializedWindowTask(tab, void 0, () => cycleUnlocked(direction, tab));
    }
    async function refreshCurrentTab(tab, windowId) {
      await ensureLoaded();
      const activeTab = await resolveActiveTab(tab, windowId);
      if (!activeTab?.id || activeTab.windowId == null) {
        return {
          ok: false,
          reason: "No active tab",
          contentScriptStatus: "unavailable"
        };
      }
      if (isPageGestureRestrictedUrl(activeTab.url)) {
        markContentScriptUnavailable(activeTab);
        return {
          ok: false,
          reason: "TabWheel cannot run on this page.",
          overview: await getOverview(activeTab, activeTab.windowId),
          contentScriptStatus: "unavailable"
        };
      }
      const wasReady = await pingContentScript(activeTab);
      const injection = await injectContentScriptIntoTab(activeTab);
      if (injection !== "injected") {
        const overview2 = await getOverview(activeTab, activeTab.windowId);
        if (wasReady || overview2.contentScriptStatus === "ready") {
          return {
            ok: true,
            overview: overview2,
            contentScriptStatus: overview2.contentScriptStatus,
            injected: false
          };
        }
        markContentScriptUnavailable(activeTab);
        return {
          ok: false,
          reason: "TabWheel cannot run on this page.",
          overview: overview2,
          contentScriptStatus: overview2.contentScriptStatus,
          injected: false
        };
      }
      const currentTab = await import_webextension_polyfill2.default.tabs.get(activeTab.id).catch(() => activeTab);
      const isReady = await waitForContentScriptReady(currentTab);
      const overview = await getOverview(currentTab, activeTab.windowId);
      if (!isReady || overview.contentScriptStatus !== "ready") {
        markContentScriptUnavailable(currentTab);
        return {
          ok: false,
          reason: "TabWheel refresh failed",
          overview,
          contentScriptStatus: overview.contentScriptStatus,
          injected: true
        };
      }
      return {
        ok: true,
        overview,
        contentScriptStatus: "ready",
        injected: true
      };
    }
    async function openSearchTab(query, tab, windowId) {
      const normalizedQuery = normalizeSearchQuery(query);
      if (!normalizedQuery) return { ok: false, reason: "Enter a search query" };
      return await runSerializedWindowTask(
        tab,
        windowId,
        async () => {
          await ensureLoaded();
          const activeTab = await resolveActiveTab(tab, windowId);
          const searchApi = getBrowserDefaultSearchApi();
          const createProperties = {
            active: true,
            url: searchApi ? "about:blank" : buildSearchUrl(normalizedQuery),
            ...activeTab?.windowId != null ? { windowId: activeTab.windowId } : {},
            ...activeTab?.index != null ? { index: activeTab.index + 1 } : {}
          };
          const createdTab = await import_webextension_polyfill2.default.tabs.create(createProperties).catch(() => null);
          if (!createdTab) return { ok: false, reason: "Search unavailable" };
          invalidateWindowTabsCache(createdTab.windowId);
          if (createdTab.id != null && searchApi) {
            const didUseBrowserDefaultSearch = await searchApi.query({ text: normalizedQuery, tabId: createdTab.id }).then(() => true).catch(() => false);
            if (!didUseBrowserDefaultSearch) {
              const didUseFallbackSearch = await import_webextension_polyfill2.default.tabs.update(createdTab.id, {
                url: buildSearchUrl(normalizedQuery)
              }).then(() => true).catch(() => false);
              if (!didUseFallbackSearch) {
                await import_webextension_polyfill2.default.tabs.remove(createdTab.id).catch(() => {
                });
                return { ok: false, reason: "Search unavailable" };
              }
            }
          }
          if (createdTab.id != null && createdTab.windowId != null) {
            await recordMruTab(createdTab.id, createdTab.windowId);
          }
          return { ok: true, tabId: createdTab.id };
        }
      );
    }
    async function openNativeNewTab(tab, windowId) {
      return await runSerializedWindowTask(
        tab,
        windowId,
        async () => {
          await ensureLoaded();
          const activeTab = await resolveActiveTab(tab, windowId);
          const createProperties = {
            active: true,
            ...activeTab?.windowId != null ? { windowId: activeTab.windowId } : {},
            ...activeTab?.index != null ? { index: activeTab.index + 1 } : {}
          };
          const fallbackCreateProperties = {
            active: true,
            ...activeTab?.windowId != null ? { windowId: activeTab.windowId } : {}
          };
          const createdTab = await import_webextension_polyfill2.default.tabs.create(createProperties).catch(() => import_webextension_polyfill2.default.tabs.create(fallbackCreateProperties)).catch(() => import_webextension_polyfill2.default.tabs.create({ active: true })).catch(() => import_webextension_polyfill2.default.tabs.create({ active: true, url: "about:blank" })).catch(() => null);
          if (!createdTab) return { ok: false, reason: "New tab unavailable" };
          invalidateWindowTabsCache(createdTab.windowId);
          if (createdTab.id != null && createdTab.windowId != null) {
            await recordMruTab(createdTab.id, createdTab.windowId);
          }
          return { ok: true, tabId: createdTab.id };
        }
      );
    }
    async function activateMostRecentTab(tab, windowId) {
      return await runSerializedWindowTask(
        tab,
        windowId,
        async () => {
          await ensureLoaded();
          const settings = await getSettings();
          const activeTab = await resolveActiveTab(tab, windowId);
          if (!activeTab?.id || activeTab.windowId == null) return { ok: false, reason: "No active tab" };
          const tabs = await getWindowTabs(activeTab.windowId);
          await reconcileMruWindow(activeTab.windowId, tabs);
          const eligibleTabs = (await getGestureEligibleTabs(tabs, settings, activeTab.windowId)).filter((candidate) => candidate.id !== activeTab.id);
          if (eligibleTabs.length === 0) return { ok: false, reason: "No recent tab" };
          const targetTab = await resolveMostRecentAvailableTab(activeTab, activeTab.windowId, eligibleTabs, settings);
          if (!targetTab?.id) return { ok: false, reason: "No recent tab" };
          cancelScrollRestore(activeTab.id);
          captureTabScrollUnlessWaking(activeTab);
          await dismissTabWheelPanel(activeTab);
          const didActivate = await activateTab(targetTab, { restoreScrollAsync: true });
          if (!didActivate) return { ok: false, reason: "No recent tab" };
          return { ok: true, tabId: targetTab.id };
        }
      );
    }
    async function closeCurrentTabAndActivateRecent(tab, windowId) {
      return await runSerializedWindowTask(
        tab,
        windowId,
        async () => {
          await ensureLoaded();
          const settings = await getSettings();
          const activeTab = await resolveActiveTab(tab, windowId);
          if (!activeTab?.id || activeTab.windowId == null) return { ok: false, reason: "No active tab" };
          const tabs = await getWindowTabs(activeTab.windowId);
          await reconcileMruWindow(activeTab.windowId, tabs);
          const eligibleTabs = (await getGestureEligibleTabs(tabs, settings, activeTab.windowId)).filter((candidate) => candidate.id !== activeTab.id);
          const targetTab = eligibleTabs.length > 0 ? await resolveMostRecentAvailableTab(activeTab, activeTab.windowId, eligibleTabs, settings) : null;
          cancelScrollRestore(activeTab.id);
          await dismissTabWheelPanel(activeTab);
          if (targetTab?.id) {
            const didActivate = await activateTab(targetTab, { restoreScrollAsync: true });
            if (!didActivate) return { ok: false, reason: "No recent tab" };
          }
          const didClose = await import_webextension_polyfill2.default.tabs.remove(activeTab.id).then(() => true).catch(() => false);
          invalidateWindowTabsCache(activeTab.windowId);
          if (!didClose) return { ok: false, reason: "Close tab failed" };
          return { ok: true, tabId: targetTab?.id };
        }
      );
    }
    async function duplicateTab(tab, windowId) {
      return await runSerializedWindowTask(
        tab,
        windowId,
        async () => {
          await ensureLoaded();
          const activeTab = await resolveActiveTab(tab, windowId);
          if (!activeTab?.id) return { ok: false, reason: "No active tab" };
          const duplicatedTab = await import_webextension_polyfill2.default.tabs.duplicate(activeTab.id).catch(() => null);
          if (!duplicatedTab) return { ok: false, reason: "Duplicate unavailable" };
          invalidateWindowTabsCache(duplicatedTab.windowId ?? activeTab.windowId);
          if (duplicatedTab.id != null && duplicatedTab.windowId != null) {
            await recordMruTab(duplicatedTab.id, duplicatedTab.windowId);
          }
          return { ok: true, tabId: duplicatedTab.id };
        }
      );
    }
    async function setCycleScope(cycleScope, tab, windowId, options = {}) {
      await ensureLoaded();
      const resolvedWindowId = await resolveCurrentWindowId(windowId ?? tab?.windowId);
      if (resolvedWindowId == null) return { ok: false, reason: "No current window" };
      const nextSettings = await saveCycleScope(cycleScope);
      const activeTab = await resolveActiveTab(tab, resolvedWindowId);
      if (options.suppressPageStatus !== true) {
        await sendStatus(activeTab?.id, cycleScope === "mru" ? "MRU scrolling" : "General scrolling");
      }
      return { ok: true, cycleScope: nextSettings.cycleScope };
    }
    async function toggleCycleScope(tab, windowId) {
      const settings = await getSettings();
      return await setCycleScope(settings.cycleScope === "mru" ? "general" : "mru", tab, windowId);
    }
    async function saveScrollPosition(tabId, windowId, rawUrl, scrollData) {
      await ensureLoaded();
      const url = normalizePageUrl(rawUrl);
      if (!url) return { ok: false, reason: "Unsupported page" };
      const scroll = normalizeScrollData(scrollData);
      const key = tabKey(tabId);
      const existing = scrollMemoryByTabId[key];
      if (existing?.url === url && existing.scrollX === scroll.scrollX && existing.scrollY === scroll.scrollY && existing.scrollRatioX === scroll.scrollRatioX && existing.scrollRatioY === scroll.scrollRatioY && existing.scrollWidth === scroll.scrollWidth && existing.scrollHeight === scroll.scrollHeight && existing.viewportWidth === scroll.viewportWidth && existing.viewportHeight === scroll.viewportHeight) {
        return { ok: true };
      }
      scrollMemoryByTabId[key] = buildScrollMemoryEntry(tabId, windowId, url, scroll);
      await saveScrollMemory();
      return { ok: true };
    }
    function registerLifecycleListeners() {
      import_webextension_polyfill2.default.runtime.onInstalled.addListener((details) => {
        if (details.reason !== "install" && details.reason !== "update") return;
        void activateExistingContentScripts().then(ensureActiveTabContentScripts).catch((error) => {
          console.warn("[TabWheel] install-time content script activation failed:", error);
        });
      });
      import_webextension_polyfill2.default.storage.onChanged.addListener((changes, areaName) => {
        if (areaName !== "local") return;
        const settingsChange = changes[TABWHEEL_STORAGE_KEYS.settings];
        if (settingsChange) updateSettingsCache(settingsChange.newValue);
      });
      import_webextension_polyfill2.default.tabs.onCreated.addListener((createdTab) => {
        invalidateWindowTabsCache(createdTab.windowId);
      });
      import_webextension_polyfill2.default.tabs.onActivated.addListener((activeInfo) => {
        const previousTabId = activeTabIdsByWindowId.get(activeInfo.windowId);
        activeTabIdsByWindowId.set(activeInfo.windowId, activeInfo.tabId);
        const wakeHold = discardedWakeHoldByWindowId.get(activeInfo.windowId);
        if (wakeHold && wakeHold.tabId !== activeInfo.tabId) discardedWakeHoldByWindowId.delete(activeInfo.windowId);
        if (previousTabId != null && previousTabId !== activeInfo.tabId) {
          cancelScrollRestore(previousTabId);
          void dismissTabWheelPanelById(previousTabId).catch(() => {
          });
        }
        void recordMruTab(activeInfo.tabId, activeInfo.windowId);
        void ensureContentScriptForActiveTab(activeInfo.tabId).catch(() => {
        });
      });
      import_webextension_polyfill2.default.tabs.onMoved.addListener((_tabId, moveInfo) => {
        invalidateWindowTabsCache(moveInfo.windowId);
      });
      import_webextension_polyfill2.default.tabs.onAttached.addListener((_tabId, attachInfo) => {
        invalidateWindowTabsCache(attachInfo.newWindowId);
      });
      import_webextension_polyfill2.default.tabs.onDetached.addListener((_tabId, detachInfo) => {
        invalidateWindowTabsCache(detachInfo.oldWindowId);
      });
      import_webextension_polyfill2.default.tabs.onRemoved.addListener(async (tabId, removeInfo) => {
        invalidateWindowTabsCache(removeInfo?.windowId);
        await ensureLoaded();
        delete scrollMemoryByTabId[tabKey(tabId)];
        contentScriptReadyUrlsByTabId.delete(tabId);
        contentScriptUnavailableUrlsByTabId.delete(tabId);
        scrollRestoreTokensByTabId.delete(tabId);
        clearDiscardedWakeHoldForTab(tabId);
        for (const [windowId, activeTabId] of activeTabIdsByWindowId) {
          if (activeTabId === tabId) activeTabIdsByWindowId.delete(windowId);
        }
        for (const [windowId, session] of mruCycleSessionsByWindowId) {
          if (session.tabIds.includes(tabId)) mruCycleSessionsByWindowId.delete(windowId);
        }
        let mruChanged = false;
        for (const [key, tabIds] of Object.entries(mruTabIdsByWindowId)) {
          const nextTabIds = tabIds.filter((candidate) => candidate !== tabId);
          if (nextTabIds.length === tabIds.length) continue;
          mruChanged = true;
          if (nextTabIds.length > 0) mruTabIdsByWindowId[key] = nextTabIds;
          else delete mruTabIdsByWindowId[key];
        }
        if (mruChanged) await saveMruState();
        await saveScrollMemory();
      });
      import_webextension_polyfill2.default.tabs.onUpdated.addListener((tabId, changeInfo, updatedTab) => {
        if (changeInfo.url || changeInfo.pinned != null || changeInfo.groupId != null) {
          invalidateWindowTabsCache(updatedTab?.windowId);
        }
        if (changeInfo.status === "complete") {
          clearDiscardedWakeHoldForTab(tabId);
        }
        if (changeInfo.url) {
          contentScriptReadyUrlsByTabId.delete(tabId);
          contentScriptUnavailableUrlsByTabId.delete(tabId);
          cancelScrollRestore(tabId);
        }
      });
      import_webextension_polyfill2.default.windows.onRemoved.addListener((windowId) => {
        void (async () => {
          await ensureLoaded();
          invalidateWindowTabsCache(windowId);
          delete mruTabIdsByWindowId[windowKey(windowId)];
          mruCycleSessionsByWindowId.delete(windowId);
          activeTabIdsByWindowId.delete(windowId);
          discardedWakeHoldByWindowId.delete(windowId);
          for (const [key, entry] of Object.entries(scrollMemoryByTabId)) {
            if (entry.windowId === windowId) {
              delete scrollMemoryByTabId[key];
              scrollRestoreTokensByTabId.delete(entry.tabId);
            }
          }
          await saveMruState();
          await saveScrollMemory();
        })();
      });
      import_webextension_polyfill2.default.runtime.onStartup.addListener(async () => {
        await ensureLoaded();
        scrollMemoryByTabId = trimScrollMemory(scrollMemoryByTabId);
        mruTabIdsByWindowId = {};
        windowTabsCacheByWindowId.clear();
        collapsedTabGroupIdsCacheByWindowId.clear();
        mruCycleSessionsByWindowId.clear();
        contentScriptReadyUrlsByTabId.clear();
        contentScriptUnavailableUrlsByTabId.clear();
        scrollRestoreTokensByTabId.clear();
        activeTabIdsByWindowId.clear();
        discardedWakeHoldByWindowId.clear();
        await saveScrollMemory();
        await import_webextension_polyfill2.default.storage.local.remove(TABWHEEL_STORAGE_KEYS.mruState);
      });
      void ensureActiveTabContentScripts().catch(() => {
      });
    }
    return {
      ensureLoaded,
      activateExistingContentScripts,
      getOverview,
      cycle,
      refreshCurrentTab,
      openSearchTab,
      openNativeNewTab,
      activateMostRecentTab,
      closeCurrentTabAndActivateRecent,
      duplicateTab,
      toggleCycleScope,
      setCycleScope,
      saveScrollPosition,
      markContentScriptReady,
      registerLifecycleListeners
    };
  }

  // src/lib/backgroundRuntime/handlers/tabWheelMessageHandler.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());

  // src/lib/backgroundRuntime/handlers/runtimeRouter.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());
  var UNHANDLED = Symbol("background-runtime-unhandled");
  function registerRuntimeMessageRouter(handlers) {
    import_webextension_polyfill3.default.runtime.onMessage.addListener(async (receivedMessage, sender) => {
      if (typeof receivedMessage !== "object" || receivedMessage === null) return null;
      const message = receivedMessage;
      for (const handler of handlers) {
        try {
          const result = await handler(message, sender);
          if (result !== UNHANDLED) {
            return result;
          }
        } catch (error) {
          console.error("[TabWheel] Runtime message handler failed:", error);
          if (message.type === "TABWHEEL_GET_OVERVIEW") {
            throw error;
          }
          return { ok: false, reason: "Internal error" };
        }
      }
      return null;
    });
  }

  // src/lib/backgroundRuntime/handlers/tabWheelMessageHandler.ts
  async function openHelpInActiveTab() {
    const [tab] = await import_webextension_polyfill4.default.tabs.query({ active: true, currentWindow: true });
    if (tab?.id == null) {
      return { ok: false, reason: "No active tab" };
    }
    try {
      await import_webextension_polyfill4.default.tabs.sendMessage(tab.id, { type: "OPEN_TABWHEEL_HELP" });
      return { ok: true };
    } catch (_) {
      return { ok: false, reason: "Help is unavailable on this page" };
    }
  }
  async function openOptionsPage() {
    try {
      await import_webextension_polyfill4.default.runtime.openOptionsPage();
      return { ok: true };
    } catch (_) {
      return { ok: false, reason: "Settings unavailable" };
    }
  }
  function createTabWheelMessageHandler(domain) {
    return async (message, sender) => {
      switch (message.type) {
        case "TABWHEEL_CONTENT_READY":
          return domain.markContentScriptReady(sender.tab);
        case "TABWHEEL_CYCLE":
          return await domain.cycle(message.direction, sender.tab);
        case "TABWHEEL_REFRESH_CURRENT_TAB":
          return await domain.refreshCurrentTab(sender.tab, message.windowId ?? sender.tab?.windowId);
        case "TABWHEEL_GET_OVERVIEW":
          return await domain.getOverview(sender.tab, message.windowId ?? sender.tab?.windowId);
        case "TABWHEEL_TOGGLE_CYCLE_SCOPE":
          return await domain.toggleCycleScope(sender.tab, message.windowId);
        case "TABWHEEL_SET_CYCLE_SCOPE":
          return await domain.setCycleScope(message.cycleScope, sender.tab, message.windowId, {
            suppressPageStatus: message.suppressPageStatus
          });
        case "TABWHEEL_OPEN_SEARCH_TAB":
          return await domain.openSearchTab(message.query, sender.tab, message.windowId);
        case "TABWHEEL_OPEN_NATIVE_NEW_TAB":
          return await domain.openNativeNewTab(sender.tab, message.windowId);
        case "TABWHEEL_ACTIVATE_MOST_RECENT_TAB":
          return await domain.activateMostRecentTab(sender.tab, message.windowId);
        case "TABWHEEL_CLOSE_CURRENT_TAB_AND_ACTIVATE_RECENT":
          return await domain.closeCurrentTabAndActivateRecent(sender.tab, message.windowId);
        case "TABWHEEL_DUPLICATE_TAB":
          return await domain.duplicateTab(sender.tab, message.windowId);
        case "TABWHEEL_SAVE_SCROLL_POSITION": {
          const tabId = sender.tab?.id;
          const windowId = sender.tab?.windowId;
          if (tabId == null || windowId == null) return { ok: false, reason: "No sender tab" };
          return await domain.saveScrollPosition(
            tabId,
            windowId,
            sender.tab?.url,
            message
          );
        }
        case "TABWHEEL_OPEN_HELP":
          return await openHelpInActiveTab();
        case "TABWHEEL_OPEN_OPTIONS":
          return await openOptionsPage();
        default:
          return UNHANDLED;
      }
    };
  }

  // src/lib/common/utils/storageMigrationsRuntime.ts
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());

  // src/lib/common/utils/storageMigrations.ts
  var STORAGE_SCHEMA_VERSION_KEY = "storageSchemaVersion";
  var TABWHEEL_SETTINGS_KEY = "tabWheelSettings";
  var TABWHEEL_SCROLL_MEMORY_KEY = "tabWheelScrollMemory";
  var TABWHEEL_MRU_STATE_KEY = "tabWheelMruState";
  var TABWHEEL_LEGACY_TAGGED_TABS_KEY = "tabWheelTaggedTabs";
  var TABWHEEL_WHEEL_LIST_KEY = "tabWheelWheelList";
  var STORAGE_SCHEMA_VERSION = 13;
  function readSchemaVersion(storage) {
    const numeric = Number(storage[STORAGE_SCHEMA_VERSION_KEY]);
    if (!Number.isFinite(numeric)) return 0;
    const rounded = Math.floor(numeric);
    return rounded > 0 ? rounded : 0;
  }
  function isStorageSchemaVersionCurrent(rawVersion) {
    return Number(rawVersion) === STORAGE_SCHEMA_VERSION;
  }
  function createCurrentVersionMigrationResult() {
    return {
      fromVersion: STORAGE_SCHEMA_VERSION,
      toVersion: STORAGE_SCHEMA_VERSION,
      changed: false,
      migratedStorage: {}
    };
  }
  function hasKey(storage, key) {
    return Object.prototype.hasOwnProperty.call(storage, key);
  }
  function deleteKey(storage, key) {
    if (!hasKey(storage, key)) return false;
    delete storage[key];
    return true;
  }
  function enableEditableFieldsByDefault(storage) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    if (typeof settings !== "object" || settings === null || Array.isArray(settings)) {
      storage[TABWHEEL_SETTINGS_KEY] = { allowGesturesInEditableFields: true };
      return true;
    }
    const nextSettings = {
      ...settings,
      allowGesturesInEditableFields: true
    };
    const changed = settings.allowGesturesInEditableFields !== true;
    storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    return changed;
  }
  function deleteSettingKey(storage, key) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    if (typeof settings !== "object" || settings === null || Array.isArray(settings)) return false;
    const nextSettings = { ...settings };
    if (!deleteKey(nextSettings, key)) return false;
    storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    return true;
  }
  function migrateTabWheelSettings(storage) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    const hasExistingSettings = typeof settings === "object" && settings !== null && !Array.isArray(settings);
    const nextSettings = hasExistingSettings ? { ...settings } : {};
    let changed = !hasExistingSettings;
    if (nextSettings.cycleScope !== "general" && nextSettings.cycleScope !== "mru") {
      nextSettings.cycleScope = "general";
      changed = true;
    }
    if (typeof nextSettings.skipRestrictedPages !== "boolean") {
      nextSettings.skipRestrictedPages = true;
      changed = true;
    }
    if (typeof nextSettings.openNativeNewTabOnLeftClick !== "boolean") {
      nextSettings.openNativeNewTabOnLeftClick = false;
      changed = true;
    }
    if (deleteKey(nextSettings, "searchUrlTemplate")) changed = true;
    if (deleteKey(nextSettings, "cycleOrder")) changed = true;
    if (typeof nextSettings.wheelPreset !== "string") {
      nextSettings.wheelPreset = "balanced";
      changed = true;
    }
    if (typeof nextSettings.horizontalWheel !== "boolean") {
      nextSettings.horizontalWheel = true;
      changed = true;
    }
    if (typeof nextSettings.overshootGuard !== "boolean") {
      nextSettings.overshootGuard = true;
      changed = true;
    }
    if (typeof nextSettings.wheelAcceleration !== "boolean") {
      nextSettings.wheelAcceleration = false;
      changed = true;
    }
    if (typeof nextSettings.wheelCooldownMs !== "number") {
      nextSettings.wheelCooldownMs = 160;
      changed = true;
    }
    if (typeof nextSettings.wheelSensitivity !== "number") {
      nextSettings.wheelSensitivity = 1;
      changed = true;
    }
    if (typeof nextSettings.pageScrollSpeedMultiplier !== "number") {
      nextSettings.pageScrollSpeedMultiplier = 1;
      changed = true;
    }
    if (typeof nextSettings.pageScrollViewportCapRatio !== "number") {
      nextSettings.pageScrollViewportCapRatio = 1;
      changed = true;
    }
    if (changed) storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    return changed;
  }
  var TABWHEEL_CLICK_ACTION_VALUES = [
    "search",
    "nativeNewTab",
    "recentTab",
    "closeToRecent",
    "duplicateTab",
    "openSettings",
    "none"
  ];
  function isClickActionValue(value) {
    return typeof value === "string" && TABWHEEL_CLICK_ACTION_VALUES.includes(value);
  }
  function migrateClickActionSettings(storage) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    const hasExistingSettings = typeof settings === "object" && settings !== null && !Array.isArray(settings);
    const nextSettings = hasExistingSettings ? { ...settings } : {};
    let changed = !hasExistingSettings;
    const clickActionFallbacks = [
      ["leftClickAction", nextSettings.openNativeNewTabOnLeftClick === true ? "nativeNewTab" : "search"],
      ["middleClickAction", "recentTab"],
      ["rightClickAction", "closeToRecent"]
    ];
    for (const [settingKey, fallback] of clickActionFallbacks) {
      if (isClickActionValue(nextSettings[settingKey])) continue;
      nextSettings[settingKey] = fallback;
      changed = true;
    }
    if (deleteKey(nextSettings, "openNativeNewTabOnLeftClick")) changed = true;
    if (changed) storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    return changed;
  }
  function isHttpUrl(value) {
    if (typeof value !== "string") return false;
    try {
      const url = new URL(value);
      return url.protocol === "http:" || url.protocol === "https:";
    } catch (_) {
      return false;
    }
  }
  function removeScrollMemoryWithoutUrls(storage) {
    const scrollMemory = storage[TABWHEEL_SCROLL_MEMORY_KEY];
    if (typeof scrollMemory !== "object" || scrollMemory === null || Array.isArray(scrollMemory)) return false;
    const nextScrollMemory = {};
    let changed = false;
    for (const [key, rawEntry] of Object.entries(scrollMemory)) {
      if (typeof rawEntry !== "object" || rawEntry === null || Array.isArray(rawEntry)) {
        changed = true;
        continue;
      }
      const entry = rawEntry;
      if (!isHttpUrl(entry.url)) {
        changed = true;
        continue;
      }
      nextScrollMemory[key] = entry;
    }
    if (changed) storage[TABWHEEL_SCROLL_MEMORY_KEY] = nextScrollMemory;
    return changed;
  }
  function removeScrollMemoryZoom(storage) {
    const scrollMemory = storage[TABWHEEL_SCROLL_MEMORY_KEY];
    if (typeof scrollMemory !== "object" || scrollMemory === null || Array.isArray(scrollMemory)) return false;
    const nextScrollMemory = {};
    let changed = false;
    for (const [key, rawEntry] of Object.entries(scrollMemory)) {
      if (typeof rawEntry !== "object" || rawEntry === null || Array.isArray(rawEntry)) {
        nextScrollMemory[key] = rawEntry;
        continue;
      }
      const entry = rawEntry;
      if (!hasKey(entry, "zoom")) {
        nextScrollMemory[key] = entry;
        continue;
      }
      const nextEntry = { ...entry };
      delete nextEntry.zoom;
      nextScrollMemory[key] = nextEntry;
      changed = true;
    }
    if (changed) storage[TABWHEEL_SCROLL_MEMORY_KEY] = nextScrollMemory;
    return changed;
  }
  function migrateStorageSnapshot(input) {
    const migratedStorage = { ...input };
    const fromVersion = readSchemaVersion(input);
    if (fromVersion > STORAGE_SCHEMA_VERSION) {
      return {
        fromVersion,
        toVersion: fromVersion,
        changed: false,
        migratedStorage
      };
    }
    let changed = false;
    if (fromVersion < 2) {
      changed = deleteKey(migratedStorage, "frecencyData") || changed;
    }
    if (fromVersion === 2) {
      changed = deleteKey(migratedStorage, "frecencyData") || changed;
    }
    if (fromVersion < 4) {
      changed = deleteKey(migratedStorage, "tabWheelSessions") || changed;
    }
    if (fromVersion < 5) {
      changed = enableEditableFieldsByDefault(migratedStorage) || changed;
    }
    if (fromVersion < 6) {
      changed = deleteSettingKey(migratedStorage, "showCycleToast") || changed;
    }
    if (fromVersion < 7) {
      changed = removeScrollMemoryWithoutUrls(migratedStorage) || changed;
      changed = deleteKey(migratedStorage, TABWHEEL_MRU_STATE_KEY) || changed;
    }
    if (fromVersion < 8) {
      changed = deleteKey(migratedStorage, TABWHEEL_LEGACY_TAGGED_TABS_KEY) || changed;
      changed = deleteKey(migratedStorage, TABWHEEL_MRU_STATE_KEY) || changed;
      changed = migrateTabWheelSettings(migratedStorage) || changed;
    }
    if (fromVersion < 9) {
      changed = deleteKey(migratedStorage, TABWHEEL_LEGACY_TAGGED_TABS_KEY) || changed;
      changed = deleteKey(migratedStorage, TABWHEEL_WHEEL_LIST_KEY) || changed;
      changed = migrateTabWheelSettings(migratedStorage) || changed;
    }
    if (fromVersion < 10) {
      changed = removeScrollMemoryZoom(migratedStorage) || changed;
    }
    if (fromVersion < 11) {
      changed = migrateTabWheelSettings(migratedStorage) || changed;
    }
    if (fromVersion < 12) {
      changed = deleteSettingKey(migratedStorage, "searchUrlTemplate") || changed;
    }
    if (fromVersion < 13) {
      changed = migrateClickActionSettings(migratedStorage) || changed;
    }
    if (migratedStorage[STORAGE_SCHEMA_VERSION_KEY] !== STORAGE_SCHEMA_VERSION) {
      migratedStorage[STORAGE_SCHEMA_VERSION_KEY] = STORAGE_SCHEMA_VERSION;
      changed = true;
    }
    return {
      fromVersion,
      toVersion: STORAGE_SCHEMA_VERSION,
      changed,
      migratedStorage
    };
  }

  // src/lib/common/utils/storageMigrationsRuntime.ts
  async function migrateStorageIfNeeded() {
    const versionSnapshot = await import_webextension_polyfill5.default.storage.local.get(STORAGE_SCHEMA_VERSION_KEY);
    if (isStorageSchemaVersionCurrent(versionSnapshot[STORAGE_SCHEMA_VERSION_KEY])) {
      return createCurrentVersionMigrationResult();
    }
    const snapshot = await import_webextension_polyfill5.default.storage.local.get(null);
    const result = migrateStorageSnapshot(snapshot);
    if (!result.changed) return result;
    const deletedKeys = Object.keys(snapshot).filter((key) => !(key in result.migratedStorage));
    if (deletedKeys.length > 0) {
      await import_webextension_polyfill5.default.storage.local.remove(deletedKeys);
    }
    await import_webextension_polyfill5.default.storage.local.set(result.migratedStorage);
    return result;
  }

  // src/entryPoints/backgroundRuntime/background.ts
  var tabWheel = createTabWheelDomain();
  tabWheel.registerLifecycleListeners();
  registerRuntimeMessageRouter([
    createTabWheelMessageHandler(tabWheel)
  ]);
  async function bootstrapBackground() {
    const migration = await migrateStorageIfNeeded();
    if (migration.changed) {
      console.log(
        `[TabWheel] Storage migration applied (${migration.fromVersion} -> ${migration.toVersion}).`
      );
    }
    void tabWheel.ensureLoaded();
  }
  void bootstrapBackground().catch((error) => {
    console.error("[TabWheel] Background bootstrap failed:", error);
  });
})();
