# Store Reference — ScrollRail / Harpoon-Tabs

This document is a reference for store-facing metadata, product claims, and permission rationale.

## Extension Names

- Firefox / Zen: Harpoon-Tabs
- Chrome: ScrollRail

## Summary (short — 132 characters max for AMO)

Tag page positions, see on-page anchors, pin tabs, and move fast with the keyboard. No data leaves your browser.

## Description

ScrollRail / Harpoon-Tabs is a keyboard-first page navigation extension focused on saving and revisiting important positions inside the current tab.

Core capabilities:

- Tag up to 4 positions inside the current tab, see them on-page, and cycle through them.
- Automatically connect anchored tabs to the Tab Manager when a slot is available.
- Open the Anchor Tags panel to jump, rename, delete, and undo anchor tags.
- Pin up to 4 tabs to numbered Tab Manager slots.
- Rename Tab Manager entries when page titles are not the label you want.
- Restore scroll position when jumping back to saved tabs.
- Save and restore anchor tags with sessions for pinned tabs.
- Keep up to 4 sessions.
- Customize global and panel keybindings from the options page.

Privacy and behavior claims:

- No data leaves your browser.
- No analytics, tracking, or external network telemetry.
- Everything is stored locally via browser extension storage.
- Works on Firefox, Chrome, and Zen Browser.

## Tags / Keywords

anchors, page navigation, productivity, keyboard, tabs, tab manager, shortcuts, session manager, scroll positions

## Additional notes for Chrome Web Store "Why do you need these permissions?"

- **tabs**: Read tab titles and URLs so the extension can display the tab manager, validate session plans, and switch tabs.
- **storage**: Save tab-manager entries, anchor tags, sessions, keybinding preferences, and migration metadata.
- **host_permissions (<all_urls>)**: Inject content scripts on pages where overlays and keybind-driven UI run.
