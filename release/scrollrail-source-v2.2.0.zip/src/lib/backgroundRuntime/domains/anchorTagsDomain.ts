import browser, { Tabs } from "webextension-polyfill";
import { MAX_ANCHOR_TAGS } from "../../common/contracts/keybindings";
import { normalizeUrlForMatch } from "../../common/utils/helpers";
import {
  findAnchorCycleTarget,
  isDuplicateAnchorTag,
  sortAndCompactAnchorTags,
} from "../../core/anchorTags/anchorTagsCore";

const STORAGE_KEY = "anchorTagsByTabId";

type AnchorTagsByTabId = Record<string, AnchorTagEntry[]>;
type PendingSessionRestore = {
  url: string;
  entries: TabManagerSessionAnchorTag[];
};

export interface AnchorTagsTabManagerState {
  ensureManagedForAnchorTag(
    tab: Tabs.Tab,
    scroll: ScrollData,
  ): Promise<{ ok: boolean; reason?: string; added?: boolean }>;
}

export interface AnchorTagMutationResult {
  ok: boolean;
  reason?: string;
  entry?: AnchorTagEntry;
  slot?: number;
}

export interface AnchorTagsDomain {
  ensureLoaded(): Promise<void>;
  listCurrentTab(tabId?: number, url?: string): Promise<AnchorTagEntry[]>;
  listForSession(tabId: number, url: string): Promise<TabManagerSessionAnchorTag[]>;
  queueSessionRestore(
    tabId: number,
    url: string,
    entries: TabManagerSessionAnchorTag[],
  ): Promise<void>;
  consumeQueuedSessionRestore(tabId: number): Promise<void>;
  replaceForSession(
    tabId: number,
    url: string,
    entries: TabManagerSessionAnchorTag[],
  ): Promise<void>;
  addCurrentTab(): Promise<AnchorTagMutationResult>;
  removeCurrentTabSlot(slot: number): Promise<AnchorTagMutationResult>;
  renameCurrentTabSlot(slot: number, label: string): Promise<AnchorTagMutationResult>;
  restoreCurrentTabEntry(entry: AnchorTagEntry): Promise<AnchorTagMutationResult>;
  cycleCurrentTab(direction: "prev" | "next"): Promise<AnchorTagMutationResult>;
  jumpCurrentTabSlot(slot: number): Promise<AnchorTagMutationResult>;
  clearAll(): Promise<void>;
  registerLifecycleListeners(): void;
}

function tabKey(tabId: number): string {
  return String(tabId);
}

function normalizeStoredEntry(rawEntry: unknown): AnchorTagEntry | null {
  if (typeof rawEntry !== "object" || rawEntry === null) return null;
  const entry = rawEntry as Partial<AnchorTagEntry>;
  const tabId = Number(entry.tabId);
  const slot = Number(entry.slot);
  const scrollX = Number(entry.scrollX);
  const scrollY = Number(entry.scrollY);
  const createdAt = Number(entry.createdAt);
  if (!Number.isInteger(tabId) || tabId <= 0) return null;
  if (!Number.isInteger(slot) || slot <= 0) return null;
  if (!Number.isFinite(scrollX) || !Number.isFinite(scrollY)) return null;
  if (!Number.isFinite(createdAt)) return null;
  if (typeof entry.url !== "string" || !entry.url) return null;
  const label = typeof entry.label === "string" && entry.label.trim()
    ? entry.label.trim().slice(0, 30)
    : "Anchor Tag";

  return {
    tabId,
    url: entry.url,
    slot,
    scrollX: Math.max(0, scrollX),
    scrollY: Math.max(0, scrollY),
    label,
    isCustomLabel: entry.isCustomLabel === true,
    createdAt,
  };
}

function normalizeStoredMap(rawValue: unknown): AnchorTagsByTabId {
  if (typeof rawValue !== "object" || rawValue === null || Array.isArray(rawValue)) {
    return {};
  }

  const normalized: AnchorTagsByTabId = {};
  for (const [key, rawEntries] of Object.entries(rawValue as Record<string, unknown>)) {
    const tabId = Number(key);
    if (!Number.isInteger(tabId) || tabId <= 0 || !Array.isArray(rawEntries)) continue;
    const entries = rawEntries
      .map(normalizeStoredEntry)
      .filter((entry): entry is AnchorTagEntry => !!entry)
      .filter((entry) => entry.tabId === tabId)
      .slice(0, MAX_ANCHOR_TAGS);
    if (entries.length > 0) {
      normalized[key] = sortAndCompactAnchorTags(entries);
    }
  }
  return normalized;
}

export function createAnchorTagsDomain(
  tabManagerState?: AnchorTagsTabManagerState,
): AnchorTagsDomain {
  let anchorTagsByTabId: AnchorTagsByTabId = {};
  let loaded = false;
  const pendingSessionRestores = new Map<number, PendingSessionRestore>();

  async function ensureLoaded(): Promise<void> {
    if (loaded) return;
    const stored = await browser.storage.local.get(STORAGE_KEY);
    anchorTagsByTabId = normalizeStoredMap(stored[STORAGE_KEY]);
    loaded = true;
  }

  async function save(): Promise<void> {
    await browser.storage.local.set({ [STORAGE_KEY]: anchorTagsByTabId });
  }

  async function getActiveTab(): Promise<Tabs.Tab | null> {
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    if (!tab || tab.id == null) return null;
    return tab;
  }

  function getTabEntries(tabId: number, url?: string): AnchorTagEntry[] {
    const entries = anchorTagsByTabId[tabKey(tabId)] || [];
    if (!url) return entries;
    const exactMatches = entries.filter((entry) => entry.url === url);
    if (exactMatches.length > 0) return exactMatches;
    const normalizedUrl = normalizeUrlForMatch(url);
    if (!normalizedUrl) return [];
    return entries.filter((entry) => normalizeUrlForMatch(entry.url) === normalizedUrl);
  }

  function getUrlEntriesAcrossTabs(url: string): AnchorTagEntry[] {
    const normalizedUrl = normalizeUrlForMatch(url);
    if (!normalizedUrl) return [];

    return Object.values(anchorTagsByTabId)
      .flat()
      .filter((entry) => normalizeUrlForMatch(entry.url) === normalizedUrl);
  }

  function setTabEntries(tabId: number, entries: AnchorTagEntry[]): void {
    const compacted = sortAndCompactAnchorTags(entries).slice(0, MAX_ANCHOR_TAGS);
    if (compacted.length === 0) {
      delete anchorTagsByTabId[tabKey(tabId)];
      return;
    }
    anchorTagsByTabId[tabKey(tabId)] = compacted;
  }

  function toSessionAnchorTags(entries: AnchorTagEntry[]): TabManagerSessionAnchorTag[] {
    return sortAndCompactAnchorTags(entries)
      .slice(0, MAX_ANCHOR_TAGS)
      .map((entry) => ({
        slot: entry.slot,
        scrollX: entry.scrollX,
        scrollY: entry.scrollY,
        label: entry.label,
        isCustomLabel: entry.isCustomLabel,
        createdAt: entry.createdAt,
      }));
  }

  function copySessionAnchorTags(
    entries: TabManagerSessionAnchorTag[],
  ): TabManagerSessionAnchorTag[] {
    return entries
      .slice(0, MAX_ANCHOR_TAGS)
      .map((entry, index) => ({
        slot: Number.isInteger(entry.slot) && entry.slot > 0 ? entry.slot : index + 1,
        scrollX: Math.max(0, Number(entry.scrollX) || 0),
        scrollY: Math.max(0, Number(entry.scrollY) || 0),
        label: typeof entry.label === "string" && entry.label.trim()
          ? entry.label.trim().slice(0, 30)
          : "Anchor Tag",
        isCustomLabel: entry.isCustomLabel === true,
        createdAt: Number.isFinite(Number(entry.createdAt)) ? Number(entry.createdAt) : Date.now() + index,
      }));
  }

  function fromSessionAnchorTags(
    tabId: number,
    url: string,
    entries: TabManagerSessionAnchorTag[],
  ): AnchorTagEntry[] {
    return entries
      .slice(0, MAX_ANCHOR_TAGS)
      .map((entry, index) => ({
        tabId,
        url,
        slot: Number.isInteger(entry.slot) && entry.slot > 0 ? entry.slot : index + 1,
        scrollX: Math.max(0, Number(entry.scrollX) || 0),
        scrollY: Math.max(0, Number(entry.scrollY) || 0),
        label: typeof entry.label === "string" && entry.label.trim()
          ? entry.label.trim().slice(0, 30)
          : "Anchor Tag",
        isCustomLabel: entry.isCustomLabel === true,
        createdAt: Number.isFinite(Number(entry.createdAt)) ? Number(entry.createdAt) : Date.now() + index,
      }));
  }

  async function sendFeedback(tabId: number, message: string): Promise<void> {
    try {
      await browser.tabs.sendMessage(tabId, {
        type: "ANCHOR_TAG_FEEDBACK",
        message,
      });
    } catch (_) {
      // Toast delivery is best-effort.
    }
  }

  async function sendTagsUpdated(
    tabId: number,
    entries: AnchorTagEntry[],
    activeSlot?: number,
  ): Promise<void> {
    try {
      await browser.tabs.sendMessage(tabId, {
        type: "ANCHOR_TAGS_UPDATED",
        entries,
        activeSlot,
      });
    } catch (_) {
      // Page rail delivery is best-effort.
    }
  }

  async function getScroll(tabId: number): Promise<ScrollData> {
    try {
      return (await browser.tabs.sendMessage(tabId, { type: "GET_SCROLL" })) as ScrollData;
    } catch (_) {
      return { scrollX: 0, scrollY: 0 };
    }
  }

  async function getLabelContext(
    tab: Tabs.Tab,
    scrollX: number,
    scrollY: number,
  ): Promise<AnchorLabelContext> {
    if (tab.id == null) return { label: tab.title || "Anchor Tag" };
    try {
      const context = (await browser.tabs.sendMessage(tab.id, {
        type: "GET_ANCHOR_LABEL_CONTEXT",
        scrollX,
        scrollY,
      })) as AnchorLabelContext;
      if (context.label && context.label.trim()) {
        return { label: context.label.trim().slice(0, 30) };
      }
    } catch (_) {
      // Content script may be unavailable on restricted pages.
    }
    return { label: (tab.title || "Anchor Tag").trim().slice(0, 30) };
  }

  async function scrollTabToAnchor(tabId: number, entry: AnchorTagEntry): Promise<boolean> {
    try {
      await browser.tabs.sendMessage(tabId, {
        type: "SET_SCROLL",
        scrollX: entry.scrollX,
        scrollY: entry.scrollY,
        smooth: true,
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  async function listCurrentTab(tabId?: number, url?: string): Promise<AnchorTagEntry[]> {
    await ensureLoaded();
    if (tabId != null) {
      return getTabEntries(tabId, url || "");
    }
    const tab = await getActiveTab();
    if (!tab?.id) return [];
    return getTabEntries(tab.id, tab.url || "");
  }

  async function listForSession(
    tabId: number,
    url: string,
  ): Promise<TabManagerSessionAnchorTag[]> {
    await ensureLoaded();
    const entries = toSessionAnchorTags(getTabEntries(tabId, url));
    if (entries.length > 0) return entries;

    const urlEntries = toSessionAnchorTags(getUrlEntriesAcrossTabs(url));
    if (urlEntries.length > 0) return urlEntries;

    const pending = pendingSessionRestores.get(tabId);
    if (pending && normalizeUrlForMatch(pending.url) === normalizeUrlForMatch(url)) {
      return copySessionAnchorTags(pending.entries);
    }

    return [];
  }

  async function queueSessionRestore(
    tabId: number,
    url: string,
    entries: TabManagerSessionAnchorTag[],
  ): Promise<void> {
    await ensureLoaded();
    const sessionEntries = copySessionAnchorTags(entries);
    pendingSessionRestores.set(tabId, { url, entries: sessionEntries });
    setTabEntries(tabId, fromSessionAnchorTags(tabId, url, sessionEntries));
    await save();
    await sendTagsUpdated(tabId, getTabEntries(tabId, url));
  }

  async function consumeQueuedSessionRestore(tabId: number): Promise<void> {
    await ensureLoaded();
    const pending = pendingSessionRestores.get(tabId);
    if (!pending) return;

    let currentUrl = pending.url;
    try {
      const tab = await browser.tabs.get(tabId);
      currentUrl = tab.url || currentUrl;
    } catch (_) {
      // The tab may have closed before its content script was ready.
    }

    pendingSessionRestores.delete(tabId);
    if (normalizeUrlForMatch(currentUrl) !== normalizeUrlForMatch(pending.url)) {
      if (anchorTagsByTabId[tabKey(tabId)]) {
        delete anchorTagsByTabId[tabKey(tabId)];
        await save();
        await sendTagsUpdated(tabId, []);
      }
      return;
    }

    await replaceForSession(tabId, currentUrl, pending.entries);
  }

  async function replaceForSession(
    tabId: number,
    url: string,
    entries: TabManagerSessionAnchorTag[],
  ): Promise<void> {
    await ensureLoaded();
    pendingSessionRestores.delete(tabId);
    setTabEntries(tabId, fromSessionAnchorTags(tabId, url, entries));
    await save();
    await sendTagsUpdated(tabId, getTabEntries(tabId, url));
  }

  async function addCurrentTab(): Promise<AnchorTagMutationResult> {
    await ensureLoaded();
    const tab = await getActiveTab();
    if (!tab?.id) return { ok: false, reason: "No active tab" };

    const url = tab.url || "";
    const entries = getTabEntries(tab.id, url);
    if (entries.length >= MAX_ANCHOR_TAGS) {
      await sendFeedback(tab.id, `Anchor Tags full (max ${MAX_ANCHOR_TAGS})`);
      return { ok: false, reason: `Anchor Tags full (max ${MAX_ANCHOR_TAGS})` };
    }

    const scroll = await getScroll(tab.id);
    if (isDuplicateAnchorTag(entries, scroll.scrollY)) {
      await sendFeedback(tab.id, "Anchor Tag already near here");
      return { ok: false, reason: "Anchor Tag already near here" };
    }

    const context = await getLabelContext(tab, scroll.scrollX, scroll.scrollY);
    const entry: AnchorTagEntry = {
      tabId: tab.id,
      url,
      slot: entries.length + 1,
      scrollX: scroll.scrollX,
      scrollY: scroll.scrollY,
      label: context.label || "Anchor Tag",
      isCustomLabel: false,
      createdAt: Date.now(),
    };

    const nextEntries = sortAndCompactAnchorTags([...entries, entry]);
    setTabEntries(tab.id, nextEntries);
    await save();
    const savedEntry = nextEntries.find((candidate) => candidate.createdAt === entry.createdAt) || entry;
    await sendTagsUpdated(tab.id, getTabEntries(tab.id, url), savedEntry.slot);
    const tabManagerResult = await tabManagerState?.ensureManagedForAnchorTag(tab, scroll);
    const sessionNote = tabManagerResult && !tabManagerResult.ok
      ? " (not session-saved: Tab Manager full)"
      : "";
    await sendFeedback(tab.id, `Added Anchor Tag [${savedEntry.slot}]${sessionNote}`);
    return { ok: true, entry: savedEntry, slot: savedEntry.slot };
  }

  async function removeCurrentTabSlot(slot: number): Promise<AnchorTagMutationResult> {
    await ensureLoaded();
    const tab = await getActiveTab();
    if (!tab?.id) return { ok: false, reason: "No active tab" };
    const entries = getTabEntries(tab.id, tab.url || "");
    const removed = entries.find((entry) => entry.slot === slot);
    if (!removed) return { ok: false, reason: "Anchor Tag not found" };
    setTabEntries(tab.id, entries.filter((entry) => entry.slot !== slot));
    await save();
    await sendTagsUpdated(tab.id, getTabEntries(tab.id, tab.url || ""));
    return { ok: true, entry: removed };
  }

  async function renameCurrentTabSlot(
    slot: number,
    label: string,
  ): Promise<AnchorTagMutationResult> {
    await ensureLoaded();
    const tab = await getActiveTab();
    if (!tab?.id) return { ok: false, reason: "No active tab" };
    const trimmed = label.trim().slice(0, 30);
    if (!trimmed) return { ok: false, reason: "Name cannot be empty" };

    const entries = getTabEntries(tab.id, tab.url || "");
    const target = entries.find((entry) => entry.slot === slot);
    if (!target) return { ok: false, reason: "Anchor Tag not found" };

    target.label = trimmed;
    target.isCustomLabel = true;
    setTabEntries(tab.id, entries);
    await save();
    await sendTagsUpdated(tab.id, getTabEntries(tab.id, tab.url || ""), target.slot);
    return { ok: true, entry: target };
  }

  async function restoreCurrentTabEntry(
    entry: AnchorTagEntry,
  ): Promise<AnchorTagMutationResult> {
    await ensureLoaded();
    const tab = await getActiveTab();
    if (!tab?.id) return { ok: false, reason: "No active tab" };
    const url = tab.url || "";
    const entries = getTabEntries(tab.id, url);
    if (entries.length >= MAX_ANCHOR_TAGS) {
      return { ok: false, reason: `Anchor Tags full (max ${MAX_ANCHOR_TAGS})` };
    }
    if (isDuplicateAnchorTag(entries, entry.scrollY)) {
      return { ok: false, reason: "Anchor Tag already near here" };
    }

    const restored: AnchorTagEntry = {
      ...entry,
      tabId: tab.id,
      url,
    };
    const nextEntries = sortAndCompactAnchorTags([...entries, restored]);
    setTabEntries(tab.id, nextEntries);
    await save();
    const savedEntry = nextEntries.find((candidate) => candidate.createdAt === entry.createdAt) || restored;
    await sendTagsUpdated(tab.id, getTabEntries(tab.id, url), savedEntry.slot);
    return { ok: true, entry: savedEntry, slot: savedEntry.slot };
  }

  async function cycleCurrentTab(
    direction: "prev" | "next",
  ): Promise<AnchorTagMutationResult> {
    await ensureLoaded();
    const tab = await getActiveTab();
    if (!tab?.id) return { ok: false, reason: "No active tab" };
    const entries = getTabEntries(tab.id, tab.url || "");
    const scroll = await getScroll(tab.id);
    const target = findAnchorCycleTarget(entries, scroll.scrollY, direction);
    if (!target) {
      await sendFeedback(tab.id, "No Anchor Tags in this tab");
      return { ok: false, reason: "No Anchor Tags in this tab" };
    }

    const ok = await scrollTabToAnchor(tab.id, target);
    if (!ok) return { ok: false, reason: "Jump failed" };
    await sendTagsUpdated(tab.id, entries, target.slot);
    return { ok: true, entry: target, slot: target.slot };
  }

  async function jumpCurrentTabSlot(slot: number): Promise<AnchorTagMutationResult> {
    await ensureLoaded();
    const tab = await getActiveTab();
    if (!tab?.id) return { ok: false, reason: "No active tab" };
    const entries = getTabEntries(tab.id, tab.url || "");
    const target = entries.find((entry) => entry.slot === slot);
    if (!target) return { ok: false, reason: "Anchor Tag not found" };
    const ok = await scrollTabToAnchor(tab.id, target);
    if (!ok) return { ok: false, reason: "Jump failed" };
    await sendTagsUpdated(tab.id, entries, target.slot);
    return { ok: true, entry: target, slot: target.slot };
  }

  async function clearAll(): Promise<void> {
    await ensureLoaded();
    anchorTagsByTabId = {};
    pendingSessionRestores.clear();
    await save();
  }

  function registerLifecycleListeners(): void {
    browser.tabs.onRemoved.addListener(async (tabId: number) => {
      await ensureLoaded();
      pendingSessionRestores.delete(tabId);
      if (!anchorTagsByTabId[tabKey(tabId)]) return;
      delete anchorTagsByTabId[tabKey(tabId)];
      await save();
    });

    browser.tabs.onUpdated.addListener(async (tabId: number, changeInfo: Tabs.OnUpdatedChangeInfoType) => {
      const changedUrl = changeInfo.url;
      if (!changedUrl) return;
      await ensureLoaded();
      const nextUrl = normalizeUrlForMatch(changedUrl);
      const pending = pendingSessionRestores.get(tabId);
      if (pending) {
        const pendingUrl = normalizeUrlForMatch(pending.url);
        if (nextUrl && pendingUrl && nextUrl === pendingUrl) return;
        pendingSessionRestores.delete(tabId);
      }
      const entries = anchorTagsByTabId[tabKey(tabId)] || [];
      if (entries.length === 0) return;
      const samePageEntries = entries.every(
        (entry) => normalizeUrlForMatch(entry.url) === nextUrl,
      );
      if (nextUrl && samePageEntries) {
        anchorTagsByTabId[tabKey(tabId)] = entries.map((entry) => ({
          ...entry,
          url: changedUrl,
        }));
        await save();
        await sendTagsUpdated(tabId, getTabEntries(tabId, changedUrl));
        return;
      }
      delete anchorTagsByTabId[tabKey(tabId)];
      await save();
      await sendTagsUpdated(tabId, []);
    });

    browser.runtime.onStartup.addListener(async () => {
      await clearAll();
    });
  }

  return {
    ensureLoaded,
    listCurrentTab,
    listForSession,
    queueSessionRestore,
    consumeQueuedSessionRestore,
    replaceForSession,
    addCurrentTab,
    removeCurrentTabSlot,
    renameCurrentTabSlot,
    restoreCurrentTabEntry,
    cycleCurrentTab,
    jumpCurrentTabSlot,
    clearAll,
    registerLifecycleListeners,
  };
}
