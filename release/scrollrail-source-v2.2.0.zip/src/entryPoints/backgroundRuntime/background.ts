// Background entrypoint — composes domain handlers and runtime routers.

import { createAnchorTagsDomain } from "../../lib/backgroundRuntime/domains/anchorTagsDomain";
import { createAnchorTagsMessageHandler } from "../../lib/backgroundRuntime/handlers/anchorTagsMessageHandler";
import { registerCommandRouter } from "../../lib/backgroundRuntime/handlers/commandRouter";
import { createSessionMessageHandler } from "../../lib/backgroundRuntime/handlers/sessionMessageHandler";
import { createTabManagerDomain } from "../../lib/backgroundRuntime/domains/tabManagerDomain";
import { createTabManagerMessageHandler } from "../../lib/backgroundRuntime/handlers/tabManagerMessageHandler";
import { miscMessageHandler } from "../../lib/backgroundRuntime/handlers/miscMessageHandler";
import { registerRuntimeMessageRouter } from "../../lib/backgroundRuntime/handlers/runtimeRouter";
import { registerStartupRestore } from "../../lib/backgroundRuntime/lifecycle/startupRestore";
import { migrateStorageIfNeeded } from "../../lib/common/utils/storageMigrationsRuntime";

async function bootstrapBackground(): Promise<void> {
  const migration = await migrateStorageIfNeeded();
  if (migration.changed) {
    console.log(
      `[Anchor Tags] Storage migration applied (${migration.fromVersion} -> ${migration.toVersion}).`,
    );
  }

  const tabManager = createTabManagerDomain();
  const anchorTags = createAnchorTagsDomain(tabManager);
  tabManager.registerLifecycleListeners();
  anchorTags.registerLifecycleListeners();

  registerCommandRouter({
    addTabManagerEntry: async (tab) => await tabManager.add(tab),
    jumpToSlot: async (slot) => await tabManager.jump(slot),
  });

  registerRuntimeMessageRouter([
    createAnchorTagsMessageHandler(anchorTags),
    createTabManagerMessageHandler(tabManager, anchorTags),
    createSessionMessageHandler(tabManager.state, anchorTags),
    miscMessageHandler,
  ]);

  void anchorTags.ensureLoaded();
  void tabManager.ensureLoaded();
  void tabManager.captureInitialActiveTab();

  registerStartupRestore({
    clearTabManager: async () => await tabManager.clearAll(),
  });
}

void bootstrapBackground().catch((error) => {
  console.error("[Anchor Tags] Background bootstrap failed:", error);
});
