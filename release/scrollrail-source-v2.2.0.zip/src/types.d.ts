// Shared project type declarations

// Allow importing .css files as text (esbuild text loader)
declare module "*.css" {
  const content: string;
  export default content;
}

// Tab Manager entry stored in extension state
interface TabManagerEntry {
  tabId: number;
  url: string;
  title: string;
  isCustomTitle?: boolean;
  scrollX: number;
  scrollY: number;
  slot: number;
  closed?: boolean;  // tab was closed but entry persists for re-opening
}

// Keybinding configuration shape
interface KeyBinding {
  key: string;
  default: string;
}

interface KeybindingsConfig {
  navigationMode: "standard";
  bindings: {
    global: Record<string, KeyBinding>;
    tabManager: Record<string, KeyBinding>;
    anchorTags: Record<string, KeyBinding>;
    session: Record<string, KeyBinding>;
  };
}

// Collision detection result
interface CollisionResult {
  action: string;
  label: string;
}

// Message types passed between background and content scripts
interface ScrollData {
  scrollX: number;
  scrollY: number;
}

interface AnchorLabelContext {
  label: string;
}

interface AnchorTagEntry {
  tabId: number;
  url: string;
  slot: number;
  scrollX: number;
  scrollY: number;
  label: string;
  isCustomLabel: boolean;
  createdAt: number;
}

interface TabManagerSessionAnchorTag {
  slot: number;
  scrollX: number;
  scrollY: number;
  label: string;
  isCustomLabel: boolean;
  createdAt: number;
}

// Saved tab manager session (detach/attach)
interface TabManagerSessionEntry {
  url: string;
  title: string;
  isCustomTitle?: boolean;
  scrollX: number;
  scrollY: number;
  anchorTags?: TabManagerSessionAnchorTag[];
}

interface TabManagerSession {
  name: string;
  entries: TabManagerSessionEntry[];
  savedAt: number;  // timestamp
}

interface SessionLoadSummary {
  sessionName: string;
  totalCount: number;
  replaceCount: number;
  openCount: number;
  reuseCount: number;
  slotDiffs: SessionLoadSlotDiff[];
  reuseMatches: SessionLoadReuseMatch[];
}

interface SessionLoadSlotDiff {
  slot: number;
  change: "replace" | "remove" | "add";
  currentTitle?: string;
  currentUrl?: string;
  incomingTitle?: string;
  incomingUrl?: string;
}

interface SessionLoadReuseMatch {
  slot: number;
  sessionTitle: string;
  sessionUrl: string;
  openTabTitle: string;
  openTabUrl: string;
}
