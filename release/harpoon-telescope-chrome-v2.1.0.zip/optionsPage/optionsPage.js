"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/common/contracts/keybindings.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var DEFAULT_KEYBINDINGS = {
    navigationMode: "standard",
    bindings: {
      global: {
        openTabManager: { key: "Alt+T", default: "Alt+T" },
        addTab: { key: "Alt+Shift+T", default: "Alt+Shift+T" },
        jumpSlot1: { key: "Alt+1", default: "Alt+1" },
        jumpSlot2: { key: "Alt+2", default: "Alt+2" },
        jumpSlot3: { key: "Alt+3", default: "Alt+3" },
        jumpSlot4: { key: "Alt+4", default: "Alt+4" },
        cyclePrev: { key: "Alt+-", default: "Alt+-" },
        cycleNext: { key: "Alt+=", default: "Alt+=" },
        searchInPage: { key: "Alt+F", default: "Alt+F" },
        openSessions: { key: "Alt+S", default: "Alt+S" },
        openSessionSave: { key: "Alt+Shift+S", default: "Alt+Shift+S" },
        openHelp: { key: "Alt+M", default: "Alt+M" }
      },
      tabManager: {
        moveUp: { key: "ArrowUp", default: "ArrowUp" },
        moveDown: { key: "ArrowDown", default: "ArrowDown" },
        jump: { key: "Enter", default: "Enter" },
        remove: { key: "D", default: "D" },
        swap: { key: "W", default: "W" },
        undo: { key: "U", default: "U" },
        close: { key: "Escape", default: "Escape" }
      },
      search: {
        moveUp: { key: "ArrowUp", default: "ArrowUp" },
        moveDown: { key: "ArrowDown", default: "ArrowDown" },
        switchPane: { key: "Tab", default: "Tab" },
        focusSearch: { key: "F", default: "F" },
        clearSearch: { key: "Shift+Space", default: "Shift+Space" },
        accept: { key: "Enter", default: "Enter" },
        close: { key: "Escape", default: "Escape" }
      },
      session: {
        focusList: { key: "Tab", default: "Tab" },
        focusSearch: { key: "F", default: "F" },
        clearSearch: { key: "Shift+Space", default: "Shift+Space" },
        rename: { key: "R", default: "R" },
        overwrite: { key: "O", default: "O" },
        confirmYes: { key: "Y", default: "Y" },
        confirmNo: { key: "N", default: "N" }
      }
    }
  };
  var ACTION_LABELS = {
    global: {
      openTabManager: "Open Tab Manager panel",
      addTab: "Add current tab",
      jumpSlot1: "Jump to slot 1",
      jumpSlot2: "Jump to slot 2",
      jumpSlot3: "Jump to slot 3",
      jumpSlot4: "Jump to slot 4",
      cyclePrev: "Cycle to previous slot",
      cycleNext: "Cycle to next slot",
      searchInPage: "Search in Page",
      openSessions: "Session menu",
      openSessionSave: "Save session",
      openHelp: "Help menu"
    },
    tabManager: {
      moveUp: "Move up",
      moveDown: "Move down",
      jump: "Jump to tab",
      remove: "Remove entry",
      swap: "Swap mode",
      undo: "Undo remove",
      close: "Close"
    },
    search: {
      moveUp: "Move up",
      moveDown: "Move down",
      switchPane: "Switch pane",
      focusSearch: "Focus search",
      clearSearch: "Clear search",
      accept: "Accept / jump",
      close: "Close"
    },
    session: {
      focusList: "Focus list",
      focusSearch: "Focus search",
      clearSearch: "Clear search",
      rename: "Rename session",
      overwrite: "Overwrite session",
      confirmYes: "Confirm",
      confirmNo: "Cancel"
    }
  };
  var SCOPE_LABELS = {
    global: "Global Commands",
    tabManager: "Tab Manager Panel",
    search: "Search Panel",
    session: "Session Panel"
  };
  async function loadKeybindings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get("keybindings");
      if (data.keybindings) {
        return mergeWithDefaults(data.keybindings);
      }
    } catch (_) {
    }
    return JSON.parse(JSON.stringify(DEFAULT_KEYBINDINGS));
  }
  async function saveKeybindings(config) {
    await import_webextension_polyfill.default.storage.local.set({ keybindings: config });
  }
  function mergeWithDefaults(stored) {
    const merged = JSON.parse(
      JSON.stringify(DEFAULT_KEYBINDINGS)
    );
    merged.navigationMode = "standard";
    for (const scope of Object.keys(merged.bindings)) {
      if (!stored.bindings?.[scope]) continue;
      for (const action of Object.keys(merged.bindings[scope])) {
        const storedBinding = stored.bindings[scope]?.[action];
        if (storedBinding) {
          merged.bindings[scope][action].key = storedBinding.key;
        }
      }
    }
    return merged;
  }
  function checkCollision(config, scope, action, key) {
    if (!key) return null;
    const scopeBindings = config.bindings[scope];
    for (const [existingAction, binding] of Object.entries(scopeBindings)) {
      if (existingAction === action) continue;
      if (binding.key === key) {
        const label = ACTION_LABELS[scope]?.[existingAction] || existingAction;
        return { action: existingAction, label };
      }
    }
    return null;
  }
  var KEY_NAME_MAP = {
    ArrowUp: "ArrowUp",
    ArrowDown: "ArrowDown",
    ArrowLeft: "ArrowLeft",
    ArrowRight: "ArrowRight",
    " ": "Space",
    Escape: "Escape",
    Enter: "Enter",
    Tab: "Tab",
    Backspace: "Backspace",
    Delete: "Delete",
    PageUp: "PageUp",
    PageDown: "PageDown",
    Home: "Home",
    End: "End",
    Insert: "Insert"
  };
  var MODIFIER_KEYS = /* @__PURE__ */ new Set(["Control", "Alt", "Shift", "Meta"]);
  function normalizeKeyName(keyName) {
    if (KEY_NAME_MAP[keyName]) return KEY_NAME_MAP[keyName];
    if (keyName.length === 1) return keyName.toUpperCase();
    return keyName;
  }
  function keyEventToString(event) {
    const parts = [];
    if (event.ctrlKey) parts.push("Ctrl");
    if (event.altKey) parts.push("Alt");
    if (event.shiftKey) parts.push("Shift");
    if (event.metaKey) parts.push("Meta");
    const keyName = normalizeKeyName(event.key);
    if (MODIFIER_KEYS.has(keyName)) return null;
    parts.push(keyName);
    return parts.join("+");
  }
  function keyToDisplay(keyString) {
    if (!keyString) return "Unbound";
    return keyString.replace("ArrowUp", "\u2191").replace("ArrowDown", "\u2193").replace("ArrowLeft", "\u2190").replace("ArrowRight", "\u2192").replace("Escape", "Esc").replace("Delete", "Del").replace("Backspace", "Bksp");
  }

  // src/lib/common/utils/helpers.ts
  var HTML_ESCAPE = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  var HTML_ESCAPE_RE = /[&<>"']/;
  function escapeHtml(text) {
    if (!HTML_ESCAPE_RE.test(text)) return text;
    return text.replace(/[&<>"']/g, (character) => HTML_ESCAPE[character]);
  }

  // src/entryPoints/optionsPage/optionsPage.ts
  document.addEventListener("DOMContentLoaded", async () => {
    let config = await loadKeybindings();
    let recordingState = null;
    const container = document.getElementById("bindingsContainer");
    const resetAllBtn = document.getElementById("resetAllBtn");
    const disableAllBtn = document.getElementById("disableAllBtn");
    const statusBar = document.getElementById("statusBar");
    function renderBindings() {
      container.innerHTML = "";
      for (const [scope, actions] of Object.entries(config.bindings)) {
        const scopeLabel = SCOPE_LABELS[scope] || scope;
        const header = document.createElement("div");
        header.className = "scope-header";
        header.textContent = scopeLabel;
        container.appendChild(header);
        for (const [action, binding] of Object.entries(actions)) {
          const label = ACTION_LABELS[scope]?.[action] || action;
          const isModified = binding.key !== binding.default;
          const isUnbound = !binding.key;
          const row = document.createElement("div");
          row.className = "binding-row";
          row.dataset.scope = scope;
          row.dataset.action = action;
          row.innerHTML = `
          <span class="binding-action">${escapeHtml(label)}</span>
          <span class="binding-key${isModified ? " modified" : ""}${isUnbound ? " unbound" : ""}">${escapeHtml(keyToDisplay(binding.key))}</span>
          <button class="btn change-btn">change</button>
          <button class="btn unbind-btn"${isUnbound ? ' style="opacity:0.3;pointer-events:none"' : ""}>unbind</button>
          <button class="btn reset-btn"${!isModified ? ' style="opacity:0.3;pointer-events:none"' : ""}>reset</button>
        `;
          const changeBtn = row.querySelector(".change-btn");
          const unbindBtn = row.querySelector(".unbind-btn");
          const resetBtn = row.querySelector(".reset-btn");
          changeBtn.addEventListener(
            "click",
            () => startRecording(scope, action, row)
          );
          unbindBtn.addEventListener(
            "click",
            () => unbindBinding(scope, action)
          );
          resetBtn.addEventListener(
            "click",
            () => resetBinding(scope, action)
          );
          container.appendChild(row);
        }
      }
    }
    function startRecording(scope, action, row) {
      cancelRecording();
      recordingState = { scope, action, row };
      row.classList.add("recording");
      const keyDisplay = row.querySelector(".binding-key");
      keyDisplay.textContent = "Press a key...";
      keyDisplay.classList.add("recording-indicator");
      const changeBtn = row.querySelector(".change-btn");
      changeBtn.textContent = "cancel";
      changeBtn.classList.add("cancel-btn");
      changeBtn.onclick = (event) => {
        event.stopPropagation();
        cancelRecording();
      };
    }
    function cancelRecording() {
      if (!recordingState) return;
      recordingState.row.classList.remove("recording");
      recordingState = null;
      renderBindings();
    }
    document.addEventListener(
      "keydown",
      async (event) => {
        if (!recordingState) return;
        event.preventDefault();
        event.stopPropagation();
        const keyStr = keyEventToString(event);
        if (!keyStr) return;
        const { scope, action } = recordingState;
        const collision = checkCollision(config, scope, action, keyStr);
        if (collision) {
          showStatus(
            `Conflict: "${keyToDisplay(keyStr)}" is already bound to "${collision.label}". Unbind it first.`,
            "error"
          );
          cancelRecording();
          return;
        }
        config.bindings[scope][action].key = keyStr;
        await saveKeybindings(config);
        const label = ACTION_LABELS[scope]?.[action] || action;
        showStatus(`${label} \u2192 ${keyToDisplay(keyStr)}`, "success");
        cancelRecording();
        renderBindings();
      },
      true
    );
    async function resetBinding(scope, action) {
      const defaultKey = config.bindings[scope][action].default;
      const collision = checkCollision(config, scope, action, defaultKey);
      if (collision) {
        showStatus(
          `Conflict: default "${keyToDisplay(defaultKey)}" conflicts with "${collision.label}".`,
          "error"
        );
        return;
      }
      config.bindings[scope][action].key = defaultKey;
      await saveKeybindings(config);
      const label = ACTION_LABELS[scope]?.[action] || action;
      showStatus(
        `${label} \u2192 ${keyToDisplay(defaultKey)} (default)`,
        "success"
      );
      renderBindings();
    }
    async function unbindBinding(scope, action) {
      if (!config.bindings[scope][action].key) return;
      config.bindings[scope][action].key = "";
      await saveKeybindings(config);
      const label = ACTION_LABELS[scope]?.[action] || action;
      showStatus(`${label} \u2192 Unbound`, "success");
      renderBindings();
    }
    resetAllBtn.addEventListener("click", async () => {
      config = JSON.parse(JSON.stringify(DEFAULT_KEYBINDINGS));
      await saveKeybindings(config);
      showStatus("All keybindings reset to defaults.", "success");
      renderBindings();
    });
    disableAllBtn.addEventListener("click", async () => {
      for (const [scope, actions] of Object.entries(config.bindings)) {
        for (const action of Object.keys(actions)) {
          config.bindings[scope][action].key = "";
        }
      }
      await saveKeybindings(config);
      showStatus("All keybindings disabled (unbound).", "success");
      renderBindings();
    });
    let statusTimeout = null;
    function showStatus(message, type) {
      if (statusTimeout) clearTimeout(statusTimeout);
      statusBar.textContent = message;
      statusBar.className = `status-bar visible ${type}`;
      statusTimeout = setTimeout(() => {
        statusBar.classList.remove("visible");
      }, 3500);
    }
    renderBindings();
  });
})();
