"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/entryPoints/toolbarPopup/toolbarPopup.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());

  // src/lib/common/utils/helpers.ts
  var HTML_ESCAPE = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  var HTML_ESCAPE_RE = /[&<>"']/;
  function escapeHtml(text) {
    if (!HTML_ESCAPE_RE.test(text)) return text;
    return text.replace(/[&<>"']/g, (character) => HTML_ESCAPE[character]);
  }
  var DOMAIN_CACHE_MAX = 500;
  var domainCache = /* @__PURE__ */ new Map();
  function cacheDomain(url, value) {
    if (domainCache.size >= DOMAIN_CACHE_MAX) {
      const firstKey = domainCache.keys().next().value;
      if (firstKey !== void 0) domainCache.delete(firstKey);
    }
    domainCache.set(url, value);
    return value;
  }
  function extractDomain(url) {
    const cached = domainCache.get(url);
    if (cached) return cached;
    try {
      return cacheDomain(url, new URL(url).hostname);
    } catch (_) {
      return cacheDomain(url, url.length > 30 ? url.substring(0, 30) + "\u2026" : url);
    }
  }

  // src/lib/common/contracts/tabWheel.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var MAX_WHEEL_LIST_TABS = 15;
  var TABWHEEL_STORAGE_KEYS = {
    settings: "tabWheelSettings",
    scrollMemory: "tabWheelScrollMemory",
    wheelList: "tabWheelWheelList"
  };
  var TABWHEEL_MODIFIER_KEYS = [
    "alt",
    "ctrl",
    "meta"
  ];
  var TABWHEEL_CYCLE_SCOPES = ["general", "tagged"];
  var TABWHEEL_PRESETS = ["precise", "balanced", "fast", "custom"];
  var MIN_WHEEL_SENSITIVITY = 0.5;
  var MAX_WHEEL_SENSITIVITY = 2;
  var MIN_WHEEL_COOLDOWN_MS = 60;
  var MAX_WHEEL_COOLDOWN_MS = 400;
  var TABWHEEL_PRESET_VALUES = {
    precise: {
      wheelSensitivity: 0.8,
      wheelCooldownMs: 220,
      wheelAcceleration: false,
      overshootGuard: true
    },
    balanced: {
      wheelSensitivity: 1,
      wheelCooldownMs: 160,
      wheelAcceleration: false,
      overshootGuard: true
    },
    fast: {
      wheelSensitivity: 1.35,
      wheelCooldownMs: 90,
      wheelAcceleration: true,
      overshootGuard: true
    }
  };
  var DEFAULT_TABWHEEL_SETTINGS = {
    invertScroll: false,
    gestureModifier: "alt",
    gestureWithShift: false,
    allowGesturesInEditableFields: true,
    cycleScope: "general",
    skipPinnedTabs: false,
    wrapAround: true,
    wheelPreset: "balanced",
    wheelSensitivity: 1,
    wheelCooldownMs: 160,
    wheelAcceleration: false,
    horizontalWheel: true,
    overshootGuard: true
  };
  function normalizeModifierKey(value, fallback) {
    return TABWHEEL_MODIFIER_KEYS.includes(value) ? value : fallback;
  }
  function normalizeShiftRequirement(value) {
    return value === true;
  }
  function normalizeEnabledFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeNumberInRange(value, fallback, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.max(min, Math.min(max, numeric));
  }
  function normalizeTabWheelCycleScope(value) {
    return TABWHEEL_CYCLE_SCOPES.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.cycleScope;
  }
  function normalizeWheelPreset(value) {
    return TABWHEEL_PRESETS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.wheelPreset;
  }
  function detectTabWheelPreset(settings) {
    for (const preset of ["precise", "balanced", "fast"]) {
      const presetValues = TABWHEEL_PRESET_VALUES[preset];
      if (settings.wheelSensitivity === presetValues.wheelSensitivity && settings.wheelCooldownMs === presetValues.wheelCooldownMs && settings.wheelAcceleration === presetValues.wheelAcceleration && settings.overshootGuard === presetValues.overshootGuard) {
        return preset;
      }
    }
    return "custom";
  }
  function applyTabWheelPreset(settings, preset) {
    if (preset === "custom") return { ...settings, wheelPreset: "custom" };
    return {
      ...settings,
      ...TABWHEEL_PRESET_VALUES[preset],
      wheelPreset: preset
    };
  }
  function normalizeTabWheelSettings(value) {
    if (typeof value !== "object" || value === null) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
    const settings = value;
    const normalizedSettings = {
      invertScroll: settings.invertScroll === true,
      gestureModifier: normalizeModifierKey(
        settings.gestureModifier,
        DEFAULT_TABWHEEL_SETTINGS.gestureModifier
      ),
      gestureWithShift: normalizeShiftRequirement(settings.gestureWithShift),
      allowGesturesInEditableFields: normalizeEnabledFlag(
        settings.allowGesturesInEditableFields,
        DEFAULT_TABWHEEL_SETTINGS.allowGesturesInEditableFields
      ),
      cycleScope: normalizeTabWheelCycleScope(settings.cycleScope),
      skipPinnedTabs: normalizeEnabledFlag(
        settings.skipPinnedTabs,
        DEFAULT_TABWHEEL_SETTINGS.skipPinnedTabs
      ),
      wrapAround: normalizeEnabledFlag(
        settings.wrapAround,
        DEFAULT_TABWHEEL_SETTINGS.wrapAround
      ),
      wheelPreset: normalizeWheelPreset(settings.wheelPreset),
      wheelSensitivity: normalizeNumberInRange(
        settings.wheelSensitivity,
        DEFAULT_TABWHEEL_SETTINGS.wheelSensitivity,
        MIN_WHEEL_SENSITIVITY,
        MAX_WHEEL_SENSITIVITY
      ),
      wheelCooldownMs: normalizeNumberInRange(
        settings.wheelCooldownMs,
        DEFAULT_TABWHEEL_SETTINGS.wheelCooldownMs,
        MIN_WHEEL_COOLDOWN_MS,
        MAX_WHEEL_COOLDOWN_MS
      ),
      wheelAcceleration: normalizeEnabledFlag(
        settings.wheelAcceleration,
        DEFAULT_TABWHEEL_SETTINGS.wheelAcceleration
      ),
      horizontalWheel: normalizeEnabledFlag(
        settings.horizontalWheel,
        DEFAULT_TABWHEEL_SETTINGS.horizontalWheel
      ),
      overshootGuard: normalizeEnabledFlag(
        settings.overshootGuard,
        DEFAULT_TABWHEEL_SETTINGS.overshootGuard
      )
    };
    normalizedSettings.wheelPreset = settings.wheelPreset == null ? detectTabWheelPreset(normalizedSettings) : normalizedSettings.wheelPreset;
    return normalizedSettings;
  }
  function formatTabWheelModifierKey(modifier) {
    if (modifier === "ctrl") return "Ctrl";
    if (modifier === "meta") return "Meta";
    return "Alt";
  }
  function formatTabWheelModifierCombo(modifier, withShift) {
    const baseModifier = formatTabWheelModifierKey(modifier);
    return withShift ? `${baseModifier} + Shift` : baseModifier;
  }
  async function loadTabWheelSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.settings);
      return normalizeTabWheelSettings(data[TABWHEEL_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
  }
  async function saveTabWheelSettings(settings) {
    await import_webextension_polyfill.default.storage.local.set({
      [TABWHEEL_STORAGE_KEYS.settings]: normalizeTabWheelSettings(settings)
    });
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  var DEFAULT_RUNTIME_RETRY_POLICY = {
    retryDelaysMs: [0, 80, 220, 420]
  };
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill2.default.runtime.sendMessage(message);
  }
  async function sendRuntimeMessageWithRetry(message, policy = DEFAULT_RUNTIME_RETRY_POLICY) {
    let lastError = null;
    for (const delay of policy.retryDelaysMs) {
      if (delay > 0) {
        await sleep(delay);
      }
      try {
        return await sendRuntimeMessage(message);
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error(`Runtime message failed: ${message.type}`);
  }

  // src/lib/adapters/runtime/tabWheelApi.ts
  function getTabWheelOverviewWithRetry(windowId, policy = { retryDelaysMs: [0, 90, 240, 450] }) {
    return sendRuntimeMessageWithRetry(
      { type: "TABWHEEL_GET_OVERVIEW", windowId },
      policy
    );
  }
  function cycleTabWheel(direction) {
    return sendRuntimeMessage({
      type: "TABWHEEL_CYCLE",
      direction
    });
  }
  function refreshCurrentTabWheel(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_REFRESH_CURRENT_TAB",
      windowId
    });
  }
  function toggleCurrentTabWheelTag(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_TOGGLE_CURRENT_TAG",
      windowId
    });
  }
  function removeTaggedTabWheelTab(tabId, windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_REMOVE_TAGGED_TAB",
      tabId,
      windowId
    });
  }
  function clearTaggedTabWheelTabs(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_CLEAR_TAGGED_TABS",
      windowId
    });
  }
  function activateTaggedTabWheelTab(tabId, windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_ACTIVATE_TAGGED_TAB",
      tabId,
      windowId
    });
  }
  function setTabWheelCycleScope(cycleScope, windowId, options = {}) {
    return sendRuntimeMessage({
      type: "TABWHEEL_SET_CYCLE_SCOPE",
      cycleScope,
      windowId,
      suppressPageStatus: options.suppressPageStatus
    });
  }
  function openTabWheelHelp() {
    return sendRuntimeMessage({ type: "TABWHEEL_OPEN_HELP" });
  }

  // src/entryPoints/toolbarPopup/toolbarPopup.ts
  function presetLabel(preset) {
    if (preset === "precise") return "Precise";
    if (preset === "fast") return "Fast";
    if (preset === "custom") return "Custom";
    return "Balanced";
  }
  function cycleScopeLabel(scope) {
    return scope === "tagged" ? "Wheel List" : "General";
  }
  var UNAVAILABLE_GESTURES_MESSAGE = "Page gestures unavailable here; popup buttons still work.";
  function setSelectOptions(select, values, selected, label) {
    select.innerHTML = values.map((value) => `<option value="${value}" ${value === selected ? "selected" : ""}>${label(value)}</option>`).join("");
  }
  document.addEventListener("DOMContentLoaded", async () => {
    const shortcutEl = document.getElementById("shortcutLabel");
    const shortcutStatusEl = document.getElementById("shortcutStatus");
    const toastEl = document.getElementById("popupToast");
    const titlebarTextEl = document.getElementById("titlebarText");
    const refreshTabWheelBtn = document.getElementById("refreshTabWheelBtn");
    const scopeLabel = document.getElementById("scopeLabel");
    const tagCountLabel = document.getElementById("tagCountLabel");
    const tagCurrentBtn = document.getElementById("tagCurrentBtn");
    const generalModeBtn = document.getElementById("generalModeBtn");
    const wheelListModeBtn = document.getElementById("wheelListModeBtn");
    const prevTabBtn = document.getElementById("prevTabBtn");
    const nextTabBtn = document.getElementById("nextTabBtn");
    const wheelListSection = document.getElementById("wheelListSection");
    const wheelListToggle = document.getElementById("wheelListToggle");
    const clearTagsBtn = document.getElementById("clearTagsBtn");
    const taggedTabsList = document.getElementById("taggedTabsList");
    const wheelPresetSelect = document.getElementById("wheelPreset");
    const gestureModifierSelect = document.getElementById("gestureModifier");
    const gestureWithShiftInput = document.getElementById("gestureWithShift");
    const invertScrollInput = document.getElementById("invertScroll");
    const skipPinnedTabsInput = document.getElementById("skipPinnedTabs");
    const wrapAroundInput = document.getElementById("wrapAround");
    const wheelAccelerationInput = document.getElementById("wheelAcceleration");
    const horizontalWheelInput = document.getElementById("horizontalWheel");
    const overshootGuardInput = document.getElementById("overshootGuard");
    const allowEditableInput = document.getElementById("allowGesturesInEditableFields");
    const wheelSensitivityInput = document.getElementById("wheelSensitivity");
    const wheelSensitivityValue = document.getElementById("wheelSensitivityValue");
    const wheelCooldownInput = document.getElementById("wheelCooldownMs");
    const wheelCooldownValue = document.getElementById("wheelCooldownValue");
    const helpBtn = document.getElementById("helpBtn");
    const settingsBtn = document.getElementById("settingsBtn");
    let settings = await loadTabWheelSettings();
    let overview = null;
    let statusTimer = 0;
    let statusHiddenCallback = null;
    let isConfirmingClear = false;
    let isWheelListOpen = false;
    function clearStatusTimer() {
      if (statusTimer) window.clearTimeout(statusTimer);
      statusTimer = 0;
    }
    function runStatusHiddenCallback() {
      const callback = statusHiddenCallback;
      statusHiddenCallback = null;
      callback?.();
    }
    function hideStatus(runHiddenCallback = true) {
      clearStatusTimer();
      toastEl.classList.remove("is-visible");
      toastEl.textContent = "";
      if (runHiddenCallback) runStatusHiddenCallback();
      else statusHiddenCallback = null;
    }
    function showStatus(message, sticky = false, onHidden) {
      clearStatusTimer();
      runStatusHiddenCallback();
      toastEl.textContent = message;
      toastEl.classList.add("is-visible");
      statusHiddenCallback = onHidden || null;
      if (sticky) {
        statusHiddenCallback = null;
        return;
      }
      statusTimer = window.setTimeout(() => {
        hideStatus();
      }, 1800);
    }
    async function refreshOverview() {
      overview = await getTabWheelOverviewWithRetry().catch(() => null);
    }
    function renderTaggedList() {
      const taggedTabs = overview?.taggedTabs || [];
      if (taggedTabs.length === 0) {
        taggedTabsList.innerHTML = `
        <div class="tagged-empty">
          <strong>No Wheel List tabs</strong>
          <span>Add tabs here to create a short wheel-cycling list. ${escapeHtml(formatTabWheelModifierCombo(settings.gestureModifier, settings.gestureWithShift))} + Left Click also adds the current tab.</span>
        </div>
      `;
        clearTagsBtn.disabled = true;
        return;
      }
      clearTagsBtn.disabled = false;
      taggedTabsList.innerHTML = taggedTabs.map((entry) => {
        const isActive = overview?.activeTabId === entry.tabId;
        return `
        <div class="tagged-row${isActive ? " is-active" : ""}">
          <button class="tagged-main" data-action="activate" data-tab-id="${entry.tabId}" type="button">
            <span class="tagged-title">${escapeHtml(entry.title || "Untitled")}</span>
            <span class="tagged-url">${escapeHtml(extractDomain(entry.url) || entry.url || "Restricted page")}</span>
          </button>
          <span class="tagged-actions">
            <button data-action="remove" data-tab-id="${entry.tabId}" type="button">Remove</button>
          </span>
        </div>
      `;
      }).join("");
      taggedTabsList.querySelectorAll('[data-action="activate"]').forEach((button) => {
        button.addEventListener("click", async () => {
          const tabId = Number(button.dataset.tabId);
          const result = await activateTaggedTabWheelTab(tabId);
          if (!result.ok) {
            showStatus(result.reason || "Unable to activate tab");
            return;
          }
          window.close();
        });
      });
      taggedTabsList.querySelectorAll('[data-action="remove"]').forEach((button) => {
        button.addEventListener("click", async () => {
          const tabId = Number(button.dataset.tabId);
          const result = await removeTaggedTabWheelTab(tabId);
          if (!result.ok) {
            showStatus(result.reason || "Remove failed");
            return;
          }
          await refreshAll();
          showStatus("Removed from Wheel List");
        });
      });
    }
    function renderWheelListDisclosure() {
      wheelListSection.classList.toggle("is-open", isWheelListOpen);
      wheelListToggle.setAttribute("aria-expanded", String(isWheelListOpen));
    }
    function renderModeButtons(cycleScope) {
      for (const button of [generalModeBtn, wheelListModeBtn]) {
        const isActive = button.dataset.cycleScope === cycleScope;
        button.classList.toggle("is-active", isActive);
        button.setAttribute("aria-pressed", String(isActive));
      }
    }
    function renderState(options = {}) {
      const gesture = formatTabWheelModifierCombo(settings.gestureModifier, settings.gestureWithShift);
      const cycleScope = overview?.cycleScope || settings.cycleScope;
      shortcutEl.textContent = `${gesture} + Wheel`;
      titlebarTextEl.textContent = overview ? `TabWheel (${Math.max(1, overview.activeIndex + 1)}/${overview.tabCount})` : "TabWheel";
      scopeLabel.textContent = cycleScopeLabel(cycleScope);
      tagCountLabel.textContent = `${overview?.taggedCount || 0}/${MAX_WHEEL_LIST_TABS} tagged`;
      tagCurrentBtn.textContent = overview?.isCurrentTagged ? "Remove current" : "Add current";
      renderModeButtons(cycleScope);
      shortcutStatusEl.textContent = overview?.contentScriptStatus === "ready" ? "Scroll switches tabs. Left click adds this tab. Right click changes mode." : "Use popup buttons when page shortcuts are unavailable";
      if (overview?.contentScriptStatus === "unavailable") {
        if (options.announceUnavailable) showStatus(UNAVAILABLE_GESTURES_MESSAGE, true);
      } else if (toastEl.textContent === UNAVAILABLE_GESTURES_MESSAGE) {
        hideStatus();
      }
      renderWheelListDisclosure();
      renderTaggedList();
    }
    function renderSettings() {
      setSelectOptions(
        wheelPresetSelect,
        TABWHEEL_PRESETS,
        settings.wheelPreset,
        (value) => presetLabel(value)
      );
      setSelectOptions(
        gestureModifierSelect,
        TABWHEEL_MODIFIER_KEYS,
        settings.gestureModifier,
        (value) => formatTabWheelModifierKey(value)
      );
      gestureWithShiftInput.checked = settings.gestureWithShift;
      invertScrollInput.checked = settings.invertScroll;
      skipPinnedTabsInput.checked = settings.skipPinnedTabs;
      wrapAroundInput.checked = settings.wrapAround;
      wheelAccelerationInput.checked = settings.wheelAcceleration;
      horizontalWheelInput.checked = settings.horizontalWheel;
      overshootGuardInput.checked = settings.overshootGuard;
      allowEditableInput.checked = settings.allowGesturesInEditableFields;
      wheelSensitivityInput.min = String(MIN_WHEEL_SENSITIVITY);
      wheelSensitivityInput.max = String(MAX_WHEEL_SENSITIVITY);
      wheelSensitivityInput.value = String(settings.wheelSensitivity);
      wheelSensitivityValue.textContent = `Wheel distance: ${settings.wheelSensitivity.toFixed(1)}x`;
      wheelCooldownInput.min = String(MIN_WHEEL_COOLDOWN_MS);
      wheelCooldownInput.max = String(MAX_WHEEL_COOLDOWN_MS);
      wheelCooldownInput.value = String(settings.wheelCooldownMs);
      wheelCooldownValue.textContent = `Switch delay: ${Math.round(settings.wheelCooldownMs)}ms`;
    }
    async function refreshAll(options = {}) {
      settings = await loadTabWheelSettings();
      await refreshOverview();
      renderSettings();
      renderState(options);
    }
    async function persist(nextSettings) {
      settings = nextSettings;
      await saveTabWheelSettings(settings);
      await refreshAll();
      showStatus("Saved");
    }
    async function runPopupCycle(direction) {
      const result = await cycleTabWheel(direction).catch(() => ({
        ok: false,
        reason: "Unable to switch tabs"
      }));
      await refreshAll();
      if (!result.ok) {
        showStatus(result.reason || "Unable to switch tabs");
        return;
      }
    }
    async function setPopupCycleScope(cycleScope) {
      const result = await setTabWheelCycleScope(cycleScope, void 0, {
        suppressPageStatus: true
      }).catch(() => ({
        ok: false,
        reason: "Mode switch failed"
      }));
      await refreshAll();
      showStatus(result.ok ? `Mode: ${cycleScopeLabel(result.cycleScope || cycleScope)}` : result.reason || "Mode switch failed");
    }
    async function refreshCurrentTabWheelState() {
      refreshTabWheelBtn.disabled = true;
      try {
        const result = await refreshCurrentTabWheel();
        settings = await loadTabWheelSettings();
        overview = result.overview || await getTabWheelOverviewWithRetry().catch(() => null);
        renderSettings();
        renderState();
        showStatus(result.ok ? "TabWheel refreshed" : result.reason || "TabWheel cannot run on this page.");
      } catch (_) {
        await refreshAll();
        showStatus("TabWheel refresh failed");
      } finally {
        refreshTabWheelBtn.disabled = false;
      }
    }
    function readSettings() {
      const nextSettings = {
        ...settings,
        wheelPreset: wheelPresetSelect.value,
        gestureModifier: gestureModifierSelect.value,
        gestureWithShift: gestureWithShiftInput.checked,
        invertScroll: invertScrollInput.checked,
        skipPinnedTabs: skipPinnedTabsInput.checked,
        wrapAround: wrapAroundInput.checked,
        wheelAcceleration: wheelAccelerationInput.checked,
        horizontalWheel: horizontalWheelInput.checked,
        overshootGuard: overshootGuardInput.checked,
        allowGesturesInEditableFields: allowEditableInput.checked,
        wheelSensitivity: Number(wheelSensitivityInput.value),
        wheelCooldownMs: Number(wheelCooldownInput.value)
      };
      return {
        ...nextSettings,
        wheelPreset: detectTabWheelPreset(nextSettings)
      };
    }
    [
      gestureModifierSelect,
      gestureWithShiftInput,
      invertScrollInput,
      skipPinnedTabsInput,
      wrapAroundInput,
      wheelAccelerationInput,
      horizontalWheelInput,
      overshootGuardInput,
      allowEditableInput,
      wheelSensitivityInput,
      wheelCooldownInput
    ].forEach((control) => {
      control.addEventListener("change", () => void persist(readSettings()));
    });
    wheelPresetSelect.addEventListener("change", () => {
      void persist(applyTabWheelPreset(readSettings(), wheelPresetSelect.value));
    });
    wheelSensitivityInput.addEventListener("input", () => {
      wheelSensitivityValue.textContent = `Wheel distance: ${Number(wheelSensitivityInput.value).toFixed(1)}x`;
      wheelPresetSelect.value = "custom";
    });
    wheelCooldownInput.addEventListener("input", () => {
      wheelCooldownValue.textContent = `Switch delay: ${Math.round(Number(wheelCooldownInput.value))}ms`;
      wheelPresetSelect.value = "custom";
    });
    tagCurrentBtn.addEventListener("click", async () => {
      const result = await toggleCurrentTabWheelTag();
      await refreshAll();
      showStatus(result.ok ? "Wheel List updated" : result.reason || "Could not update Wheel List");
    });
    wheelListToggle.addEventListener("click", () => {
      isWheelListOpen = !isWheelListOpen;
      renderWheelListDisclosure();
    });
    generalModeBtn.addEventListener("click", () => {
      void setPopupCycleScope("general");
    });
    wheelListModeBtn.addEventListener("click", () => {
      void setPopupCycleScope("tagged");
    });
    prevTabBtn.addEventListener("click", () => {
      void runPopupCycle("prev");
    });
    nextTabBtn.addEventListener("click", () => {
      void runPopupCycle("next");
    });
    refreshTabWheelBtn.addEventListener("click", () => {
      void refreshCurrentTabWheelState();
    });
    clearTagsBtn.addEventListener("click", async () => {
      if (!isConfirmingClear) {
        isConfirmingClear = true;
        showStatus("Click Remove all again to empty the Wheel List", false, () => {
          isConfirmingClear = false;
        });
        return;
      }
      isConfirmingClear = false;
      const result = await clearTaggedTabWheelTabs();
      await refreshAll();
      showStatus(result.ok ? "Wheel List emptied" : result.reason || "Could not empty Wheel List");
    });
    helpBtn.addEventListener("click", async () => {
      const result = await openTabWheelHelp();
      if (!result.ok) {
        showStatus(result.reason || "Help unavailable on this page");
        return;
      }
      window.close();
    });
    settingsBtn.addEventListener("click", () => {
      void import_webextension_polyfill3.default.runtime.openOptionsPage();
      window.close();
    });
    await refreshAll({ announceUnavailable: true });
  });
})();
