#  Harpoon-Tabs — Browser Extension

Harpoon-Tabs is a keyboard-first saved browsing-position extension for saving important tabs and page positions, then jumping back fast with scroll memory, Anchor Tags, and small saved sessions across Firefox, Chrome, and Zen.

## What It Does

- Anchor Tags: tag up to 4 positions inside the current tab, see them on-page, and cycle top-down.
- Tab Manager: pin up to 4 tabs and jump instantly with scroll-position memory.
- Sessions: save/load up to 4 named Tab Manager sets, including saved anchor tags.
- Keybinding customization: configurable global and panel bindings.

## Feature Snapshot

### Anchor Tags

- `Alt+A` opens the Anchor Tags panel.
- `Alt+Shift+A` saves the current page position as a tag.
- `Alt+]` cycles to the next tag; `Alt+[` cycles to the previous tag.
- Saving a tag silently connects the tab to the Tab Manager when a slot is available, making the tag eligible for session save/restore.
- Tags are per live tab and clear when the tab closes or navigates unless restored from a saved session.
- A subtle on-page rail shows saved tag positions while you browse.
- Panel supports jump, rename, delete, and undo delete.

### Tab Manager

- Pin up to 4 tabs to numbered slots.
- Pinned tabs that were closed can be recovered with their slot keybind.
- Recovered tabs retry restoring their last known scroll position while the page finishes loading.
- Managed tabs save scroll position while you browse, with a final best-effort save when the page is hidden or closed.
- Jump/cycle with scroll restoration on reopen.
- Swap mode (`W`), rename (`R`), delete (`D`), undo remove (`U`).

### Sessions

- `Alt+S` opens load view.
- `Alt+Shift+S` opens save view directly.
- Save/load up to 4 named Tab Manager sets.
- Sessions snapshot pinned tabs, scroll positions, labels, slot order, and anchor tags for managed tabs.
- Includes overwrite/delete/load confirmations and session preview.

### Help + Navigation

- `Alt+M` opens the help overlay.
- Standard navigation mode always on (`j/k` aliases + arrow keys).
- Half-page jumps in list views: `Ctrl+D` / `Ctrl+U`.

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Alt+T` | Open Tab Manager |
| `Alt+Shift+T` | Add current tab to Tab Manager |
| `Alt+1` — `Alt+4` | Jump to Tab Manager slot 1–4 |
| `Alt+-` | Cycle to previous Tab Manager slot |
| `Alt+=` | Cycle to next Tab Manager slot |
| `Alt+A` | Open Anchor Tags panel |
| `Alt+Shift+A` | Add Anchor Tag at current page position |
| `Alt+[` / `Alt+]` | Cycle previous/next Anchor Tag |
| `Alt+S` | Open session menu |
| `Alt+Shift+S` | Open save session |
| `Alt+M` | Open help menu |

Global and panel keybindings are configurable in the extension options page with per-scope collision detection.

## Quick Start (Development)

### Firefox / Zen

1. `npm run build:firefox`
2. Open `about:debugging` → **This Firefox** → **Load Temporary Add-on**
3. Select `dist/manifest.json`

### Chrome

1. `npm run build:chrome`
2. Open `chrome://extensions` and enable **Developer mode**
3. Click **Load unpacked** and select `dist/`

## Build And Test

Build targets:

| Command | Target | Manifest |
|---------|--------|----------|
| `npm run build` | Firefox (default) | `manifest_v2.json` |
| `npm run build:firefox` | Firefox / Zen | `manifest_v2.json` |
| `npm run build:chrome` | Chrome | `manifest_v3.json` |

Core verification commands:

```sh
npm run lint
npm run test
npm run typecheck
npm run verify:compat
npm run verify:upgrade
npm run verify:store
npm run ci
```

## Promise to myself

- Keyboard-first workflows stay predictable across all panels.
- Native browser primitives first (Shadow DOM + WebExtension APIs).
- Firefox/Chrome parity is maintained through shared contracts and adapters.
- Reliability guardrails (tests + compat/store checks) are part of release quality.

Quick path:

```sh
npm ci
npm run build:firefox
VERSION=$(node -p "require('./package.json').version")
mkdir -p release
(cd dist && zip -qr "../release/harpoon-tabs-firefox-v${VERSION}.xpi" .)
```

## Docs Map

- Build/release runbook and reproducible packaging: `RELEASE.md`
- Store metadata/policy reference: `STORE.md`
- Privacy policy: `PRIVACY.md`

## Project Structure

```text
harpoon-tabs/
├── src/
│   ├── entryPoints/                         # Browser bundle entry points
│   │   ├── backgroundRuntime/               # WebExtension background bootstrap
│   │   ├── contentScript/                   # Page/content-script bootstrap
│   │   ├── optionsPage/                     # Keybinding options UI
│   │   └── toolbarPopup/                    # Browser toolbar popup
│   ├── lib/
│   │   ├── adapters/runtime/                # Typed browser.runtime message clients
│   │   ├── appInit/                         # Content-script wiring, keybinds, message router
│   │   ├── backgroundRuntime/
│   │   │   ├── domains/                     # Stateful background feature domains
│   │   │   ├── handlers/                    # Runtime/command message handlers
│   │   │   └── lifecycle/                   # Startup restore and lifecycle hooks
│   │   ├── common/
│   │   │   ├── contracts/                   # Shared keybinding/runtime message contracts
│   │   │   └── utils/                       # Shared helpers, storage, feedback, panel host
│   │   ├── core/                            # Pure feature logic and testable algorithms
│   │   │   ├── anchorTags/                  # Anchor sorting, cycling, percent calculations
│   │   │   ├── panel/                       # Shared panel list navigation logic
│   │   │   └── sessions/                    # Session planning/reuse logic
│   │   └── ui/
│   │       ├── overlays/                    # Persistent page overlays, like Anchor Tag rail
│   │       └── panels/                      # Shadow DOM panels for features/help/session UI
│   ├── icons/                               # Extension icons
│   └── types.d.ts                           # Shared ambient project types
├── esBuildConfig/
│   ├── build.mjs                            # Shared Firefox/Chrome build script
│   ├── manifest_v2.json                     # Firefox/Zen manifest source
│   ├── manifest_v3.json                     # Chrome manifest source
│   └── verify*.mjs                          # Store, compat, and upgrade verification scripts
├── test/                                    # node:test guardrails for core logic and wiring
├── RELEASE.md                              # Build/release runbook
├── STORE.md                                # Store listing and permission rationale
├── PRIVACY.md                              # Local-only data policy
└── README.md                               # Project overview
```

## License

MIT — see `LICENSE`.
