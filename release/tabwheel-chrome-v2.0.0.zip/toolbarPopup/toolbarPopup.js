"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/entryPoints/toolbarPopup/toolbarPopup.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/tabWheel.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var TABWHEEL_STORAGE_KEYS = {
    settings: "tabWheelSettings",
    scrollMemory: "tabWheelScrollMemory",
    mruState: "tabWheelMruState"
  };
  var TABWHEEL_MODIFIER_KEYS = [
    "alt",
    "ctrl",
    "meta"
  ];
  var TABWHEEL_CYCLE_SCOPES = ["general", "mru"];
  var TABWHEEL_PRESETS = ["precise", "balanced", "fast", "custom"];
  var MIN_WHEEL_SENSITIVITY = 0.5;
  var MAX_WHEEL_SENSITIVITY = 2;
  var MIN_WHEEL_COOLDOWN_MS = 60;
  var MAX_WHEEL_COOLDOWN_MS = 400;
  var MIN_PAGE_SCROLL_SPEED_MULTIPLIER = 0.5;
  var MAX_PAGE_SCROLL_SPEED_MULTIPLIER = 3;
  var MIN_PAGE_SCROLL_VIEWPORT_CAP_RATIO = 0.1;
  var MAX_PAGE_SCROLL_VIEWPORT_CAP_RATIO = 1;
  var MAX_SEARCH_QUERY_LENGTH = 512;
  var TABWHEEL_PRESET_VALUES = {
    precise: {
      wheelSensitivity: 0.8,
      wheelCooldownMs: 220,
      pageScrollSpeedMultiplier: 0.8,
      pageScrollViewportCapRatio: 0.35,
      wheelAcceleration: false,
      overshootGuard: true
    },
    balanced: {
      wheelSensitivity: 1,
      wheelCooldownMs: 160,
      pageScrollSpeedMultiplier: 1,
      pageScrollViewportCapRatio: 1,
      wheelAcceleration: false,
      overshootGuard: true
    },
    fast: {
      wheelSensitivity: 1.35,
      wheelCooldownMs: 90,
      pageScrollSpeedMultiplier: 1.4,
      pageScrollViewportCapRatio: 1,
      wheelAcceleration: true,
      overshootGuard: true
    }
  };
  var DEFAULT_TABWHEEL_SETTINGS = {
    invertScroll: false,
    gestureModifier: "alt",
    gestureWithShift: false,
    allowGesturesInEditableFields: true,
    openNativeNewTabOnLeftClick: false,
    cycleScope: "general",
    skipPinnedTabs: false,
    skipRestrictedPages: true,
    wrapAround: true,
    wheelPreset: "balanced",
    wheelSensitivity: 1,
    wheelCooldownMs: 160,
    pageScrollSpeedMultiplier: 1,
    pageScrollViewportCapRatio: 1,
    wheelAcceleration: false,
    horizontalWheel: true,
    overshootGuard: true
  };
  function normalizeModifierKey(value, fallback) {
    return TABWHEEL_MODIFIER_KEYS.includes(value) ? value : fallback;
  }
  function normalizeShiftRequirement(value) {
    return value === true;
  }
  function normalizeEnabledFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeNumberInRange(value, fallback, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.max(min, Math.min(max, numeric));
  }
  function normalizeSearchQuery(value) {
    if (typeof value !== "string") return "";
    return value.trim().replace(/\s+/g, " ").slice(0, MAX_SEARCH_QUERY_LENGTH);
  }
  function normalizeTabWheelCycleScope(value) {
    return TABWHEEL_CYCLE_SCOPES.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.cycleScope;
  }
  function normalizeWheelPreset(value) {
    return TABWHEEL_PRESETS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.wheelPreset;
  }
  function detectTabWheelPreset(settings) {
    for (const preset of ["precise", "balanced", "fast"]) {
      const presetValues = TABWHEEL_PRESET_VALUES[preset];
      if (settings.wheelSensitivity === presetValues.wheelSensitivity && settings.wheelCooldownMs === presetValues.wheelCooldownMs && settings.pageScrollSpeedMultiplier === presetValues.pageScrollSpeedMultiplier && settings.pageScrollViewportCapRatio === presetValues.pageScrollViewportCapRatio && settings.wheelAcceleration === presetValues.wheelAcceleration && settings.overshootGuard === presetValues.overshootGuard) {
        return preset;
      }
    }
    return "custom";
  }
  function applyTabWheelPreset(settings, preset) {
    if (preset === "custom") return { ...settings, wheelPreset: "custom" };
    return {
      ...settings,
      ...TABWHEEL_PRESET_VALUES[preset],
      wheelPreset: preset
    };
  }
  function normalizeTabWheelSettings(value) {
    if (typeof value !== "object" || value === null) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
    const settings = value;
    const normalizedSettings = {
      invertScroll: settings.invertScroll === true,
      gestureModifier: normalizeModifierKey(
        settings.gestureModifier,
        DEFAULT_TABWHEEL_SETTINGS.gestureModifier
      ),
      gestureWithShift: normalizeShiftRequirement(settings.gestureWithShift),
      allowGesturesInEditableFields: normalizeEnabledFlag(
        settings.allowGesturesInEditableFields,
        DEFAULT_TABWHEEL_SETTINGS.allowGesturesInEditableFields
      ),
      openNativeNewTabOnLeftClick: normalizeEnabledFlag(
        settings.openNativeNewTabOnLeftClick,
        DEFAULT_TABWHEEL_SETTINGS.openNativeNewTabOnLeftClick
      ),
      cycleScope: normalizeTabWheelCycleScope(settings.cycleScope),
      skipPinnedTabs: normalizeEnabledFlag(
        settings.skipPinnedTabs,
        DEFAULT_TABWHEEL_SETTINGS.skipPinnedTabs
      ),
      skipRestrictedPages: normalizeEnabledFlag(
        settings.skipRestrictedPages,
        DEFAULT_TABWHEEL_SETTINGS.skipRestrictedPages
      ),
      wrapAround: normalizeEnabledFlag(
        settings.wrapAround,
        DEFAULT_TABWHEEL_SETTINGS.wrapAround
      ),
      wheelPreset: normalizeWheelPreset(settings.wheelPreset),
      wheelSensitivity: normalizeNumberInRange(
        settings.wheelSensitivity,
        DEFAULT_TABWHEEL_SETTINGS.wheelSensitivity,
        MIN_WHEEL_SENSITIVITY,
        MAX_WHEEL_SENSITIVITY
      ),
      wheelCooldownMs: normalizeNumberInRange(
        settings.wheelCooldownMs,
        DEFAULT_TABWHEEL_SETTINGS.wheelCooldownMs,
        MIN_WHEEL_COOLDOWN_MS,
        MAX_WHEEL_COOLDOWN_MS
      ),
      pageScrollSpeedMultiplier: normalizeNumberInRange(
        settings.pageScrollSpeedMultiplier,
        DEFAULT_TABWHEEL_SETTINGS.pageScrollSpeedMultiplier,
        MIN_PAGE_SCROLL_SPEED_MULTIPLIER,
        MAX_PAGE_SCROLL_SPEED_MULTIPLIER
      ),
      pageScrollViewportCapRatio: normalizeNumberInRange(
        settings.pageScrollViewportCapRatio,
        DEFAULT_TABWHEEL_SETTINGS.pageScrollViewportCapRatio,
        MIN_PAGE_SCROLL_VIEWPORT_CAP_RATIO,
        MAX_PAGE_SCROLL_VIEWPORT_CAP_RATIO
      ),
      wheelAcceleration: normalizeEnabledFlag(
        settings.wheelAcceleration,
        DEFAULT_TABWHEEL_SETTINGS.wheelAcceleration
      ),
      horizontalWheel: normalizeEnabledFlag(
        settings.horizontalWheel,
        DEFAULT_TABWHEEL_SETTINGS.horizontalWheel
      ),
      overshootGuard: normalizeEnabledFlag(
        settings.overshootGuard,
        DEFAULT_TABWHEEL_SETTINGS.overshootGuard
      )
    };
    normalizedSettings.wheelPreset = settings.wheelPreset == null ? detectTabWheelPreset(normalizedSettings) : normalizedSettings.wheelPreset;
    return normalizedSettings;
  }
  function formatTabWheelModifierKey(modifier) {
    if (modifier === "ctrl") return "Ctrl / Control";
    if (modifier === "meta") return "Meta / Command";
    return "Alt / Option";
  }
  function formatTabWheelModifierCombo(modifier, withShift) {
    const baseModifier = formatTabWheelModifierKey(modifier);
    return withShift ? `${baseModifier} + Shift` : baseModifier;
  }
  async function loadTabWheelSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.settings);
      return normalizeTabWheelSettings(data[TABWHEEL_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
  }
  async function saveTabWheelSettings(settings) {
    await import_webextension_polyfill.default.storage.local.set({
      [TABWHEEL_STORAGE_KEYS.settings]: normalizeTabWheelSettings(settings)
    });
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  var DEFAULT_RUNTIME_RETRY_POLICY = {
    retryDelaysMs: [0, 80, 220, 420]
  };
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill2.default.runtime.sendMessage(message);
  }
  async function sendRuntimeMessageWithRetry(message, policy = DEFAULT_RUNTIME_RETRY_POLICY) {
    let lastError = null;
    for (const delay of policy.retryDelaysMs) {
      if (delay > 0) {
        await sleep(delay);
      }
      try {
        return await sendRuntimeMessage(message);
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error(`Runtime message failed: ${message.type}`);
  }

  // src/lib/adapters/runtime/tabWheelApi.ts
  function getTabWheelOverviewWithRetry(windowId, policy = { retryDelaysMs: [0, 90, 240, 450] }) {
    return sendRuntimeMessageWithRetry(
      { type: "TABWHEEL_GET_OVERVIEW", windowId },
      policy
    );
  }
  function cycleTabWheel(direction) {
    return sendRuntimeMessage({
      type: "TABWHEEL_CYCLE",
      direction
    });
  }
  function refreshCurrentTabWheel(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_REFRESH_CURRENT_TAB",
      windowId
    });
  }
  function setTabWheelCycleScope(cycleScope, windowId, options = {}) {
    return sendRuntimeMessage({
      type: "TABWHEEL_SET_CYCLE_SCOPE",
      cycleScope,
      windowId,
      suppressPageStatus: options.suppressPageStatus
    });
  }
  function openTabWheelSearchTab(query, windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_OPEN_SEARCH_TAB",
      query: normalizeSearchQuery(query),
      windowId
    });
  }
  function activateMostRecentTabWheelTab(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_ACTIVATE_MOST_RECENT_TAB",
      windowId
    });
  }
  function closeCurrentTabWheelTabAndActivateRecent(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_CLOSE_CURRENT_TAB_AND_ACTIVATE_RECENT",
      windowId
    });
  }
  function openTabWheelHelp() {
    return sendRuntimeMessage({ type: "TABWHEEL_OPEN_HELP" });
  }

  // src/entryPoints/toolbarPopup/toolbarPopup.ts
  var EXTENSION_TITLE = "Scroll Wheel Tab Switcher";
  function presetLabel(preset) {
    if (preset === "precise") return "Precise";
    if (preset === "fast") return "Fast";
    if (preset === "custom") return "Custom";
    return "Balanced";
  }
  function cycleScopeLabel(scope) {
    return scope === "mru" ? "Most Recently Used" : "Left-To-Right";
  }
  function setSelectOptions(select, values, selected, label) {
    select.innerHTML = values.map((value) => `<option value="${value}" ${value === selected ? "selected" : ""}>${label(value)}</option>`).join("");
  }
  document.addEventListener("DOMContentLoaded", async () => {
    const shortcutEl = document.getElementById("shortcutLabel");
    const shortcutStatusEl = document.getElementById("shortcutStatus");
    const fallbackPanel = document.getElementById("fallbackPanel");
    const toastEl = document.getElementById("popupToast");
    const titlebarTextEl = document.getElementById("titlebarText");
    const refreshTabWheelBtn = document.getElementById("refreshTabWheelBtn");
    const scopeLabel = document.getElementById("scopeLabel");
    const generalModeBtn = document.getElementById("generalModeBtn");
    const mruModeBtn = document.getElementById("mruModeBtn");
    const leftClickActionLabel = document.getElementById("leftClickActionLabel");
    const leftClickSearchBtn = document.getElementById("leftClickSearchBtn");
    const leftClickNativeBtn = document.getElementById("leftClickNativeBtn");
    const prevTabBtn = document.getElementById("prevTabBtn");
    const nextTabBtn = document.getElementById("nextTabBtn");
    const searchForm = document.getElementById("searchForm");
    const searchQueryInput = document.getElementById("searchQueryInput");
    const recentTabBtn = document.getElementById("recentTabBtn");
    const closeRecentBtn = document.getElementById("closeRecentBtn");
    const wheelPresetSelect = document.getElementById("wheelPreset");
    const gestureModifierSelect = document.getElementById("gestureModifier");
    const gestureWithShiftInput = document.getElementById("gestureWithShift");
    const invertScrollInput = document.getElementById("invertScroll");
    const skipPinnedTabsInput = document.getElementById("skipPinnedTabs");
    const skipRestrictedPagesInput = document.getElementById("skipRestrictedPages");
    const wrapAroundInput = document.getElementById("wrapAround");
    const wheelAccelerationInput = document.getElementById("wheelAcceleration");
    const horizontalWheelInput = document.getElementById("horizontalWheel");
    const overshootGuardInput = document.getElementById("overshootGuard");
    const allowEditableInput = document.getElementById("allowGesturesInEditableFields");
    const wheelSensitivityInput = document.getElementById("wheelSensitivity");
    const wheelSensitivityValue = document.getElementById("wheelSensitivityValue");
    const wheelCooldownInput = document.getElementById("wheelCooldownMs");
    const wheelCooldownValue = document.getElementById("wheelCooldownValue");
    const pageScrollSpeedInput = document.getElementById("pageScrollSpeedMultiplier");
    const pageScrollSpeedValue = document.getElementById("pageScrollSpeedValue");
    const pageScrollViewportCapInput = document.getElementById("pageScrollViewportCapRatio");
    const pageScrollViewportCapValue = document.getElementById("pageScrollViewportCapValue");
    const helpBtn = document.getElementById("helpBtn");
    const settingsBtn = document.getElementById("settingsBtn");
    let settings = await loadTabWheelSettings();
    let overview = null;
    let statusTimer = 0;
    function clearStatusTimer() {
      if (statusTimer) window.clearTimeout(statusTimer);
      statusTimer = 0;
    }
    function hideStatus() {
      clearStatusTimer();
      toastEl.classList.remove("is-visible");
      toastEl.textContent = "";
    }
    function showStatus(message, sticky = false) {
      clearStatusTimer();
      toastEl.textContent = message;
      toastEl.classList.add("is-visible");
      if (sticky) return;
      statusTimer = window.setTimeout(() => {
        hideStatus();
      }, 1800);
    }
    async function refreshOverview() {
      overview = await getTabWheelOverviewWithRetry().catch(() => null);
    }
    function renderModeButtons(cycleScope) {
      for (const button of [generalModeBtn, mruModeBtn]) {
        const isActive = button.dataset.cycleScope === cycleScope;
        button.classList.toggle("is-active", isActive);
        button.setAttribute("aria-pressed", String(isActive));
      }
    }
    function renderLeftClickActionButtons() {
      leftClickActionLabel.textContent = settings.openNativeNewTabOnLeftClick ? "Browser Default" : "Tabwheel";
      for (const button of [leftClickSearchBtn, leftClickNativeBtn]) {
        const isNativeNewTabButton = button.dataset.nativeNewTab === "true";
        const isActive = isNativeNewTabButton === settings.openNativeNewTabOnLeftClick;
        button.classList.toggle("is-active", isActive);
        button.setAttribute("aria-pressed", String(isActive));
      }
    }
    function renderState() {
      const gesture = formatTabWheelModifierCombo(settings.gestureModifier, settings.gestureWithShift);
      const cycleScope = overview?.cycleScope || settings.cycleScope;
      shortcutEl.textContent = `Hold ${gesture} and Use Mouse Wheel or Clicks`;
      titlebarTextEl.textContent = EXTENSION_TITLE;
      scopeLabel.textContent = cycleScopeLabel(cycleScope);
      renderModeButtons(cycleScope);
      renderLeftClickActionButtons();
      const arePageShortcutsReady = overview?.contentScriptStatus === "ready";
      fallbackPanel.hidden = arePageShortcutsReady;
      shortcutStatusEl.hidden = !arePageShortcutsReady;
      shortcutStatusEl.textContent = arePageShortcutsReady ? "Wheel switches tab. Left-click opens new tab. Middle-click opens most recent tab. Right-click closes current tab." : "";
    }
    function renderSettings() {
      setSelectOptions(
        wheelPresetSelect,
        TABWHEEL_PRESETS,
        settings.wheelPreset,
        (value) => presetLabel(value)
      );
      setSelectOptions(
        gestureModifierSelect,
        TABWHEEL_MODIFIER_KEYS,
        settings.gestureModifier,
        (value) => formatTabWheelModifierKey(value)
      );
      gestureWithShiftInput.checked = settings.gestureWithShift;
      invertScrollInput.checked = settings.invertScroll;
      skipPinnedTabsInput.checked = settings.skipPinnedTabs;
      skipRestrictedPagesInput.checked = settings.skipRestrictedPages;
      wrapAroundInput.checked = settings.wrapAround;
      wheelAccelerationInput.checked = settings.wheelAcceleration;
      horizontalWheelInput.checked = settings.horizontalWheel;
      overshootGuardInput.checked = settings.overshootGuard;
      allowEditableInput.checked = settings.allowGesturesInEditableFields;
      wheelSensitivityInput.min = String(MIN_WHEEL_SENSITIVITY);
      wheelSensitivityInput.max = String(MAX_WHEEL_SENSITIVITY);
      wheelSensitivityInput.value = String(settings.wheelSensitivity);
      wheelSensitivityValue.textContent = `Wheel distance: ${settings.wheelSensitivity.toFixed(1)}x`;
      wheelCooldownInput.min = String(MIN_WHEEL_COOLDOWN_MS);
      wheelCooldownInput.max = String(MAX_WHEEL_COOLDOWN_MS);
      wheelCooldownInput.value = String(settings.wheelCooldownMs);
      wheelCooldownValue.textContent = `Switch delay: ${Math.round(settings.wheelCooldownMs)}ms`;
      pageScrollSpeedInput.min = String(MIN_PAGE_SCROLL_SPEED_MULTIPLIER);
      pageScrollSpeedInput.max = String(MAX_PAGE_SCROLL_SPEED_MULTIPLIER);
      pageScrollSpeedInput.value = String(settings.pageScrollSpeedMultiplier);
      pageScrollSpeedValue.textContent = `Page speed: ${settings.pageScrollSpeedMultiplier.toFixed(1)}x`;
      pageScrollViewportCapInput.min = String(MIN_PAGE_SCROLL_VIEWPORT_CAP_RATIO);
      pageScrollViewportCapInput.max = String(MAX_PAGE_SCROLL_VIEWPORT_CAP_RATIO);
      pageScrollViewportCapInput.value = String(settings.pageScrollViewportCapRatio);
      pageScrollViewportCapValue.textContent = `Max step: ${Math.round(settings.pageScrollViewportCapRatio * 100)}%`;
    }
    async function refreshAll() {
      settings = await loadTabWheelSettings();
      await refreshOverview();
      renderSettings();
      renderState();
    }
    async function persist(nextSettings) {
      settings = nextSettings;
      await saveTabWheelSettings(settings);
      await refreshAll();
      showStatus("Saved");
    }
    async function runPopupAction(action, successMessage, failureMessage, shouldClose = false) {
      const result = await action().catch(() => ({
        ok: false,
        reason: failureMessage
      }));
      await refreshAll();
      if (!result.ok) {
        showStatus(result.reason || failureMessage);
        return;
      }
      if (shouldClose) {
        window.close();
        return;
      }
      showStatus(successMessage);
    }
    async function setPopupCycleScope(cycleScope) {
      const result = await setTabWheelCycleScope(cycleScope, void 0, {
        suppressPageStatus: true
      }).catch(() => ({
        ok: false,
        reason: "Mode switch failed"
      }));
      await refreshAll();
      showStatus(result.ok ? `Mode: ${cycleScopeLabel(result.cycleScope || cycleScope)}` : result.reason || "Mode switch failed");
    }
    async function refreshCurrentTabWheelState() {
      refreshTabWheelBtn.disabled = true;
      try {
        const result = await refreshCurrentTabWheel();
        settings = await loadTabWheelSettings();
        overview = result.overview || await getTabWheelOverviewWithRetry().catch(() => null);
        renderSettings();
        renderState();
        showStatus(result.ok ? "TabWheel refreshed" : result.reason || "TabWheel cannot run on this page.");
      } catch (_) {
        await refreshAll();
        showStatus("TabWheel refresh failed");
      } finally {
        refreshTabWheelBtn.disabled = false;
      }
    }
    function readSettings() {
      const nextSettings = {
        ...settings,
        wheelPreset: wheelPresetSelect.value,
        gestureModifier: gestureModifierSelect.value,
        gestureWithShift: gestureWithShiftInput.checked,
        invertScroll: invertScrollInput.checked,
        skipPinnedTabs: skipPinnedTabsInput.checked,
        skipRestrictedPages: skipRestrictedPagesInput.checked,
        wrapAround: wrapAroundInput.checked,
        wheelAcceleration: wheelAccelerationInput.checked,
        horizontalWheel: horizontalWheelInput.checked,
        overshootGuard: overshootGuardInput.checked,
        allowGesturesInEditableFields: allowEditableInput.checked,
        wheelSensitivity: Number(wheelSensitivityInput.value),
        wheelCooldownMs: Number(wheelCooldownInput.value),
        pageScrollSpeedMultiplier: Number(pageScrollSpeedInput.value),
        pageScrollViewportCapRatio: Number(pageScrollViewportCapInput.value)
      };
      return {
        ...nextSettings,
        wheelPreset: detectTabWheelPreset(nextSettings)
      };
    }
    [
      gestureModifierSelect,
      gestureWithShiftInput,
      invertScrollInput,
      skipPinnedTabsInput,
      skipRestrictedPagesInput,
      wrapAroundInput,
      wheelAccelerationInput,
      horizontalWheelInput,
      overshootGuardInput,
      allowEditableInput,
      wheelSensitivityInput,
      wheelCooldownInput,
      pageScrollSpeedInput,
      pageScrollViewportCapInput
    ].forEach((control) => {
      control.addEventListener("change", () => void persist(readSettings()));
    });
    wheelPresetSelect.addEventListener("change", () => {
      void persist(applyTabWheelPreset(readSettings(), wheelPresetSelect.value));
    });
    wheelSensitivityInput.addEventListener("input", () => {
      wheelSensitivityValue.textContent = `Wheel distance: ${Number(wheelSensitivityInput.value).toFixed(1)}x`;
      wheelPresetSelect.value = "custom";
    });
    wheelCooldownInput.addEventListener("input", () => {
      wheelCooldownValue.textContent = `Switch delay: ${Math.round(Number(wheelCooldownInput.value))}ms`;
      wheelPresetSelect.value = "custom";
    });
    pageScrollSpeedInput.addEventListener("input", () => {
      pageScrollSpeedValue.textContent = `Page speed: ${Number(pageScrollSpeedInput.value).toFixed(1)}x`;
      wheelPresetSelect.value = "custom";
    });
    pageScrollViewportCapInput.addEventListener("input", () => {
      pageScrollViewportCapValue.textContent = `Max step: ${Math.round(Number(pageScrollViewportCapInput.value) * 100)}%`;
      wheelPresetSelect.value = "custom";
    });
    generalModeBtn.addEventListener("click", () => {
      void setPopupCycleScope("general");
    });
    mruModeBtn.addEventListener("click", () => {
      void setPopupCycleScope("mru");
    });
    leftClickSearchBtn.addEventListener("click", () => {
      if (!settings.openNativeNewTabOnLeftClick) return;
      void persist({ ...readSettings(), openNativeNewTabOnLeftClick: false });
    });
    leftClickNativeBtn.addEventListener("click", () => {
      if (settings.openNativeNewTabOnLeftClick) return;
      void persist({ ...readSettings(), openNativeNewTabOnLeftClick: true });
    });
    prevTabBtn.addEventListener("click", () => {
      void runPopupAction(
        () => cycleTabWheel("prev"),
        "Previous tab",
        "Unable to switch tabs"
      );
    });
    nextTabBtn.addEventListener("click", () => {
      void runPopupAction(
        () => cycleTabWheel("next"),
        "Next tab",
        "Unable to switch tabs"
      );
    });
    searchForm.addEventListener("submit", (event) => {
      event.preventDefault();
      void runPopupAction(
        () => openTabWheelSearchTab(searchQueryInput.value),
        "Opened search",
        "Unable to open search",
        true
      );
    });
    recentTabBtn.addEventListener("click", () => {
      void runPopupAction(
        () => activateMostRecentTabWheelTab(),
        "Most Recent Tab",
        "Recent tab unavailable",
        true
      );
    });
    closeRecentBtn.addEventListener("click", () => {
      void runPopupAction(
        () => closeCurrentTabWheelTabAndActivateRecent(),
        "",
        "Unable to close tab",
        true
      );
    });
    refreshTabWheelBtn.addEventListener("click", () => {
      void refreshCurrentTabWheelState();
    });
    helpBtn.addEventListener("click", async () => {
      const result = await openTabWheelHelp();
      if (!result.ok) {
        showStatus(result.reason || "Help unavailable on this page");
        return;
      }
      window.close();
    });
    settingsBtn.addEventListener("click", () => {
      void import_webextension_polyfill3.default.runtime.openOptionsPage();
      window.close();
    });
    await refreshAll();
  });
})();
