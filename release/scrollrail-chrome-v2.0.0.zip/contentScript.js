"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/appInit/appInit.ts
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/keybindings.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var MAX_TAB_MANAGER_SLOTS = 4;
  var MAX_TAB_MANAGER_TITLE_LENGTH = 60;
  var MAX_ANCHOR_TAGS = 4;
  var MAX_SESSIONS = 4;
  var DEFAULT_KEYBINDINGS = {
    navigationMode: "standard",
    bindings: {
      global: {
        openTabManager: { key: "Alt+T", default: "Alt+T" },
        addTab: { key: "Alt+Shift+T", default: "Alt+Shift+T" },
        jumpSlot1: { key: "Alt+1", default: "Alt+1" },
        jumpSlot2: { key: "Alt+2", default: "Alt+2" },
        jumpSlot3: { key: "Alt+3", default: "Alt+3" },
        jumpSlot4: { key: "Alt+4", default: "Alt+4" },
        cyclePrev: { key: "Alt+-", default: "Alt+-" },
        cycleNext: { key: "Alt+=", default: "Alt+=" },
        openAnchorTags: { key: "Alt+A", default: "Alt+A" },
        addAnchorTag: { key: "Alt+Shift+A", default: "Alt+Shift+A" },
        cycleAnchorPrev: { key: "Alt+[", default: "Alt+[" },
        cycleAnchorNext: { key: "Alt+]", default: "Alt+]" },
        openSessions: { key: "Alt+S", default: "Alt+S" },
        openSessionSave: { key: "Alt+Shift+S", default: "Alt+Shift+S" },
        openHelp: { key: "Alt+M", default: "Alt+M" }
      },
      tabManager: {
        moveUp: { key: "ArrowUp", default: "ArrowUp" },
        moveDown: { key: "ArrowDown", default: "ArrowDown" },
        jump: { key: "Enter", default: "Enter" },
        remove: { key: "D", default: "D" },
        rename: { key: "R", default: "R" },
        swap: { key: "W", default: "W" },
        undo: { key: "U", default: "U" },
        close: { key: "Escape", default: "Escape" }
      },
      anchorTags: {
        moveUp: { key: "ArrowUp", default: "ArrowUp" },
        moveDown: { key: "ArrowDown", default: "ArrowDown" },
        jump: { key: "Enter", default: "Enter" },
        add: { key: "A", default: "A" },
        rename: { key: "R", default: "R" },
        remove: { key: "D", default: "D" },
        undo: { key: "U", default: "U" },
        close: { key: "Escape", default: "Escape" }
      },
      session: {
        focusList: { key: "Tab", default: "Tab" },
        focusSearch: { key: "F", default: "F" },
        clearSearch: { key: "Shift+Space", default: "Shift+Space" },
        rename: { key: "R", default: "R" },
        overwrite: { key: "O", default: "O" },
        confirmYes: { key: "Y", default: "Y" },
        confirmNo: { key: "N", default: "N" }
      }
    }
  };
  var STANDARD_NAV_ALIASES = {
    tabManager: {
      moveUp: ["K"],
      moveDown: ["J"]
    },
    anchorTags: {
      moveUp: ["K"],
      moveDown: ["J"]
    }
  };
  async function loadKeybindings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get("keybindings");
      if (data.keybindings) {
        return mergeWithDefaults(data.keybindings);
      }
    } catch (_) {
    }
    return JSON.parse(JSON.stringify(DEFAULT_KEYBINDINGS));
  }
  function mergeWithDefaults(stored) {
    const merged = JSON.parse(
      JSON.stringify(DEFAULT_KEYBINDINGS)
    );
    merged.navigationMode = "standard";
    for (const scope of Object.keys(merged.bindings)) {
      if (!stored.bindings?.[scope]) continue;
      for (const action of Object.keys(merged.bindings[scope])) {
        const storedBinding = stored.bindings[scope]?.[action];
        if (storedBinding) {
          merged.bindings[scope][action].key = storedBinding.key;
        }
      }
    }
    return merged;
  }
  var KEY_NAME_MAP = {
    ArrowUp: "ArrowUp",
    ArrowDown: "ArrowDown",
    ArrowLeft: "ArrowLeft",
    ArrowRight: "ArrowRight",
    " ": "Space",
    Escape: "Escape",
    Enter: "Enter",
    Tab: "Tab",
    Backspace: "Backspace",
    Delete: "Delete",
    PageUp: "PageUp",
    PageDown: "PageDown",
    Home: "Home",
    End: "End",
    Insert: "Insert"
  };
  var KEY_COMBO_CACHE = /* @__PURE__ */ new Map();
  function normalizeKeyName(keyName) {
    if (KEY_NAME_MAP[keyName]) return KEY_NAME_MAP[keyName];
    if (keyName.length === 1) return keyName.toUpperCase();
    return keyName;
  }
  function parseKeyCombo(keyString) {
    if (!keyString) return null;
    const cached = KEY_COMBO_CACHE.get(keyString);
    if (cached) return cached;
    const parts = keyString.split("+");
    if (parts.length === 0) return null;
    const parsed = {
      key: normalizeKeyName(parts[parts.length - 1]),
      ctrl: false,
      alt: false,
      shift: false,
      meta: false
    };
    for (let i = 0; i < parts.length - 1; i++) {
      if (parts[i] === "Ctrl") parsed.ctrl = true;
      else if (parts[i] === "Alt") parsed.alt = true;
      else if (parts[i] === "Shift") parsed.shift = true;
      else if (parts[i] === "Meta") parsed.meta = true;
    }
    KEY_COMBO_CACHE.set(keyString, parsed);
    return parsed;
  }
  function matchesKey(event, keyString) {
    const parsed = parseKeyCombo(keyString);
    if (!parsed) return false;
    if (event.ctrlKey !== parsed.ctrl) return false;
    if (event.altKey !== parsed.alt) return false;
    if (event.shiftKey !== parsed.shift) return false;
    if (event.metaKey !== parsed.meta) return false;
    return normalizeKeyName(event.key) === parsed.key;
  }
  function matchesAction(event, config, scope, action) {
    const scopeBindings = config.bindings[scope];
    const binding = scopeBindings?.[action];
    if (!binding) return false;
    if (binding.key && matchesKey(event, binding.key)) return true;
    if (config.navigationMode !== "standard") return false;
    const standardAliases = STANDARD_NAV_ALIASES[scope]?.[action];
    if (!standardAliases) return false;
    for (const alias of standardAliases) {
      if (matchesKey(event, alias)) return true;
    }
    return false;
  }
  function keyToDisplay(keyString) {
    if (!keyString) return "Unbound";
    return keyString.replace("ArrowUp", "\u2191").replace("ArrowDown", "\u2193").replace("ArrowLeft", "\u2190").replace("ArrowRight", "\u2192").replace("Escape", "Esc").replace("Delete", "Del").replace("Backspace", "Bksp");
  }

  // src/lib/common/utils/feedback.ts
  function showFeedback(message) {
    const existing = document.getElementById("ht-feedback-toast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "ht-feedback-toast";
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "fixed",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      padding: "8px 20px",
      background: "#2d2d2d",
      color: "#e0e0e0",
      border: "1px solid rgba(255,255,255,0.1)",
      borderRadius: "8px",
      fontFamily: "'SF Mono', 'JetBrains Mono', 'Fira Code', 'Consolas', monospace",
      fontSize: "13px",
      zIndex: "2147483647",
      boxShadow: "0 4px 24px rgba(0,0,0,0.4)",
      transition: "opacity 0.3s",
      opacity: "1"
    });
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      setTimeout(() => toast.remove(), 300);
    }, 1500);
  }

  // src/lib/common/utils/toastMessages.ts
  function pluralize(count, singular, plural = `${singular}s`) {
    return count === 1 ? singular : plural;
  }
  var toastMessages = {
    panelOpenFailed: "Panel failed to open",
    tabManagerActionFailed: "Tab Manager action failed",
    tabManagerSwapFailed: "Swap failed",
    tabManagerJumpFailed: "Jump failed",
    tabManagerAdded: (slot) => `Added to Tab Manager [${slot}]`,
    tabManagerAlreadyAdded: (slot) => `Already in Tab Manager [${slot}]`,
    tabManagerFull: (max) => `Tab Manager full (max ${max})`,
    anchorTagJumpFailed: "Anchor Tag jump failed",
    sessionMenuFailed: "Session menu failed",
    alreadyUsingSavedSessionFromList: (name) => `No changes to save, already saved as "${name}"`,
    sessionLoadPlanFailed: "Failed to prepare session load",
    sessionNotFound: "Session not found",
    sessionSaveFailed: "Save session failed",
    sessionSaveReopenRequired: "Session state changed, reopen Save Session and try again",
    sessionSave: (name) => `Saved session "${name}"`,
    sessionSaveReplacing: (name, replacedName) => `Saved session "${name}" (replaced "${replacedName}")`,
    sessionLoad: (name, count) => `Loaded session "${name}" (${count} ${pluralize(count, "tab")})`,
    sessionRename: (name) => `Renamed session "${name}"`,
    sessionRenameFailed: "Rename failed",
    sessionOverwrite: (name) => `Overwrote session "${name}"`,
    sessionOverwriteFailed: "Overwrite failed",
    sessionRestore: (name, count) => `Restored session "${name}" (${count} ${pluralize(count, "tab")})`
  };

  // src/lib/core/anchorTags/anchorTagsCore.ts
  var ANCHOR_TAG_CYCLE_TOLERANCE_PX = 8;
  function sortAndCompactAnchorTags(entries) {
    return entries.slice().sort((left, right) => {
      if (left.scrollY !== right.scrollY) return left.scrollY - right.scrollY;
      return left.createdAt - right.createdAt;
    }).map((entry, index) => ({
      ...entry,
      slot: index + 1
    }));
  }
  function clampAnchorScrollY(scrollY, maxScrollY) {
    return Math.max(0, Math.min(scrollY, Math.max(0, maxScrollY)));
  }
  function calculateAnchorPagePercent(scrollY, maxScrollY) {
    if (maxScrollY <= 0) return 0;
    const clamped = clampAnchorScrollY(scrollY, maxScrollY);
    return Math.max(0, Math.min(100, Math.round(clamped / maxScrollY * 100)));
  }

  // src/lib/common/utils/panelHost.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/common/utils/helpers.ts
  var HTML_ESCAPE = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  var HTML_ESCAPE_RE = /[&<>"']/;
  function escapeHtml(text) {
    if (!HTML_ESCAPE_RE.test(text)) return text;
    return text.replace(/[&<>"']/g, (character) => HTML_ESCAPE[character]);
  }
  function escapeRegex(text) {
    return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function buildFuzzyPattern(query) {
    const terms = query.trim().split(/\s+/).filter(Boolean);
    if (terms.length === 0) return null;
    const pattern = terms.map(
      (term) => term.split("").map((character) => escapeRegex(character)).join("[^]*?")
    ).join("[^]*?");
    try {
      return new RegExp(pattern, "i");
    } catch (_) {
      return null;
    }
  }
  var DOMAIN_CACHE_MAX = 500;
  var domainCache = /* @__PURE__ */ new Map();
  function cacheDomain(url, value) {
    if (domainCache.size >= DOMAIN_CACHE_MAX) {
      const firstKey = domainCache.keys().next().value;
      if (firstKey !== void 0) domainCache.delete(firstKey);
    }
    domainCache.set(url, value);
    return value;
  }
  function extractDomain(url) {
    const cached = domainCache.get(url);
    if (cached) return cached;
    try {
      return cacheDomain(url, new URL(url).hostname);
    } catch (_) {
      return cacheDomain(url, url.length > 30 ? url.substring(0, 30) + "\u2026" : url);
    }
  }
  var TRACKING_QUERY_PREFIXES = ["utm_"];
  var TRACKING_QUERY_KEYS = /* @__PURE__ */ new Set([
    "fbclid",
    "gclid",
    "mc_cid",
    "mc_eid"
  ]);
  function normalizeUrlForMatch(rawUrl) {
    const trimmed = rawUrl.trim();
    if (!trimmed) return "";
    try {
      const parsed = new URL(trimmed);
      const protocol = parsed.protocol.toLowerCase();
      let hostname = parsed.hostname.toLowerCase();
      if (hostname.startsWith("www.")) hostname = hostname.slice(4);
      const isDefaultPort = protocol === "http:" && parsed.port === "80" || protocol === "https:" && parsed.port === "443";
      const port = parsed.port && !isDefaultPort ? `:${parsed.port}` : "";
      let pathname = parsed.pathname || "/";
      pathname = pathname.replace(/\/{2,}/g, "/");
      if (pathname.length > 1 && pathname.endsWith("/")) pathname = pathname.slice(0, -1);
      const kept = [];
      for (const [key, value] of parsed.searchParams.entries()) {
        const lowerKey = key.toLowerCase();
        if (TRACKING_QUERY_KEYS.has(lowerKey)) continue;
        if (TRACKING_QUERY_PREFIXES.some((prefix) => lowerKey.startsWith(prefix))) continue;
        kept.push([key, value]);
      }
      kept.sort((a, b) => {
        const keyCompare = a[0].localeCompare(b[0]);
        if (keyCompare !== 0) return keyCompare;
        return a[1].localeCompare(b[1]);
      });
      const search = kept.length ? `?${kept.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&")}` : "";
      return `${protocol}//${hostname}${port}${pathname}${search}`;
    } catch (_) {
      return trimmed.toLowerCase().replace(/\/+$/, "");
    }
  }

  // src/lib/common/utils/panelHost.ts
  var activePanelCleanup = null;
  var activePanelFailSafeCleanup = null;
  function invokeCleanupSafely(label, cleanup) {
    if (!cleanup) return;
    try {
      cleanup();
    } catch (error) {
      console.error(`[Anchor Tags] ${label}:`, error);
    }
  }
  function cleanupPanelFailSafe() {
    const cleanup = activePanelFailSafeCleanup;
    activePanelFailSafeCleanup = null;
    invokeCleanupSafely("Panel fail-safe cleanup failed", cleanup);
  }
  function handlePanelRuntimeFault(label, reason) {
    if (!document.getElementById("ht-panel-host")) return;
    console.error(`[Anchor Tags] ${label}; dismissing panel.`, reason);
    dismissPanel();
  }
  var EXTENSION_BASE_URL = import_webextension_polyfill2.default.runtime.getURL("");
  function reasonLooksExtensionScoped(reason) {
    if (!reason) return false;
    if (typeof reason === "string") return reason.includes(EXTENSION_BASE_URL);
    if (typeof reason === "object") {
      const maybeError = reason;
      if (typeof maybeError.stack === "string" && maybeError.stack.includes(EXTENSION_BASE_URL)) {
        return true;
      }
      if (typeof maybeError.message === "string" && maybeError.message.includes(EXTENSION_BASE_URL)) {
        return true;
      }
    }
    return false;
  }
  function isPanelRuntimeFaultFromExtension(event) {
    if (typeof event.filename === "string" && event.filename.startsWith(EXTENSION_BASE_URL)) {
      return true;
    }
    if (reasonLooksExtensionScoped(event.error)) return true;
    return reasonLooksExtensionScoped(event.message);
  }
  function registerPanelCleanup(fn) {
    activePanelCleanup = fn;
  }
  function createPanelHost() {
    if (activePanelCleanup) {
      const cleanup = activePanelCleanup;
      activePanelCleanup = null;
      invokeCleanupSafely("Panel cleanup failed while opening a new panel", cleanup);
    }
    cleanupPanelFailSafe();
    const existing = document.getElementById("ht-panel-host");
    if (existing) existing.remove();
    const host = document.createElement("div");
    host.id = "ht-panel-host";
    host.tabIndex = -1;
    host.style.cssText = "position:fixed;inset:0;z-index:2147483647;pointer-events:auto;overscroll-behavior:contain;isolation:isolate;";
    const shadow = host.attachShadow({ mode: "open" });
    document.body.appendChild(host);
    let lastFocusedInPanel = null;
    let pointerInteractionInPanel = false;
    shadow.addEventListener("focusin", (event) => {
      const target = event.target;
      if (target instanceof HTMLElement) {
        lastFocusedInPanel = target;
      }
    });
    shadow.addEventListener("pointerdown", () => {
      pointerInteractionInPanel = true;
    });
    const onGlobalPointerEnd = () => {
      pointerInteractionInPanel = false;
    };
    window.addEventListener("pointerup", onGlobalPointerEnd, true);
    window.addEventListener("pointercancel", onGlobalPointerEnd, true);
    const focusPreferredPanelTarget = () => {
      if (!document.getElementById("ht-panel-host")) return;
      if (lastFocusedInPanel && shadow.contains(lastFocusedInPanel)) {
        lastFocusedInPanel.focus({ preventScroll: true });
        return;
      }
      host.focus({ preventScroll: true });
    };
    let reclaimId = 0;
    host.addEventListener("focusout", () => {
      cancelAnimationFrame(reclaimId);
      reclaimId = requestAnimationFrame(() => {
        if (document.visibilityState !== "visible") return;
        if (pointerInteractionInPanel) return;
        if (!document.getElementById("ht-panel-host")) return;
        const activeInHostTree = document.activeElement === host || host.contains(document.activeElement);
        const activeInShadow = !!shadow.activeElement && shadow.contains(shadow.activeElement);
        if (!activeInHostTree && !activeInShadow) {
          focusPreferredPanelTarget();
        }
      });
    });
    const onVisibilityChange = () => {
      if (document.visibilityState !== "visible") return;
      if (!document.getElementById("ht-panel-host")) return;
      const activeInHostTree = document.activeElement === host || host.contains(document.activeElement);
      const activeInShadow = !!shadow.activeElement && shadow.contains(shadow.activeElement);
      if (!activeInHostTree && !activeInShadow) {
        focusPreferredPanelTarget();
      }
    };
    document.addEventListener("visibilitychange", onVisibilityChange);
    const onError = (event) => {
      if (!isPanelRuntimeFaultFromExtension(event)) return;
      handlePanelRuntimeFault("Panel runtime error", event.error || event.message);
    };
    const onUnhandledRejection = (event) => {
      if (!reasonLooksExtensionScoped(event.reason)) return;
      handlePanelRuntimeFault("Panel unhandled rejection", event.reason);
    };
    let lastAnimationFrameAt = performance.now();
    let frameProbeId = 0;
    const frameProbe = (ts) => {
      lastAnimationFrameAt = ts;
      frameProbeId = requestAnimationFrame(frameProbe);
    };
    frameProbeId = requestAnimationFrame(frameProbe);
    const watchdogIntervalId = window.setInterval(() => {
      if (!document.getElementById("ht-panel-host")) return;
      if (document.visibilityState !== "visible") return;
      const gapMs = performance.now() - lastAnimationFrameAt;
      if (gapMs > 3e3) {
        handlePanelRuntimeFault("Panel watchdog detected UI stall", { gapMs });
      }
    }, 1e3);
    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onUnhandledRejection);
    activePanelFailSafeCleanup = () => {
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onUnhandledRejection);
      window.removeEventListener("pointerup", onGlobalPointerEnd, true);
      window.removeEventListener("pointercancel", onGlobalPointerEnd, true);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      cancelAnimationFrame(frameProbeId);
      window.clearInterval(watchdogIntervalId);
    };
    return { host, shadow };
  }
  function removePanelHost() {
    cleanupPanelFailSafe();
    const host = document.getElementById("ht-panel-host");
    if (host) host.remove();
    activePanelCleanup = null;
  }
  function dismissPanel() {
    const cleanup = activePanelCleanup;
    activePanelCleanup = null;
    invokeCleanupSafely("Panel cleanup failed during dismiss", cleanup);
    removePanelHost();
  }
  function vimBadgeHtml(config) {
    const _ = config;
    return "";
  }
  function footerHintHtml(hint) {
    const activeClass = hint.active ? " ht-footer-hint-active" : "";
    return `<span class="ht-footer-hint${activeClass}">
    <strong class="ht-footer-key">${escapeHtml(hint.key)}</strong>
    <span class="ht-footer-desc">${escapeHtml(hint.desc)}</span>
  </span>`;
  }
  function footerRowHtml(hints) {
    if (hints.length === 0) return `<div class="ht-footer-row"></div>`;
    const pieces = [];
    for (let i = 0; i < hints.length; i++) {
      if (i > 0) {
        pieces.push(`<span class="ht-footer-sep" aria-hidden="true">|</span>`);
      }
      pieces.push(footerHintHtml(hints[i]));
    }
    return `<div class="ht-footer-row">${pieces.join("")}</div>`;
  }
  function getBaseStyles() {
    return `
    * { margin: 0; padding: 0; box-sizing: border-box; }

    :host {
      all: initial;
      --ht-font-mono: 'SF Mono', 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
      --ht-color-bg: #1e1e1e;
      --ht-color-bg-elevated: #252525;
      --ht-color-bg-soft: #3a3a3c;
      --ht-color-bg-detail-focus: #1a2230;
      --ht-color-bg-detail-focus-header: #1e2a3a;
      --ht-color-bg-code: #1a1a1a;
      --ht-color-text: #e0e0e0;
      --ht-color-text-soft: #c0c0c0;
      --ht-color-text-muted: #808080;
      --ht-color-text-title: #a0a0a0;
      --ht-color-text-detail-focus: #a0c0e0;
      --ht-color-text-dim: #666;
      --ht-color-text-faint: #555;
      --ht-color-text-strong: #fff;
      --ht-color-accent: #0a84ff;
      --ht-color-accent-soft: rgba(10,132,255,0.1);
      --ht-color-accent-active: rgba(10,132,255,0.15);
      --ht-color-accent-soft-strong: rgba(10,132,255,0.12);
      --ht-color-accent-soft-faint: rgba(10,132,255,0.08);
      --ht-color-accent-alt: #af82ff;
      --ht-color-accent-alt-soft: rgba(175,130,255,0.15);
      --ht-color-success: #32d74b;
      --ht-color-tree-cursor: #4ec970;
      --ht-color-tree-cursor-bg: rgba(78,201,112,0.15);
      --ht-color-tree-cursor-bg-soft: rgba(78,201,112,0.18);
      --ht-color-tree-cursor-bg-strong: rgba(78,201,112,0.20);
      --ht-color-danger: #ff5f57;
      --ht-color-warning: #febc2e;
      --ht-color-mark-bg: #f9d45c;
      --ht-color-mark-fg: #1e1e1e;
      --ht-color-border: rgba(255,255,255,0.1);
      --ht-color-border-soft: rgba(255,255,255,0.06);
      --ht-color-border-faint: rgba(255,255,255,0.04);
      --ht-color-border-ultra-faint: rgba(255,255,255,0.03);
      --ht-color-hover: rgba(255,255,255,0.06);
      --ht-color-focus-active: rgba(255,255,255,0.13);
      --ht-color-surface: rgba(255,255,255,0.08);
      --ht-color-surface-dim: rgba(255,255,255,0.04);
      --ht-color-surface-strong: rgba(255,255,255,0.15);
      --ht-shadow-overlay: 0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.05);
      --ht-radius: 10px;
      --ht-input-row-pad-y: 8px;
      --ht-input-row-pad-x: 14px;
      --ht-input-row-pad-x-compact: 10px;
      --ht-input-prompt-gap: 8px;
      --ht-input-prompt-size: 14px;
      --ht-input-prompt-weight: 600;
      --ht-input-font-size: 13px;
      --ht-input-caret-color: var(--ht-color-text-strong);
      --ht-pane-header-pad-y: 5px;
      --ht-pane-header-pad-x: 14px;
      --ht-pane-header-font-size: 11px;
      --ht-pane-header-weight: 500;
      font-family: var(--ht-font-mono);
      font-size: 13px;
      color: var(--ht-color-text);
      -webkit-font-smoothing: antialiased;
      text-rendering: optimizeLegibility;
    }

    .ht-backdrop {
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
      width: 100dvw; height: 100dvh;
      background: rgba(0, 0, 0, 0.55);
    }

    /* Keep every overlay shell truly centered, even if panel-specific
       rules regress or are partially overridden. */
    .ht-tab-manager-container,
    .ht-anchor-tags-container,
    .ht-help-container {
      position: fixed !important;
      top: 50% !important;
      left: 50% !important;
      transform: translate(-50%, -50%) !important;
      margin: 0 !important;
    }

    .ht-titlebar {
      display: flex; align-items: center;
      padding: 10px 14px;
      background: var(--ht-color-bg-soft);
      border-bottom: 1px solid var(--ht-color-border-soft);
      border-radius: var(--ht-radius) var(--ht-radius) 0 0;
      user-select: none;
    }
    .ht-traffic-lights {
      display: flex; gap: 7px; margin-right: 14px; flex-shrink: 0;
    }
    .ht-dot {
      width: 12px; height: 12px; border-radius: 50%;
      cursor: pointer; border: none;
      transition: filter 0.15s;
    }
    .ht-dot:hover { filter: brightness(1.2); }
    .ht-dot-close { background: var(--ht-color-danger); }
    .ht-titlebar-text {
      flex: 1; text-align: center; font-size: 12px;
      color: var(--ht-color-text-title); font-weight: 500;
    }

    /* Reusable UI primitives (input rows + pane headers) for panel consistency */
    .ht-ui-input-wrap {
      display: flex;
      align-items: center;
      padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x);
      border-bottom: 1px solid var(--ht-color-border-soft);
      background: var(--ht-color-bg-elevated);
    }
    .ht-ui-input-prompt {
      color: var(--ht-color-accent);
      margin-right: var(--ht-input-prompt-gap);
      font-weight: var(--ht-input-prompt-weight);
      font-size: var(--ht-input-prompt-size);
    }
    .ht-ui-input-field {
      flex: 1;
      background: transparent;
      border: none;
      outline: none;
      color: var(--ht-color-text);
      font-family: inherit;
      font-size: var(--ht-input-font-size);
      caret-color: var(--ht-input-caret-color);
    }
    input,
    textarea {
      user-select: text;
      -webkit-user-select: text;
    }
    .ht-ui-input-field::placeholder {
      color: var(--ht-color-text-dim);
    }
    .ht-ui-pane-header {
      padding: var(--ht-pane-header-pad-y) var(--ht-pane-header-pad-x);
      font-size: var(--ht-pane-header-font-size);
      color: var(--ht-color-text-muted);
      background: var(--ht-color-bg-elevated);
      border-bottom: 1px solid var(--ht-color-border-faint);
      font-weight: var(--ht-pane-header-weight);
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .ht-ui-pane-header-text {
      flex: 1;
    }
    .ht-ui-pane-header-meta {
      font-size: 10px;
      color: var(--ht-color-text-dim);
      flex-shrink: 0;
    }

    .ht-vim-badge {
      font-size: 9px; font-weight: 700; letter-spacing: 0.5px;
      padding: 2px 6px; border-radius: 4px;
      text-transform: uppercase; flex-shrink: 0;
      line-height: 1; margin-left: 8px;
    }
    .ht-vim-badge.on {
      background: var(--ht-color-success); color: #1a1a1a;
    }
    .ht-vim-badge.off {
      background: var(--ht-color-surface); color: var(--ht-color-text-dim);
    }

    .ht-footer {
      display: flex; gap: 16px; padding: 8px 14px;
      background: var(--ht-color-bg-elevated); border-top: 1px solid var(--ht-color-border-soft);
      font-size: 11px; color: var(--ht-color-text-muted); flex-wrap: wrap;
      border-radius: 0 0 var(--ht-radius) var(--ht-radius); justify-content: center;
    }
    .ht-footer-row {
      display: flex; gap: 8px; justify-content: center; width: 100%; flex-wrap: wrap;
      align-items: center;
    }
    .ht-footer-hint {
      display: inline-flex;
      align-items: baseline;
      gap: 4px;
      white-space: nowrap;
      color: var(--ht-color-text-muted);
    }
    .ht-footer-key {
      color: var(--ht-color-text-soft);
      font-weight: 700;
    }
    .ht-footer-sep {
      color: var(--ht-color-text-dim);
      font-weight: 600;
    }

    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation: none !important;
        transition: none !important;
      }
    }

    @media (max-width: 520px), (max-height: 560px) {
      .ht-ui-input-wrap {
        padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x-compact);
      }
    }
  `;
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());
  var DEFAULT_RUNTIME_RETRY_POLICY = {
    retryDelaysMs: [0, 80, 220, 420]
  };
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill3.default.runtime.sendMessage(message);
  }
  async function sendRuntimeMessageWithRetry(message, policy = DEFAULT_RUNTIME_RETRY_POLICY) {
    let lastError = null;
    for (const delay of policy.retryDelaysMs) {
      if (delay > 0) {
        await sleep(delay);
      }
      try {
        return await sendRuntimeMessage(message);
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error(`Runtime message failed: ${message.type}`);
  }

  // src/lib/adapters/runtime/anchorTagsApi.ts
  function listAnchorTagsWithRetry(policy = { retryDelaysMs: [0, 90, 240, 450] }) {
    return sendRuntimeMessageWithRetry(
      { type: "ANCHOR_TAG_LIST" },
      policy
    );
  }
  function addCurrentAnchorTag() {
    return sendRuntimeMessage({ type: "ANCHOR_TAG_ADD" });
  }
  function removeAnchorTag(slot) {
    return sendRuntimeMessage({ type: "ANCHOR_TAG_REMOVE", slot });
  }
  function renameAnchorTag(slot, label) {
    return sendRuntimeMessage({
      type: "ANCHOR_TAG_RENAME",
      slot,
      label
    });
  }
  function restoreAnchorTag(entry) {
    return sendRuntimeMessage({
      type: "ANCHOR_TAG_RESTORE",
      entry
    });
  }
  function cycleAnchorTag(direction) {
    return sendRuntimeMessage({
      type: "ANCHOR_TAG_CYCLE",
      direction
    });
  }
  function jumpToAnchorTag(slot) {
    return sendRuntimeMessage({ type: "ANCHOR_TAG_JUMP", slot });
  }

  // src/lib/core/panel/panelListController.ts
  function clampPanelListIndex(length, index) {
    if (length <= 0) return -1;
    return Math.max(0, Math.min(length - 1, index));
  }
  function movePanelListIndex(length, currentIndex, delta) {
    if (length <= 0) return -1;
    const safeCurrent = clampPanelListIndex(length, currentIndex);
    return clampPanelListIndex(length, safeCurrent + delta);
  }
  function movePanelListIndexByDirection(length, currentIndex, direction) {
    return movePanelListIndex(length, currentIndex, direction === "down" ? 1 : -1);
  }
  function movePanelListIndexHalfPage(length, currentIndex, halfPageStep, direction) {
    if (length <= 0) return -1;
    const step = Math.max(1, halfPageStep);
    return movePanelListIndex(length, currentIndex, direction === "down" ? step : -step);
  }
  function movePanelListIndexFromWheel(length, currentIndex, wheelDeltaY) {
    if (length <= 0) return -1;
    const direction = wheelDeltaY > 0 ? "down" : "up";
    return movePanelListIndexByDirection(length, currentIndex, direction);
  }
  function resolveVisibleSelection(visibleIndices, selectedIndex) {
    if (visibleIndices.length === 0) return -1;
    if (visibleIndices.includes(selectedIndex)) return selectedIndex;
    return visibleIndices[0];
  }
  function moveVisibleSelection(visibleIndices, selectedIndex, delta) {
    if (visibleIndices.length === 0) return -1;
    const currentPos = Math.max(0, visibleIndices.indexOf(resolveVisibleSelection(visibleIndices, selectedIndex)));
    const nextPos = Math.max(0, Math.min(visibleIndices.length - 1, currentPos + delta));
    return visibleIndices[nextPos];
  }
  function moveVisibleSelectionByDirection(visibleIndices, selectedIndex, direction) {
    return moveVisibleSelection(visibleIndices, selectedIndex, direction === "down" ? 1 : -1);
  }
  function moveVisibleSelectionHalfPage(visibleIndices, selectedIndex, halfPageStep, direction) {
    if (visibleIndices.length === 0) return -1;
    const step = Math.max(1, halfPageStep);
    return moveVisibleSelection(visibleIndices, selectedIndex, direction === "down" ? step : -step);
  }
  function moveVisibleSelectionFromWheel(visibleIndices, selectedIndex, wheelDeltaY) {
    const direction = wheelDeltaY > 0 ? "down" : "up";
    return moveVisibleSelectionByDirection(visibleIndices, selectedIndex, direction);
  }

  // src/lib/ui/panels/anchorTags/anchorTags.css
  var anchorTags_default = "/* Anchor Tags panel \u2014 page-position list and tag management actions */\n\n.ht-anchor-tags-container {\n  position: fixed;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  width: min(520px, calc(100dvw - 32px));\n  max-height: min(560px, calc(100dvh - 32px));\n  background: var(--ht-color-bg);\n  border: 1px solid var(--ht-color-border);\n  border-radius: var(--ht-radius);\n  box-shadow: var(--ht-shadow-overlay);\n  overflow: hidden;\n  display: flex;\n  flex-direction: column;\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n\n.ht-anchor-tags-body {\n  display: flex;\n  flex-direction: column;\n  min-height: 0;\n}\n\n.ht-anchor-tags-list {\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n  padding: 12px;\n  max-height: 360px;\n  overflow: auto;\n}\n\n.ht-anchor-tag-item,\n.ht-anchor-tag-empty {\n  display: grid;\n  grid-template-columns: 30px minmax(0, 1fr) 28px 28px;\n  align-items: center;\n  min-height: 48px;\n  border: 1px solid var(--ht-color-border-soft);\n  border-radius: 8px;\n  background: var(--ht-color-bg-elevated);\n}\n\n.ht-anchor-tag-item {\n  cursor: pointer;\n}\n\n.ht-anchor-tag-empty {\n  grid-template-columns: 30px minmax(0, 1fr);\n  color: var(--ht-color-text-dim);\n  background: var(--ht-color-surface-dim);\n  border-style: dashed;\n}\n\n.ht-anchor-tag-item.active {\n  border-color: var(--ht-color-accent);\n  background: var(--ht-color-accent-soft);\n}\n\n.ht-anchor-tag-slot {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  margin-left: 8px;\n  border-radius: 999px;\n  background: var(--ht-color-surface);\n  color: var(--ht-color-text-strong);\n  font-size: 11px;\n  font-weight: 700;\n}\n\n.ht-anchor-tag-info {\n  min-width: 0;\n  padding: 6px 8px;\n}\n\n.ht-anchor-tag-label {\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  color: var(--ht-color-text);\n  font-size: 13px;\n}\n\n.ht-anchor-tag-meta,\n.ht-anchor-tag-empty-label {\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  color: var(--ht-color-text-muted);\n  font-size: 11px;\n}\n\n.ht-anchor-tag-rename-input {\n  width: 100%;\n  border: 0;\n  outline: 0;\n  background: transparent;\n  color: var(--ht-color-text-strong);\n  font: inherit;\n  border-bottom: 1px solid var(--ht-color-accent);\n}\n\n.ht-anchor-tag-rename,\n.ht-anchor-tag-delete {\n  width: 24px;\n  height: 24px;\n  border: 0;\n  border-radius: 6px;\n  background: transparent;\n  color: var(--ht-color-text-muted);\n  cursor: pointer;\n  font: inherit;\n}\n\n.ht-anchor-tag-rename:hover,\n.ht-anchor-tag-delete:hover {\n  background: var(--ht-color-hover);\n  color: var(--ht-color-text-strong);\n}\n\n.ht-anchor-tag-delete:hover {\n  color: var(--ht-color-danger);\n}\n\n@media (max-width: 640px), (max-height: 560px) {\n  .ht-anchor-tags-container {\n    width: min(96dvw, 520px);\n    max-height: 90dvh;\n    border-radius: 8px;\n  }\n\n  .ht-anchor-tags-list {\n    padding: 10px;\n    max-height: 55dvh;\n  }\n}\n";

  // src/lib/ui/panels/anchorTags/anchorTags.ts
  function getMaxScrollY() {
    const documentElement = document.documentElement;
    const body = document.body;
    const scrollHeight = Math.max(
      documentElement?.scrollHeight || 0,
      body?.scrollHeight || 0,
      documentElement?.offsetHeight || 0,
      body?.offsetHeight || 0
    );
    return Math.max(0, scrollHeight - window.innerHeight);
  }
  function formatAnchorPercent(entry) {
    return `${calculateAnchorPagePercent(entry.scrollY, getMaxScrollY())}%`;
  }
  function buildFooterHtml(config, hasUndo) {
    const upKey = keyToDisplay(config.bindings.anchorTags.moveUp.key);
    const downKey = keyToDisplay(config.bindings.anchorTags.moveDown.key);
    const jumpKey = keyToDisplay(config.bindings.anchorTags.jump.key);
    const addKey = keyToDisplay(config.bindings.anchorTags.add.key);
    const renameKey = keyToDisplay(config.bindings.anchorTags.rename.key);
    const removeKey = keyToDisplay(config.bindings.anchorTags.remove.key);
    const undoKey = keyToDisplay(config.bindings.anchorTags.undo.key);
    const closeKey = keyToDisplay(config.bindings.anchorTags.close.key);
    const navHints = config.navigationMode === "standard" ? [
      { key: "j/k", desc: "nav" },
      { key: `${upKey}/${downKey}`, desc: "nav" }
    ] : [
      { key: `${upKey}/${downKey}`, desc: "nav" }
    ];
    return `${footerRowHtml(navHints)}
    ${footerRowHtml([
      { key: addKey, desc: "add" },
      { key: renameKey, desc: "rename" },
      { key: removeKey, desc: "del" },
      { key: undoKey, desc: "undo", active: hasUndo },
      { key: jumpKey, desc: "jump" },
      { key: closeKey, desc: "close" }
    ])}`;
  }
  async function openAnchorTags(config) {
    try {
      let close2 = function() {
        document.removeEventListener("keydown", keyHandler2, true);
        window.removeEventListener("ht-navigation-mode-changed", onNavigationModeChanged2);
        removePanelHost();
      }, getSelectedTag2 = function() {
        if (tags.length === 0) return null;
        return tags[Math.max(0, Math.min(tags.length - 1, activeIndex))] || null;
      }, onNavigationModeChanged2 = function() {
        render2();
      }, render2 = function() {
        const closeKey = keyToDisplay(config.bindings.anchorTags.close.key);
        let html = `<div class="ht-backdrop"></div>
        <div class="ht-anchor-tags-container">
          <div class="ht-titlebar">
            <div class="ht-traffic-lights">
              <button class="ht-dot ht-dot-close" title="Close (${escapeHtml(closeKey)})"></button>
            </div>
            <span class="ht-titlebar-text">Anchor Tags</span>
            ${vimBadgeHtml(config)}
          </div>
          <div class="ht-anchor-tags-body">
            <div class="ht-anchor-tags-list">`;
        for (let i = 0; i < MAX_ANCHOR_TAGS; i++) {
          const tag = tags[i];
          if (!tag) {
            html += `<div class="ht-anchor-tag-empty" data-index="${i}">
            <span class="ht-anchor-tag-slot">${i + 1}</span>
            <span class="ht-anchor-tag-empty-label">---</span>
          </div>`;
            continue;
          }
          const classes = ["ht-anchor-tag-item"];
          if (i === activeIndex) classes.push("active");
          const labelHtml = renameSlot === tag.slot ? `<input type="text" class="ht-anchor-tag-rename-input" value="${escapeHtml(tag.label)}" maxlength="30" />` : `<div class="ht-anchor-tag-label">${escapeHtml(tag.label)}</div>`;
          html += `<div class="${classes.join(" ")}" data-index="${i}" data-slot="${tag.slot}" tabindex="${i === activeIndex ? "0" : "-1"}">
          <span class="ht-anchor-tag-slot">${tag.slot}</span>
          <div class="ht-anchor-tag-info">
            ${labelHtml}
            <div class="ht-anchor-tag-meta">${formatAnchorPercent(tag)} \xB7 ${escapeHtml(extractDomain(tag.url))}</div>
          </div>
          <button class="ht-anchor-tag-rename" data-slot="${tag.slot}" title="Rename">R</button>
          <button class="ht-anchor-tag-delete" data-slot="${tag.slot}" title="Remove">&times;</button>
        </div>`;
        }
        html += `</div>
            <div class="ht-footer">${buildFooterHtml(config, !!undoEntry)}</div>
          </div>
        </div>`;
        container.innerHTML = html;
        const backdrop = shadow.querySelector(".ht-backdrop");
        const closeBtn = shadow.querySelector(".ht-dot-close");
        const listEl = shadow.querySelector(".ht-anchor-tags-list");
        backdrop.addEventListener("click", close2);
        backdrop.addEventListener("mousedown", (event) => event.preventDefault());
        closeBtn.addEventListener("click", close2);
        shadow.querySelectorAll(".ht-anchor-tag-item").forEach((row) => {
          row.addEventListener("click", (event) => {
            const target = event.target;
            if (target.closest("button") || target.closest("input")) return;
            const index = Number(row.dataset.index);
            if (Number.isNaN(index) || !tags[index]) return;
            activeIndex = index;
            void jumpSelectedTag();
          });
        });
        shadow.querySelectorAll(".ht-anchor-tag-delete").forEach((button) => {
          button.addEventListener("click", (event) => {
            event.stopPropagation();
            const slot = Number(button.dataset.slot);
            if (!Number.isNaN(slot)) void deleteTag(slot);
          });
        });
        shadow.querySelectorAll(".ht-anchor-tag-rename").forEach((button) => {
          button.addEventListener("click", (event) => {
            event.stopPropagation();
            const slot = Number(button.dataset.slot);
            if (Number.isNaN(slot)) return;
            renameSlot = slot;
            render2();
            focusRenameInput2();
          });
        });
        const renameInput = shadow.querySelector(".ht-anchor-tag-rename-input");
        if (renameInput) {
          renameInput.addEventListener("click", (event) => event.stopPropagation());
          renameInput.addEventListener("mousedown", (event) => event.stopPropagation());
        }
        if (listEl) {
          listEl.addEventListener("wheel", (event) => {
            event.preventDefault();
            event.stopPropagation();
            if (tags.length === 0 || renameSlot != null) return;
            activeIndex = movePanelListIndexFromWheel(tags.length, activeIndex, event.deltaY);
            render2();
          });
        }
        const activeEl = shadow.querySelector(".ht-anchor-tag-item.active");
        if (activeEl && renameSlot == null) {
          activeEl.focus({ preventScroll: true });
        }
      }, focusRenameInput2 = function() {
        const input = shadow.querySelector(".ht-anchor-tag-rename-input");
        if (!input) return;
        input.focus();
        input.setSelectionRange(input.value.length, input.value.length);
      }, keyHandler2 = function(event) {
        if (!document.getElementById("ht-panel-host")) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (renameSlot != null) {
          if (matchesAction(event, config, "anchorTags", "close")) {
            event.preventDefault();
            event.stopPropagation();
            renameSlot = null;
            render2();
            return;
          }
          if (matchesAction(event, config, "anchorTags", "jump")) {
            event.preventDefault();
            event.stopPropagation();
            void confirmRename();
            return;
          }
          event.stopPropagation();
          return;
        }
        if (matchesAction(event, config, "anchorTags", "close")) {
          event.preventDefault();
          event.stopPropagation();
          close2();
          return;
        }
        if (matchesAction(event, config, "anchorTags", "add")) {
          event.preventDefault();
          event.stopPropagation();
          void addTag();
          return;
        }
        if (matchesAction(event, config, "anchorTags", "undo")) {
          event.preventDefault();
          event.stopPropagation();
          void undoDelete();
          return;
        }
        if (matchesAction(event, config, "anchorTags", "rename")) {
          event.preventDefault();
          event.stopPropagation();
          const tag = getSelectedTag2();
          if (!tag) return;
          renameSlot = tag.slot;
          render2();
          focusRenameInput2();
          return;
        }
        if (matchesAction(event, config, "anchorTags", "remove")) {
          event.preventDefault();
          event.stopPropagation();
          const tag = getSelectedTag2();
          if (tag) void deleteTag(tag.slot);
          return;
        }
        if (matchesAction(event, config, "anchorTags", "jump")) {
          event.preventDefault();
          event.stopPropagation();
          void jumpSelectedTag();
          return;
        }
        if (matchesAction(event, config, "anchorTags", "moveDown")) {
          event.preventDefault();
          event.stopPropagation();
          if (tags.length > 0) {
            activeIndex = movePanelListIndexByDirection(tags.length, activeIndex, "down");
            render2();
          }
          return;
        }
        if (matchesAction(event, config, "anchorTags", "moveUp")) {
          event.preventDefault();
          event.stopPropagation();
          if (tags.length > 0) {
            activeIndex = movePanelListIndexByDirection(tags.length, activeIndex, "up");
            render2();
          }
          return;
        }
        event.stopPropagation();
      };
      var close = close2, getSelectedTag = getSelectedTag2, onNavigationModeChanged = onNavigationModeChanged2, render = render2, focusRenameInput = focusRenameInput2, keyHandler = keyHandler2;
      const { host, shadow } = createPanelHost();
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + anchorTags_default;
      shadow.appendChild(style);
      const container = document.createElement("div");
      shadow.appendChild(container);
      let tags = await listAnchorTagsWithRetry();
      let activeIndex = 0;
      let undoEntry = null;
      let renameSlot = null;
      async function refreshTags() {
        tags = await listAnchorTagsWithRetry();
        if (tags.length === 0) {
          activeIndex = 0;
        } else {
          activeIndex = Math.max(0, Math.min(tags.length - 1, activeIndex));
        }
        if (renameSlot != null && !tags.some((tag) => tag.slot === renameSlot)) {
          renameSlot = null;
        }
      }
      async function addTag() {
        const result = await addCurrentAnchorTag();
        undoEntry = null;
        if (!result.ok && result.reason) {
          showFeedback(result.reason);
        }
        await refreshTags();
        if (result.slot != null) {
          const nextIndex = tags.findIndex((tag) => tag.slot === result.slot);
          if (nextIndex >= 0) activeIndex = nextIndex;
        }
        render2();
      }
      async function deleteTag(slot) {
        const result = await removeAnchorTag(slot);
        if (result.ok && result.entry) {
          undoEntry = result.entry;
          renameSlot = null;
        } else if (result.reason) {
          showFeedback(result.reason);
        }
        await refreshTags();
        render2();
      }
      async function undoDelete() {
        if (!undoEntry) return;
        const result = await restoreAnchorTag(undoEntry);
        if (result.ok) {
          undoEntry = null;
          showFeedback("Restored Anchor Tag");
        } else if (result.reason) {
          showFeedback(result.reason);
        }
        await refreshTags();
        render2();
      }
      async function confirmRename() {
        if (renameSlot == null) return;
        const input = shadow.querySelector(".ht-anchor-tag-rename-input");
        if (!input) return;
        const nextLabel = input.value.trim();
        if (!nextLabel) {
          showFeedback("Name cannot be empty");
          return;
        }
        const result = await renameAnchorTag(renameSlot, nextLabel);
        if (result.ok) {
          showFeedback("Renamed Anchor Tag");
          renameSlot = null;
        } else if (result.reason) {
          showFeedback(result.reason);
        }
        await refreshTags();
        render2();
      }
      async function jumpSelectedTag() {
        const tag = getSelectedTag2();
        if (!tag) return;
        close2();
        const result = await jumpToAnchorTag(tag.slot);
        if (!result.ok) {
          showFeedback(result.reason || toastMessages.anchorTagJumpFailed);
        }
      }
      document.addEventListener("keydown", keyHandler2, true);
      window.addEventListener("ht-navigation-mode-changed", onNavigationModeChanged2);
      registerPanelCleanup(close2);
      render2();
      host.focus();
    } catch (error) {
      console.error("[Anchor Tags] Failed to open Anchor Tags panel:", error);
      dismissPanel();
    }
  }

  // src/lib/ui/overlays/anchorTagPageOverlay.css
  var anchorTagPageOverlay_default = ":host {\n  all: initial;\n  color-scheme: dark;\n  font-family: 'SF Mono', 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;\n  pointer-events: none;\n}\n\n.ht-anchor-page-rail {\n  position: fixed;\n  top: 12dvh;\n  right: 12px;\n  width: 20px;\n  height: 76dvh;\n  z-index: 2147483644;\n  pointer-events: none;\n  contain: layout style paint;\n  backface-visibility: hidden;\n  will-change: transform, opacity;\n  opacity: 0.88;\n}\n\n.ht-anchor-page-track {\n  position: absolute;\n  top: 0;\n  left: 9px;\n  width: 2px;\n  height: 100%;\n  border-radius: 999px;\n  background: rgba(18, 18, 18, 0.42);\n  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.2);\n}\n\n.ht-anchor-page-marker {\n  position: absolute;\n  left: 50%;\n  display: grid;\n  width: 18px;\n  height: 18px;\n  transform: translate(-50%, -50%);\n  place-items: center;\n  border: 1px solid rgba(255, 255, 255, 0.78);\n  border-radius: 999px;\n  background: rgba(20, 20, 22, 0.92);\n  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.24);\n  color: rgba(255, 255, 255, 0.88);\n  font-size: 10px;\n  font-weight: 700;\n  line-height: 1;\n  transition:\n    background 120ms ease,\n    border-color 120ms ease,\n    color 120ms ease,\n    opacity 120ms ease,\n    transform 120ms ease;\n}\n\n.ht-anchor-page-marker.active {\n  border-color: rgba(74, 222, 128, 0.98);\n  background: rgba(17, 71, 44, 0.96);\n  color: #ffffff;\n  opacity: 1;\n  transform: translate(-50%, -50%) scale(1.16);\n}\n\n.ht-anchor-page-marker.pulse {\n  animation: ht-anchor-page-pulse 720ms ease-out;\n}\n\n@keyframes ht-anchor-page-pulse {\n  0% {\n    box-shadow:\n      0 0 0 0 rgba(74, 222, 128, 0.68),\n      0 4px 14px rgba(0, 0, 0, 0.24);\n  }\n  100% {\n    box-shadow:\n      0 0 0 13px rgba(74, 222, 128, 0),\n      0 4px 14px rgba(0, 0, 0, 0.24);\n  }\n}\n\n@media (max-width: 520px) {\n  .ht-anchor-page-rail {\n    top: 16dvh;\n    right: 7px;\n    height: 68dvh;\n    opacity: 0.78;\n  }\n\n  .ht-anchor-page-marker {\n    width: 16px;\n    height: 16px;\n    font-size: 9px;\n  }\n}\n\n@media (prefers-reduced-motion: reduce) {\n  .ht-anchor-page-marker {\n    transition: none;\n  }\n\n  .ht-anchor-page-marker.pulse {\n    animation: none;\n  }\n}\n\n@media print {\n  .ht-anchor-page-rail {\n    display: none;\n  }\n}\n";

  // src/lib/ui/overlays/anchorTagPageOverlay.ts
  var HOST_ID = "ht-anchor-page-overlay";
  var ACTIVE_PULSE_MS = 720;
  function getMaxScrollY2() {
    const documentElement = document.documentElement;
    const body = document.body;
    const scrollHeight = Math.max(
      documentElement?.scrollHeight || 0,
      body?.scrollHeight || 0,
      documentElement?.offsetHeight || 0,
      body?.offsetHeight || 0
    );
    return Math.max(0, scrollHeight - window.innerHeight);
  }
  function getMountParent() {
    return document.body || document.documentElement;
  }
  function removeExistingHost() {
    const existing = document.getElementById(HOST_ID);
    if (existing) existing.remove();
  }
  function initAnchorTagPageOverlay() {
    removeExistingHost();
    let host = null;
    let shadow = null;
    let tags = [];
    let renderFrame = 0;
    let refreshRequestId = 0;
    let activePulseSlot = null;
    let activePulseTimeout = 0;
    let destroyed = false;
    function ensureHost() {
      if (host && shadow) return shadow;
      host = document.createElement("div");
      host.id = HOST_ID;
      host.style.cssText = [
        "position:fixed",
        "top:0",
        "right:0",
        "width:0",
        "height:0",
        "z-index:2147483644",
        "pointer-events:none",
        "isolation:isolate"
      ].join(";");
      shadow = host.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = anchorTagPageOverlay_default;
      shadow.appendChild(style);
      getMountParent().appendChild(host);
      return shadow;
    }
    function removeHost() {
      if (host) host.remove();
      host = null;
      shadow = null;
    }
    function getActiveSlot() {
      if (activePulseSlot != null) return activePulseSlot;
      if (tags.length === 0) return null;
      const currentScrollY = window.scrollY + ANCHOR_TAG_CYCLE_TOLERANCE_PX;
      let activeTag = tags[0];
      for (const tag of tags) {
        if (tag.scrollY > currentScrollY) break;
        activeTag = tag;
      }
      return activeTag.slot;
    }
    function setActivePulse(slot) {
      window.clearTimeout(activePulseTimeout);
      activePulseSlot = typeof slot === "number" ? slot : null;
      if (activePulseSlot == null) return;
      activePulseTimeout = window.setTimeout(() => {
        activePulseSlot = null;
        scheduleRender();
      }, ACTIVE_PULSE_MS);
    }
    function render() {
      renderFrame = 0;
      if (destroyed) return;
      if (tags.length === 0) {
        removeHost();
        return;
      }
      const nextShadow = ensureHost();
      const maxScrollY = getMaxScrollY2();
      const activeSlot = getActiveSlot();
      const markers = tags.map((tag) => {
        const percent = calculateAnchorPagePercent(tag.scrollY, maxScrollY);
        const classes = ["ht-anchor-page-marker"];
        if (tag.slot === activeSlot) classes.push("active");
        if (tag.slot === activePulseSlot) classes.push("pulse");
        return `<span class="${classes.join(" ")}" style="top:${percent}%" aria-label="Anchor ${tag.slot}: ${escapeHtml(tag.label)}">${tag.slot}</span>`;
      }).join("");
      const currentStyle = nextShadow.querySelector("style");
      nextShadow.innerHTML = "";
      if (currentStyle) nextShadow.appendChild(currentStyle);
      const rail = document.createElement("div");
      rail.className = "ht-anchor-page-rail";
      rail.setAttribute("aria-hidden", "true");
      rail.innerHTML = `<div class="ht-anchor-page-track"></div>${markers}`;
      nextShadow.appendChild(rail);
    }
    function scheduleRender() {
      if (destroyed || renderFrame) return;
      renderFrame = requestAnimationFrame(render);
    }
    function update(entries, activeSlot) {
      if (destroyed) return;
      tags = sortAndCompactAnchorTags(entries).slice(0, 4);
      setActivePulse(activeSlot);
      render();
    }
    async function refresh() {
      const requestId = ++refreshRequestId;
      try {
        const entries = await listAnchorTagsWithRetry();
        if (destroyed || requestId !== refreshRequestId) return;
        update(entries);
      } catch (_) {
        if (!destroyed) update([]);
      }
    }
    function destroy() {
      destroyed = true;
      window.clearTimeout(activePulseTimeout);
      if (renderFrame) cancelAnimationFrame(renderFrame);
      window.removeEventListener("scroll", scheduleRender, true);
      window.removeEventListener("resize", scheduleRender);
      window.removeEventListener("orientationchange", scheduleRender);
      removeHost();
    }
    window.addEventListener("scroll", scheduleRender, { passive: true, capture: true });
    window.addEventListener("resize", scheduleRender);
    window.addEventListener("orientationchange", scheduleRender);
    void refresh();
    return {
      destroy,
      refresh,
      update
    };
  }

  // src/lib/ui/panels/tabManager/tabManager.css
  var tabManager_default = "/* Tab Manager overlay \u2014 panel layout, slot items, swap mode, session inputs */\n\n.ht-tab-manager-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(92vw, 420px); max-height: min(88vh, 620px);\n  background: var(--ht-color-bg); border: 1px solid var(--ht-color-border);\n  border-radius: var(--ht-radius); overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  display: flex; flex-direction: column;\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-tab-manager-container .ht-titlebar-text,\n.ht-session-shell .ht-titlebar-text {\n  font-size: 12px;\n  text-align: center;\n}\n.ht-tab-manager-list { max-height: min(340px, 50vh); overflow-y: auto; }\n.ht-tab-manager-item {\n  display: flex; align-items: center; padding: 8px 14px; gap: 10px;\n  cursor: pointer; border-bottom: 1px solid var(--ht-color-border-faint);\n  transition: background 0.1s, opacity 0.15s;\n  user-select: none; position: relative;\n}\n.ht-tab-manager-item:hover { background: var(--ht-color-border-soft); }\n.ht-tab-manager-item.active { background: var(--ht-color-surface); border-left: 2px solid var(--ht-color-accent); }\n.ht-tab-manager-item.closed { opacity: 0.5; }\n.ht-tab-manager-item.closed .ht-tab-manager-slot { background: var(--ht-color-border-faint); }\n.ht-tab-manager-item.swap-source {\n  background: var(--ht-color-accent-active);\n  border-left: 2px solid var(--ht-color-warning);\n}\n.ht-tab-manager-slot {\n  background: var(--ht-color-surface); color: var(--ht-color-text); width: 22px; height: 22px;\n  border: none; border-radius: 5px;\n  display: flex; align-items: center; justify-content: center;\n  font-weight: 600; font-size: 12px; flex-shrink: 0;\n  pointer-events: none;\n}\n.ht-tab-manager-item.active .ht-tab-manager-slot {\n  background: var(--ht-color-accent); color: var(--ht-color-text-strong);\n}\n.ht-tab-manager-info { flex: 1; min-width: 0; overflow: hidden; }\n.ht-tab-manager-item-title {\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  font-size: 12px; color: var(--ht-color-text);\n}\n.ht-tab-manager-item-url {\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  font-size: 10px; color: var(--ht-color-text-muted); margin-top: 2px;\n}\n.ht-tab-manager-rename-input {\n  width: 100%;\n  border: 0;\n  border-bottom: 1px solid var(--ht-color-accent);\n  outline: 0;\n  background: transparent;\n  color: var(--ht-color-text-strong);\n  font: inherit;\n  font-size: 12px;\n  caret-color: var(--ht-color-accent);\n}\n.ht-tab-manager-rename,\n.ht-tab-manager-delete {\n  color: var(--ht-color-text-muted); cursor: pointer; font-size: 14px; transition: color 0.2s;\n  background: none; border: none; font-family: inherit; padding: 4px;\n  line-height: 1; flex-shrink: 0;\n}\n.ht-tab-manager-rename {\n  font-size: 12px;\n  font-weight: 700;\n}\n.ht-tab-manager-rename:hover { color: var(--ht-color-text-strong); }\n.ht-tab-manager-delete:hover { color: var(--ht-color-danger); }\n.ht-tab-manager-empty {\n  padding: 32px 24px; text-align: center; color: var(--ht-color-text-muted);\n  line-height: 1.6; font-size: 12px;\n}\n.ht-tab-manager-empty-slot {\n  display: flex; align-items: center; padding: 8px 14px; gap: 10px;\n  border-bottom: 1px solid var(--ht-color-border-faint); color: var(--ht-color-text-faint);\n}\n.ht-tab-manager-empty-slot .ht-tab-manager-slot {\n  background: var(--ht-color-border-faint); color: var(--ht-color-text-faint);\n}\n.ht-footer-hint-active { color: var(--ht-color-accent); }\n\n/* Session sub-views (save, list, replace) \u2014 rendered inside Tab Manager */\n.ht-session-input-wrap {\n  display: flex;\n  align-items: center;\n  padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x);\n  border-bottom: 1px solid var(--ht-color-border-soft); background: var(--ht-color-bg-elevated);\n}\n.ht-session-prompt {\n  color: var(--ht-color-accent);\n  margin-right: var(--ht-input-prompt-gap);\n  font-weight: var(--ht-input-prompt-weight);\n  font-size: var(--ht-input-prompt-size);\n}\n.ht-session-input {\n  flex: 1; background: transparent; border: none; outline: none;\n  color: var(--ht-color-text);\n  font-family: inherit;\n  font-size: var(--ht-input-font-size);\n  caret-color: var(--ht-input-caret-color);\n}\n.ht-session-input::placeholder { color: var(--ht-color-text-dim); }\n.ht-session-body {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n  background: var(--ht-color-bg);\n}\n.ht-session-pane-header {\n  padding: var(--ht-pane-header-pad-y) var(--ht-pane-header-pad-x);\n  font-size: var(--ht-pane-header-font-size);\n  color: var(--ht-color-text-muted);\n  background: var(--ht-color-bg-elevated);\n  border-bottom: 1px solid var(--ht-color-border-faint);\n  font-weight: var(--ht-pane-header-weight);\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.ht-session-pane-header-text {\n  flex: 1;\n}\n.ht-session-pane-header-meta {\n  font-size: 10px;\n  color: var(--ht-color-text-dim);\n  flex-shrink: 0;\n}\n.ht-session-filter-wrap {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x);\n  border-bottom: 1px solid var(--ht-color-border-soft);\n  background: var(--ht-color-bg-elevated);\n}\n.ht-session-filter-prompt {\n  color: var(--ht-color-text-muted);\n  font-weight: var(--ht-input-prompt-weight);\n  font-size: var(--ht-input-prompt-size);\n}\n.ht-session-filter-input {\n  flex: 1;\n  background: transparent;\n  border: none;\n  outline: none;\n  color: var(--ht-color-text);\n  font-family: inherit;\n  font-size: var(--ht-input-font-size);\n  caret-color: var(--ht-input-caret-color);\n}\n.ht-session-filter-input::placeholder { color: var(--ht-color-text-dim); }\n.ht-session-item {\n  padding: 5px 14px;\n  cursor: pointer;\n  border-bottom: 1px solid var(--ht-color-border-ultra-faint);\n  transition: background 0.1s;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  display: flex;\n  align-items: baseline;\n  gap: 6px;\n  font-size: 12px;\n  outline: none;\n  height: 28px;\n  box-sizing: border-box;\n  user-select: none;\n}\n.ht-session-item:hover { background: var(--ht-color-border-soft); }\n.ht-session-save-container .ht-session-preview-pane {\n  width: 100%;\n  flex: 1;\n}\n.ht-session-item.active {\n  background: var(--ht-color-accent-active);\n  color: var(--ht-color-text-strong);\n  border-left: 2px solid var(--ht-color-accent);\n}\n.ht-session-list-pane.focused .ht-session-item.active {\n  background: var(--ht-color-focus-active);\n  border-left: 2px solid var(--ht-color-text-strong);\n}\n.ht-session-name {\n  flex: 1;\n  min-width: 0;\n  font-size: 12px;\n  color: var(--ht-color-text);\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n}\n.ht-session-name mark {\n  background: var(--ht-color-mark-bg);\n  color: var(--ht-color-bg);\n  border-radius: 2px;\n  padding: 0 1px;\n}\n.ht-session-meta {\n  font-size: 10px;\n  color: var(--ht-color-text-muted);\n  flex-shrink: 0;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 40%;\n}\n.ht-session-delete {\n  color: var(--ht-color-text-muted); cursor: pointer; font-size: 14px; transition: color 0.2s;\n  background: none; border: none; font-family: inherit; padding: 4px;\n  line-height: 1; flex-shrink: 0;\n}\n.ht-session-delete:hover { color: var(--ht-color-danger); }\n.ht-session-empty {\n  padding: 24px; text-align: center; color: var(--ht-color-text-muted); font-size: 12px;\n}\n.ht-session-rename-input {\n  flex: 1; background: transparent; border: none; border-bottom: 1px solid var(--ht-color-accent);\n  outline: none; color: var(--ht-color-text); font-family: inherit; font-size: 12px;\n  caret-color: var(--ht-color-accent); padding: 0 2px;\n}\n\n.ht-session-list-container {\n  width: min(92vw, 980px);\n  height: min(78vh, 680px);\n  min-height: 300px;\n}\n.ht-session-columns {\n  display: flex;\n  flex: 1;\n  overflow: hidden;\n  background: var(--ht-color-bg);\n}\n.ht-session-list-pane {\n  width: 40%;\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n  border-right: 1px solid var(--ht-color-border-soft);\n  background: var(--ht-color-bg);\n}\n.ht-session-list-scroll {\n  flex: 1;\n  max-height: none;\n  overflow-y: auto;\n}\n.ht-session-preview-pane {\n  width: 60%;\n  background: var(--ht-color-bg);\n}\n.ht-session-preview-list {\n  overflow: hidden;\n  padding: 4px 0;\n}\n.ht-session-preview-item {\n  display: flex;\n  align-items: flex-start;\n  gap: 10px;\n  padding: 1px 12px;\n  border-bottom: 1px solid var(--ht-color-border-ultra-faint);\n}\n.ht-session-preview-slot {\n  width: 20px;\n  height: 20px;\n  border-radius: 4px;\n  background: var(--ht-color-surface);\n  color: var(--ht-color-text-muted);\n  font-size: 11px;\n  font-weight: 600;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-shrink: 0;\n}\n.ht-session-preview-info {\n  min-width: 0;\n  flex: 1;\n}\n.ht-session-preview-title {\n  font-size: 11px;\n  color: var(--ht-color-text);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.ht-session-preview-url {\n  margin-top: 2px;\n  font-size: 10px;\n  color: var(--ht-color-text-muted);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.ht-session-preview-empty {\n  padding: 20px 10px;\n  text-align: center;\n  font-size: 11px;\n  color: var(--ht-color-text-muted);\n}\n.ht-session-confirm {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 10px;\n  padding: 14px 14px 12px;\n  border-bottom: 1px solid var(--ht-color-border-faint);\n  background: var(--ht-color-bg-soft);\n}\n.ht-session-confirm-icon {\n  font-size: 22px;\n  line-height: 1;\n}\n.ht-session-confirm-msg {\n  text-align: center;\n  font-size: 13px;\n  color: var(--ht-color-text);\n  line-height: 1.5;\n}\n.ht-session-confirm-title {\n  color: var(--ht-color-text-strong);\n  font-weight: 600;\n}\n.ht-session-confirm-path {\n  margin-top: 2px;\n  font-size: 11px;\n  color: var(--ht-color-text-muted);\n}\n.ht-session-confirm-details {\n  width: 100%;\n  max-width: 420px;\n  display: grid;\n  gap: 4px;\n  font-size: 11px;\n  color: var(--ht-color-text-muted);\n}\n.ht-session-confirm-hint {\n  font-size: 11px;\n  color: var(--ht-color-text);\n  font-weight: 600;\n}\n.ht-confirm-action {\n  color: var(--ht-color-text-strong);\n  font-weight: 600;\n}\n.ht-confirm-key {\n  font-weight: 700;\n  letter-spacing: 0.2px;\n}\n.ht-confirm-key-yes {\n  color: var(--ht-color-success);\n}\n.ht-confirm-key-no {\n  color: var(--ht-color-danger);\n}\n.ht-session-plan-totals {\n  width: 100%;\n  max-width: 420px;\n  font-size: 11px;\n  color: var(--ht-color-text-muted);\n  text-align: center;\n}\n.ht-session-plan-list {\n  width: 100%;\n  max-width: 420px;\n  background: var(--ht-color-bg-elevated);\n  border: 1px solid var(--ht-color-border-faint);\n  border-radius: 7px;\n  padding: 8px 10px;\n  display: grid;\n  gap: 4px;\n}\n.ht-session-plan-empty {\n  font-size: 10px;\n  color: var(--ht-color-text-faint);\n}\n.ht-session-plan-row {\n  display: grid;\n  grid-template-columns: 12px 20px minmax(0, 1fr);\n  align-items: start;\n  gap: 8px;\n  font-size: 11px;\n  line-height: 1.35;\n}\n.ht-session-plan-sign,\n.ht-session-plan-slot {\n  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;\n}\n.ht-session-plan-sign { font-weight: 700; }\n.ht-session-plan-slot { color: var(--ht-color-text-faint); }\n.ht-session-plan-text {\n  color: var(--ht-color-text);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.ht-session-plan-row-reuse .ht-session-plan-sign { color: var(--ht-color-accent); }\n.ht-session-plan-row-replace .ht-session-plan-sign { color: #ffd58f; }\n.ht-session-plan-row-add .ht-session-plan-sign { color: #89deb0; }\n.ht-session-plan-row-remove .ht-session-plan-sign { color: #ffb4af; }\n\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-tab-manager-container { border-radius: 8px; }\n  .ht-tab-manager-list { max-height: min(58vh, 380px); }\n  .ht-session-input-wrap,\n  .ht-session-filter-wrap {\n    padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x-compact);\n  }\n  .ht-tab-manager-item { padding: 8px 10px; }\n  .ht-session-item { padding: 5px 10px; }\n}\n\n@media (max-width: 860px), (max-height: 620px) {\n  .ht-session-list-container {\n    width: 96vw;\n    height: min(90vh, 760px);\n    min-height: 260px;\n  }\n  .ht-session-columns {\n    flex-direction: column;\n  }\n  .ht-session-list-pane {\n    width: 100%;\n    height: 46%;\n    max-height: none;\n    border-right: none;\n    border-bottom: 1px solid var(--ht-color-border-soft);\n  }\n  .ht-session-preview-pane {\n    width: 100%;\n    height: 54%;\n  }\n}\n";

  // src/lib/adapters/runtime/tabManagerApi.ts
  function listTabManagerEntries() {
    return sendRuntimeMessage({ type: "TAB_MANAGER_LIST" });
  }
  function listTabManagerEntriesWithRetry(policy = { retryDelaysMs: [0, 90, 240, 450] }) {
    return sendRuntimeMessageWithRetry(
      { type: "TAB_MANAGER_LIST" },
      policy
    );
  }
  function addCurrentTabToTabManager() {
    return sendRuntimeMessage({ type: "TAB_MANAGER_ADD" });
  }
  function removeTabManagerEntry(tabId) {
    return sendRuntimeMessage({ type: "TAB_MANAGER_REMOVE", tabId });
  }
  function renameTabManagerEntry(tabId, label) {
    return sendRuntimeMessage({
      type: "TAB_MANAGER_RENAME",
      tabId,
      label
    });
  }
  function jumpToTabManagerSlot(slot) {
    return sendRuntimeMessage({ type: "TAB_MANAGER_JUMP", slot });
  }
  function cycleTabManagerSlot(direction) {
    return sendRuntimeMessage({ type: "TAB_MANAGER_CYCLE", direction });
  }
  function reorderTabManagerEntries(list) {
    return sendRuntimeMessage({ type: "TAB_MANAGER_REORDER", list });
  }

  // src/lib/ui/panels/tabManager/tabManager.ts
  async function openTabManager(config) {
    try {
      let close2 = function() {
        document.removeEventListener("keydown", keyHandler2, true);
        window.removeEventListener("ht-navigation-mode-changed", onNavigationModeChanged2);
        removePanelHost();
      }, failToSafeTabManagerState2 = function(context, error) {
        console.error(`[Anchor Tags] ${context}:`, error);
        showFeedback(toastMessages.tabManagerActionFailed);
        exitSwapMode2();
        try {
          renderTabManager2();
        } catch (renderError) {
          console.error("[Anchor Tags] Failed to recover tab manager panel:", renderError);
          close2();
        }
      }, exitSwapMode2 = function() {
        swapMode = false;
        swapSourceIndex = null;
      }, cancelRename2 = function() {
        renameTabId = null;
      }, buildTabManagerFooterHtml2 = function() {
        const navHints = config.navigationMode === "standard" ? [
          { key: "j/k", desc: "nav" },
          { key: `${moveUpKey}/${moveDownKey}`, desc: "nav" },
          { key: "Ctrl+D/U", desc: "half-page" }
        ] : [
          { key: `${moveUpKey}/${moveDownKey}`, desc: "nav" }
        ];
        return `${footerRowHtml(navHints)}
      ${footerRowHtml([
          { key: undoKey, desc: "undo" },
          { key: renameKey, desc: "rename", active: renameTabId != null },
          { key: swapKey, desc: "swap", active: swapMode },
          { key: removeKey, desc: "del" },
          { key: jumpKey, desc: "jump" },
          { key: closeKey, desc: "close" }
        ])}`;
      }, refreshTabManagerFooter2 = function() {
        const footerEl = shadow.querySelector(".ht-footer");
        if (!footerEl) return;
        footerEl.innerHTML = buildTabManagerFooterHtml2();
      }, onNavigationModeChanged2 = function() {
        refreshTabManagerFooter2();
      }, renderTabManager2 = function() {
        const titleText = renameTabId != null ? "Rename tab label" : !swapMode ? "Tab Manager" : swapSourceIndex === null ? "Select source item" : "Select target to swap";
        let html = `<div class="ht-backdrop"></div>
        <div class="ht-tab-manager-container">
          <div class="ht-titlebar">
            <div class="ht-traffic-lights">
              <button class="ht-dot ht-dot-close" title="Close (${escapeHtml(closeKey)})"></button>
            </div>
            <span class="ht-titlebar-text">${titleText}</span>
            ${vimBadgeHtml(config)}
          </div>
          <div class="ht-tab-manager-list">`;
        for (let i = 0; i < MAX_TAB_MANAGER_SLOTS; i++) {
          const item = list[i];
          if (item) {
            const shortUrl = extractDomain(item.url);
            const classes = ["ht-tab-manager-item"];
            if (i === activeIndex) classes.push("active");
            if (i === swapSourceIndex) classes.push("swap-source");
            if (item.closed) classes.push("closed");
            const titleHtml = renameTabId === item.tabId ? `<input type="text" class="ht-tab-manager-rename-input" value="${escapeHtml(item.title || "Untitled")}" maxlength="${MAX_TAB_MANAGER_TITLE_LENGTH}" />` : `<div class="ht-tab-manager-item-title">${escapeHtml(item.title || "Untitled")}</div>`;
            html += `<div class="${classes.join(" ")}" data-index="${i}">
            <span class="ht-tab-manager-slot">${item.slot}</span>
            <div class="ht-tab-manager-info">
              ${titleHtml}
              <div class="ht-tab-manager-item-url">${escapeHtml(shortUrl)}</div>
            </div>
            <button class="ht-tab-manager-rename" data-tab-id="${item.tabId}" title="Rename">R</button>
            <button class="ht-tab-manager-delete" data-tab-id="${item.tabId}" title="Remove">\xD7</button>
          </div>`;
          } else {
            html += `<div class="ht-tab-manager-empty-slot" data-index="${i}">
            <span class="ht-tab-manager-slot">${i + 1}</span>
            <span>---</span>
          </div>`;
          }
        }
        html += `</div><div class="ht-footer">${buildTabManagerFooterHtml2()}</div></div>`;
        container.innerHTML = html;
        const backdrop = shadow.querySelector(".ht-backdrop");
        const closeBtn = shadow.querySelector(".ht-dot-close");
        backdrop.addEventListener("click", () => {
          if (renameTabId != null) {
            cancelRename2();
            render2();
            return;
          }
          if (swapMode) {
            exitSwapMode2();
            render2();
            return;
          }
          close2();
        });
        backdrop.addEventListener("mousedown", (event) => event.preventDefault());
        closeBtn.addEventListener("click", close2);
        shadow.querySelectorAll(".ht-tab-manager-item").forEach((el) => {
          el.addEventListener("click", (event) => {
            const target = event.target;
            if (target.closest(".ht-tab-manager-delete") || target.closest(".ht-tab-manager-rename") || target.closest(".ht-tab-manager-rename-input")) return;
            const idx = parseInt(el.dataset.index);
            if (!list[idx]) return;
            if (!swapMode) {
              jumpToSlot(list[idx]);
              return;
            }
            performSwapPick2(idx);
          });
        });
        shadow.querySelectorAll(".ht-tab-manager-rename").forEach((el) => {
          el.addEventListener("click", (event) => {
            event.stopPropagation();
            const tabId = parseInt(el.dataset.tabId);
            if (Number.isNaN(tabId)) return;
            renameTabId = tabId;
            exitSwapMode2();
            render2();
            focusRenameInput2();
          });
        });
        shadow.querySelectorAll(".ht-tab-manager-delete").forEach((el) => {
          el.addEventListener("click", async (event) => {
            event.stopPropagation();
            try {
              const tabId = parseInt(el.dataset.tabId);
              const idx = list.findIndex((item) => item.tabId === tabId);
              if (idx !== -1) undoEntry = { entry: { ...list[idx] }, index: idx };
              await removeTabManagerEntry(tabId);
              list = await listTabManagerEntries();
              if (renameTabId === tabId) renameTabId = null;
              activeIndex = Math.min(activeIndex, Math.max(list.length - 1, 0));
              if (swapMode) exitSwapMode2();
              render2();
            } catch (error) {
              failToSafeTabManagerState2("Delete tab-manager entry failed", error);
            }
          });
        });
        const renameInput = shadow.querySelector(".ht-tab-manager-rename-input");
        if (renameInput) {
          renameInput.addEventListener("click", (event) => event.stopPropagation());
          renameInput.addEventListener("mousedown", (event) => event.stopPropagation());
        }
        const activeEl = shadow.querySelector(".ht-tab-manager-item.active");
        if (activeEl && renameTabId == null) activeEl.scrollIntoView({ block: "nearest" });
        const listEl = shadow.querySelector(".ht-tab-manager-list");
        if (listEl) {
          listEl.addEventListener("wheel", (event) => {
            event.preventDefault();
            event.stopPropagation();
            if (list.length === 0) return;
            const next = movePanelListIndexFromWheel(list.length, activeIndex, event.deltaY);
            if (swapMode) {
              activeIndex = next;
              render2();
            } else {
              setActiveIndex2(next);
            }
          });
        }
      }, focusRenameInput2 = function() {
        const input = shadow.querySelector(".ht-tab-manager-rename-input");
        if (!input) return;
        input.focus();
        input.setSelectionRange(input.value.length, input.value.length);
      }, render2 = function() {
        renderTabManager2();
      }, setActiveIndex2 = function(newIndex) {
        if (newIndex === activeIndex) return;
        const tabManagerList = shadow.querySelector(".ht-tab-manager-list");
        if (!tabManagerList) return;
        const prev = tabManagerList.querySelector(".ht-tab-manager-item.active");
        if (prev) prev.classList.remove("active");
        activeIndex = newIndex;
        const next = tabManagerList.querySelector(
          `.ht-tab-manager-item[data-index="${activeIndex}"]`
        );
        if (next) {
          next.classList.add("active");
          next.scrollIntoView({ block: "nearest" });
        }
      }, performSwapPick2 = function(idx) {
        if (swapSourceIndex === null) {
          swapSourceIndex = idx;
          render2();
        } else if (swapSourceIndex === idx) {
          swapSourceIndex = null;
          render2();
        } else {
          const srcIdx = swapSourceIndex;
          const temp = list[srcIdx];
          list[srcIdx] = list[idx];
          list[idx] = temp;
          activeIndex = idx;
          swapSourceIndex = null;
          reorderTabManagerEntries(list).then(() => listTabManagerEntries()).then((fresh) => {
            list = fresh;
            render2();
          }).catch(() => {
            showFeedback(toastMessages.tabManagerSwapFailed);
            exitSwapMode2();
            render2();
          });
        }
      }, getHalfPageStep2 = function() {
        const listEl = shadow.querySelector(".ht-tab-manager-list");
        const itemEl = shadow.querySelector(".ht-tab-manager-item");
        const itemHeight = Math.max(1, itemEl?.offsetHeight ?? 36);
        const rows = Math.max(1, Math.floor((listEl?.clientHeight ?? itemHeight * 6) / itemHeight));
        return Math.max(1, Math.floor(rows / 2));
      }, setIndexWithMode2 = function(newIdx) {
        const bounded = movePanelListIndex(list.length, newIdx, 0);
        if (swapMode) {
          activeIndex = bounded;
          render2();
        } else {
          setActiveIndex2(bounded);
        }
      }, keyHandler2 = function(event) {
        if (!document.getElementById("ht-panel-host")) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (renameTabId != null) {
          if (matchesAction(event, config, "tabManager", "close")) {
            event.preventDefault();
            event.stopPropagation();
            cancelRename2();
            render2();
            return;
          }
          if (matchesAction(event, config, "tabManager", "jump")) {
            event.preventDefault();
            event.stopPropagation();
            void confirmRename();
            return;
          }
          event.stopPropagation();
          return;
        }
        if (config.navigationMode === "standard" && event.ctrlKey && !event.altKey && !event.metaKey) {
          const lowerKey = event.key.toLowerCase();
          if (lowerKey === "d" || lowerKey === "u") {
            event.preventDefault();
            event.stopPropagation();
            if (list.length > 0) {
              const nextIndex = movePanelListIndexHalfPage(
                list.length,
                activeIndex,
                getHalfPageStep2(),
                lowerKey === "d" ? "down" : "up"
              );
              setIndexWithMode2(nextIndex);
            }
            return;
          }
        }
        if (!event.ctrlKey && !event.altKey && !event.shiftKey && !event.metaKey) {
          const num = parseInt(event.key);
          if (num >= 1 && num <= MAX_TAB_MANAGER_SLOTS) {
            event.preventDefault();
            event.stopPropagation();
            const item = list.find((it) => it.slot === num);
            if (item) jumpToSlot(item);
            return;
          }
        }
        if (matchesAction(event, config, "tabManager", "swap")) {
          event.preventDefault();
          event.stopPropagation();
          cancelRename2();
          if (swapMode) {
            exitSwapMode2();
          } else {
            swapMode = true;
            swapSourceIndex = null;
          }
          render2();
          return;
        }
        if (matchesAction(event, config, "tabManager", "close")) {
          event.preventDefault();
          event.stopPropagation();
          if (swapMode) {
            exitSwapMode2();
            render2();
            return;
          }
          close2();
        } else if (matchesAction(event, config, "tabManager", "moveDown")) {
          event.preventDefault();
          event.stopPropagation();
          if (list.length > 0) {
            const newIdx = movePanelListIndexByDirection(list.length, activeIndex, "down");
            if (swapMode) {
              activeIndex = newIdx;
              render2();
            } else {
              setActiveIndex2(newIdx);
            }
          }
        } else if (matchesAction(event, config, "tabManager", "moveUp")) {
          event.preventDefault();
          event.stopPropagation();
          if (list.length > 0) {
            const newIdx = movePanelListIndexByDirection(list.length, activeIndex, "up");
            if (swapMode) {
              activeIndex = newIdx;
              render2();
            } else {
              setActiveIndex2(newIdx);
            }
          }
        } else if (matchesAction(event, config, "tabManager", "jump")) {
          event.preventDefault();
          event.stopPropagation();
          if (swapMode && list[activeIndex]) {
            performSwapPick2(activeIndex);
          } else if (list[activeIndex]) {
            jumpToSlot(list[activeIndex]);
          }
        } else if (matchesAction(event, config, "tabManager", "remove")) {
          event.preventDefault();
          event.stopPropagation();
          if (list[activeIndex]) {
            (async () => {
              try {
                undoEntry = { entry: { ...list[activeIndex] }, index: activeIndex };
                await removeTabManagerEntry(list[activeIndex].tabId);
                list = await listTabManagerEntries();
                cancelRename2();
                activeIndex = Math.min(
                  activeIndex,
                  Math.max(list.length - 1, 0)
                );
                render2();
              } catch (error) {
                failToSafeTabManagerState2("Remove tab-manager entry failed", error);
              }
            })();
          }
        } else if (matchesAction(event, config, "tabManager", "rename")) {
          event.preventDefault();
          event.stopPropagation();
          if (!list[activeIndex]) return;
          renameTabId = list[activeIndex].tabId;
          exitSwapMode2();
          render2();
          focusRenameInput2();
        } else if (matchesAction(event, config, "tabManager", "undo")) {
          event.preventDefault();
          event.stopPropagation();
          if (!undoEntry) return;
          if (list.length >= MAX_TAB_MANAGER_SLOTS) {
            undoEntry = null;
            showFeedback(toastMessages.tabManagerFull(MAX_TAB_MANAGER_SLOTS));
            return;
          }
          (async () => {
            try {
              const restoreIdx = Math.min(undoEntry.index, list.length);
              list.splice(restoreIdx, 0, undoEntry.entry);
              undoEntry = null;
              await reorderTabManagerEntries(list);
              list = await listTabManagerEntries();
              activeIndex = restoreIdx;
              render2();
            } catch (error) {
              failToSafeTabManagerState2("Undo tab-manager remove failed", error);
            }
          })();
        } else {
          event.stopPropagation();
        }
      };
      var close = close2, failToSafeTabManagerState = failToSafeTabManagerState2, exitSwapMode = exitSwapMode2, cancelRename = cancelRename2, buildTabManagerFooterHtml = buildTabManagerFooterHtml2, refreshTabManagerFooter = refreshTabManagerFooter2, onNavigationModeChanged = onNavigationModeChanged2, renderTabManager = renderTabManager2, focusRenameInput = focusRenameInput2, render = render2, setActiveIndex = setActiveIndex2, performSwapPick = performSwapPick2, getHalfPageStep = getHalfPageStep2, setIndexWithMode = setIndexWithMode2, keyHandler = keyHandler2;
      const { host, shadow } = createPanelHost();
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + tabManager_default;
      shadow.appendChild(style);
      const container = document.createElement("div");
      shadow.appendChild(container);
      let list = await listTabManagerEntriesWithRetry();
      let activeIndex = 0;
      let swapMode = false;
      let swapSourceIndex = null;
      let undoEntry = null;
      let renameTabId = null;
      const moveUpKey = keyToDisplay(config.bindings.tabManager.moveUp.key);
      const moveDownKey = keyToDisplay(config.bindings.tabManager.moveDown.key);
      const jumpKey = keyToDisplay(config.bindings.tabManager.jump.key);
      const removeKey = keyToDisplay(config.bindings.tabManager.remove.key);
      const renameKey = keyToDisplay(config.bindings.tabManager.rename.key);
      const swapKey = keyToDisplay(config.bindings.tabManager.swap.key);
      const undoKey = keyToDisplay(config.bindings.tabManager.undo.key);
      const closeKey = keyToDisplay(config.bindings.tabManager.close.key);
      async function confirmRename() {
        if (renameTabId == null) return;
        const input = shadow.querySelector(".ht-tab-manager-rename-input");
        if (!input) return;
        const nextLabel = input.value.trim();
        if (!nextLabel) {
          showFeedback("Name cannot be empty");
          return;
        }
        const result = await renameTabManagerEntry(renameTabId, nextLabel);
        if (result.ok) {
          showFeedback("Renamed Tab Manager entry");
          renameTabId = null;
        } else if (result.reason) {
          showFeedback(result.reason);
        }
        list = await listTabManagerEntries();
        render2();
      }
      async function jumpToSlot(item) {
        if (!item) return;
        close2();
        try {
          await jumpToTabManagerSlot(item.slot);
        } catch (error) {
          console.error("[Anchor Tags] Jump to tab-manager slot failed:", error);
          showFeedback(toastMessages.tabManagerJumpFailed);
        }
      }
      document.addEventListener("keydown", keyHandler2, true);
      window.addEventListener("ht-navigation-mode-changed", onNavigationModeChanged2);
      registerPanelCleanup(close2);
      render2();
      host.focus();
    } catch (err) {
      console.error("[Anchor Tags] Failed to open tab manager overlay:", err);
      dismissPanel();
    }
  }

  // src/lib/common/utils/previewPane.css
  var previewPane_default = '/* Shared preview pane primitives used by session panels. */\n\n.ht-preview-pane {\n  width: 60%;\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n}\n\n.ht-preview-header {\n  padding: var(--ht-pane-header-pad-y) var(--ht-pane-header-pad-x);\n  font-size: var(--ht-pane-header-font-size);\n  color: var(--ht-color-text-muted);\n  background: var(--ht-color-bg-elevated);\n  border-bottom: 1px solid var(--ht-color-border-faint);\n  font-weight: var(--ht-pane-header-weight);\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n\n.ht-preview-content {\n  flex: 1;\n  overflow-y: auto;\n  padding: 12px 14px;\n  font-family: inherit;\n  font-size: 12px;\n  line-height: 1.7;\n  background: var(--ht-color-bg);\n}\n\n.ht-preview-line {\n  color: var(--ht-color-text-muted);\n  display: block;\n  padding: 1px 0;\n}\n\n.ht-preview-line.match {\n  color: var(--ht-color-text);\n  background: var(--ht-color-accent-soft);\n  border-left: 2px solid var(--ht-color-accent);\n  padding-left: 8px;\n  margin-left: -10px;\n}\n\n.ht-preview-line .ht-line-num {\n  display: inline-block;\n  width: 36px;\n  text-align: right;\n  margin-right: 12px;\n  color: var(--ht-color-text-faint);\n  user-select: none;\n}\n\n.ht-preview-line.match .ht-line-num {\n  color: var(--ht-color-accent);\n}\n\n.ht-preview-line mark {\n  background: var(--ht-color-mark-bg);\n  color: var(--ht-color-bg);\n  border-radius: 2px;\n  padding: 0 1px;\n}\n\n.ht-preview-breadcrumb {\n  padding: 4px 14px;\n  font-size: 10px;\n  color: var(--ht-color-text-muted);\n  background: var(--ht-color-bg-elevated);\n  border-bottom: 1px solid var(--ht-color-border-faint);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.ht-preview-breadcrumb .ht-bc-heading {\n  color: var(--ht-color-success);\n  font-weight: 500;\n  flex: 1;\n  min-width: 0;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.ht-preview-breadcrumb .ht-bc-tag {\n  color: var(--ht-color-accent-alt);\n  font-weight: 600;\n  font-size: 9px;\n  background: var(--ht-color-accent-alt-soft);\n  padding: 1px 4px;\n  border-radius: 3px;\n  margin-right: 4px;\n}\n\n.ht-preview-breadcrumb .ht-bc-href {\n  color: var(--ht-color-accent);\n  font-size: 10px;\n  display: block;\n  min-width: 0;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.ht-preview-breadcrumb .ht-bc-row {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  width: 100%;\n  min-width: 0;\n}\n\n.ht-preview-breadcrumb .ht-bc-row + .ht-bc-row {\n  margin-top: 2px;\n}\n\n.ht-preview-breadcrumb .ht-bc-row .ht-bc-tag {\n  flex-shrink: 0;\n}\n\n.ht-preview-code-ctx {\n  background: var(--ht-color-bg-code);\n  border-radius: 4px;\n  padding: 8px 0;\n  margin: 4px 0;\n  font-family: "SF Mono", "Fira Code", "Cascadia Code", monospace;\n  font-size: 11px;\n  line-height: 1.5;\n}\n\n.ht-preview-code-ctx .ht-preview-line {\n  padding: 1px 12px;\n  font-family: inherit;\n}\n\n.ht-preview-code-ctx .ht-preview-line.match {\n  background: var(--ht-color-accent-soft-strong);\n  padding-left: 10px;\n}\n\n.ht-preview-prose-ctx {\n  padding: 4px 0;\n  font-size: 12px;\n  line-height: 1.7;\n}\n\n.ht-preview-placeholder {\n  flex: 1;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: var(--ht-color-text-faint);\n  font-size: 14px;\n  background: var(--ht-color-bg);\n}\n\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-preview-content {\n    padding: 10px;\n  }\n}\n';

  // src/lib/ui/panels/sessionMenu/session.css
  var session_default = ".ht-session-restore-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(92vw, 420px); max-height: min(84vh, 520px);\n  background: var(--ht-color-bg); border: 1px solid var(--ht-color-border);\n  border-radius: var(--ht-radius); overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  display: flex; flex-direction: column;\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-session-restore-list { max-height: 260px; overflow-y: auto; }\n.ht-session-restore-item {\n  display: flex; align-items: center; padding: 8px 14px; gap: 10px;\n  cursor: pointer; border-bottom: 1px solid var(--ht-color-border-faint);\n  transition: background 0.1s; user-select: none;\n}\n.ht-session-restore-item:hover { background: var(--ht-color-border-soft); }\n.ht-session-restore-item.active {\n  background: var(--ht-color-accent-active); border-left: 2px solid var(--ht-color-accent);\n}\n.ht-session-restore-name {\n  flex: 1; font-size: 12px; color: var(--ht-color-text);\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n}\n.ht-session-restore-meta {\n  font-size: 10px; color: var(--ht-color-text-muted); flex-shrink: 0;\n}\n.ht-session-restore-empty {\n  padding: 24px; text-align: center; color: var(--ht-color-text-muted); font-size: 12px;\n}\n\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-session-restore-container { border-radius: 8px; }\n  .ht-session-restore-item { padding: 8px 10px; }\n}\n";

  // src/lib/ui/panels/sessionMenu/sessionMenu.css
  var sessionMenu_default = ".ht-session-menu-container {\n  position: fixed;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  width: min(90dvw, 680px);\n  max-height: min(86dvh, 640px);\n  background: var(--ht-color-bg);\n  border: 1px solid var(--ht-color-border);\n  border-radius: var(--ht-radius);\n  overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  display: flex;\n  flex-direction: column;\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n\n.ht-session-menu-body {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);\n  gap: 12px;\n  padding: 12px 14px 10px;\n  min-height: 260px;\n}\n\n.ht-session-menu-list {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n\n.ht-session-menu-item {\n  border: 1px solid var(--ht-color-border-soft);\n  background: var(--ht-color-surface-dim);\n  border-radius: 8px;\n  padding: 10px 11px;\n  cursor: pointer;\n  user-select: none;\n  transition: background 0.1s, border-color 0.1s;\n}\n\n.ht-session-menu-item:hover {\n  background: var(--ht-color-hover);\n  border-color: var(--ht-color-border);\n}\n\n.ht-session-menu-item.active {\n  background: var(--ht-color-accent-active);\n  border-color: var(--ht-color-accent);\n}\n\n.ht-session-menu-item-title {\n  font-size: 12px;\n  color: var(--ht-color-text-strong);\n}\n\n.ht-session-menu-item-desc {\n  margin-top: 4px;\n  font-size: 11px;\n  color: var(--ht-color-text-soft);\n}\n\n.ht-session-menu-summary {\n  border: 1px solid var(--ht-color-border-soft);\n  background: var(--ht-color-surface-dim);\n  border-radius: 8px;\n  padding: 9px 10px;\n  min-height: 0;\n  display: flex;\n  flex-direction: column;\n}\n\n.ht-session-menu-summary-title {\n  font-size: 11px;\n  color: var(--ht-color-accent);\n  margin-bottom: 6px;\n}\n\n.ht-session-menu-summary-list {\n  min-height: 0;\n  overflow-y: auto;\n}\n\n.ht-session-menu-recent-item {\n  display: flex;\n  justify-content: space-between;\n  gap: 8px;\n  border-bottom: 1px solid var(--ht-color-border-ultra-faint);\n  padding: 5px 0;\n}\n\n.ht-session-menu-recent-item:last-child {\n  border-bottom: none;\n}\n\n.ht-session-menu-recent-name {\n  font-size: 11px;\n  color: var(--ht-color-text);\n  min-width: 0;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.ht-session-menu-recent-meta {\n  flex-shrink: 0;\n  font-size: 10px;\n  color: var(--ht-color-text-muted);\n}\n\n.ht-session-menu-empty {\n  font-size: 11px;\n  color: var(--ht-color-text-muted);\n  padding: 6px 0;\n}\n\n@media (max-width: 860px) {\n  .ht-session-menu-container {\n    width: min(96dvw, 720px);\n    max-height: min(90dvh, 680px);\n  }\n\n  .ht-session-menu-body {\n    grid-template-columns: minmax(0, 1fr);\n    gap: 10px;\n  }\n}\n\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-session-menu-container {\n    border-radius: 8px;\n  }\n\n  .ht-session-menu-body {\n    padding: 10px;\n  }\n}\n";

  // src/lib/core/sessionMenu/sessionCore.ts
  function createSessionTransientState() {
    return {
      isRenameModeActive: false,
      isOverwriteConfirmationActive: false,
      isDeleteConfirmationActive: false,
      isLoadConfirmationActive: false,
      pendingLoadSummary: null,
      pendingLoadSessionName: "",
      pendingDeleteSessionName: "",
      sessionListFocusTarget: "filter"
    };
  }
  function resetSessionTransientState() {
    return createSessionTransientState();
  }
  function withSessionListFocusTarget(state, target) {
    return {
      ...state,
      sessionListFocusTarget: target
    };
  }
  function startSessionRenameMode(state) {
    return {
      ...state,
      isRenameModeActive: true
    };
  }
  function stopSessionRenameMode(state) {
    return {
      ...state,
      isRenameModeActive: false
    };
  }
  function startSessionOverwriteConfirmation(state) {
    return {
      ...state,
      isOverwriteConfirmationActive: true
    };
  }
  function stopSessionOverwriteConfirmation(state) {
    return {
      ...state,
      isOverwriteConfirmationActive: false
    };
  }
  function startSessionLoadConfirmation(state, sessionName, summary) {
    return {
      ...state,
      isLoadConfirmationActive: true,
      pendingLoadSessionName: sessionName,
      pendingLoadSummary: summary,
      isDeleteConfirmationActive: false,
      pendingDeleteSessionName: ""
    };
  }
  function stopSessionLoadConfirmation(state) {
    return {
      ...state,
      isLoadConfirmationActive: false,
      pendingLoadSummary: null,
      pendingLoadSessionName: ""
    };
  }
  function startSessionDeleteConfirmation(state, sessionName) {
    return {
      ...state,
      isRenameModeActive: false,
      isLoadConfirmationActive: false,
      pendingLoadSummary: null,
      pendingLoadSessionName: "",
      isOverwriteConfirmationActive: false,
      isDeleteConfirmationActive: true,
      pendingDeleteSessionName: sessionName
    };
  }
  function stopSessionDeleteConfirmation(state) {
    return {
      ...state,
      isDeleteConfirmationActive: false,
      pendingDeleteSessionName: ""
    };
  }
  function hasActiveSessionConfirmation(state) {
    return state.isLoadConfirmationActive || state.isOverwriteConfirmationActive || state.isDeleteConfirmationActive;
  }
  function deriveSessionListViewModel(sessions, visibleIndices, sessionIndex, filterQuery, transientState) {
    const selectedSessionIndex = visibleIndices.includes(sessionIndex) ? sessionIndex : visibleIndices[0] ?? -1;
    const selectedSession = selectedSessionIndex === -1 ? void 0 : sessions[selectedSessionIndex];
    const pendingDeleteSession = transientState.isDeleteConfirmationActive ? sessions.find((session) => session.name === transientState.pendingDeleteSessionName) || selectedSession : void 0;
    const previewTargetSession = pendingDeleteSession || selectedSession;
    const titleText = filterQuery.trim() ? `Load Sessions (${visibleIndices.length})` : "Load Sessions";
    return {
      selectedSessionIndex,
      selectedSession,
      previewTargetSession,
      titleText,
      shouldSyncSessionIndex: selectedSessionIndex !== sessionIndex
    };
  }

  // src/lib/adapters/runtime/sessionApi.ts
  function listSessions() {
    return sendRuntimeMessage({ type: "SESSION_LIST" });
  }
  function listSessionsWithRetry(policy = { retryDelaysMs: [0, 90, 240, 450] }) {
    return sendRuntimeMessageWithRetry(
      { type: "SESSION_LIST" },
      policy
    );
  }
  function saveSessionByName(name) {
    return sendRuntimeMessage({ type: "SESSION_SAVE", name });
  }
  function loadSessionByName(name) {
    return sendRuntimeMessage({ type: "SESSION_LOAD", name });
  }
  function loadSessionPlanByName(name) {
    return sendRuntimeMessage({ type: "SESSION_LOAD_PLAN", name });
  }
  function deleteSessionByName(name) {
    return sendRuntimeMessage({ type: "SESSION_DELETE", name });
  }
  function renameSession(oldName, newName) {
    return sendRuntimeMessage({ type: "SESSION_RENAME", oldName, newName });
  }
  function updateSession(name) {
    return sendRuntimeMessage({ type: "SESSION_UPDATE", name });
  }
  function replaceSession(oldName, newName) {
    return sendRuntimeMessage({
      type: "SESSION_REPLACE",
      oldName,
      newName
    });
  }

  // src/lib/ui/panels/sessionMenu/sessionView.ts
  function scoreSessionMatch(lowerText, rawText, queryLower, fuzzyRe) {
    if (lowerText === queryLower) return 0;
    if (lowerText.startsWith(queryLower)) return 1;
    if (lowerText.includes(queryLower)) return 2;
    if (fuzzyRe.test(rawText)) return 3;
    return -1;
  }
  function getFilteredSessionIndices(sessions, rawQuery) {
    const trimmedQuery = rawQuery.trim();
    if (!trimmedQuery) return sessions.map((_, index) => index);
    const fuzzyRe = buildFuzzyPattern(trimmedQuery);
    if (!fuzzyRe) return sessions.map((_, index) => index);
    const substringRe = new RegExp(escapeRegex(trimmedQuery), "i");
    const queryLower = trimmedQuery.toLowerCase();
    const ranked = [];
    for (let i = 0; i < sessions.length; i++) {
      const name = sessions[i].name || "";
      if (!(substringRe.test(name) || fuzzyRe.test(name))) continue;
      const score = scoreSessionMatch(name.toLowerCase(), name, queryLower, fuzzyRe);
      if (score < 0) continue;
      ranked.push({ index: i, score, nameLen: name.length });
    }
    ranked.sort((a, b) => {
      if (a.score !== b.score) return a.score - b.score;
      if (a.nameLen !== b.nameLen) return a.nameLen - b.nameLen;
      return a.index - b.index;
    });
    return ranked.map((item) => item.index);
  }
  function pluralize2(count, singular, plural = `${singular}s`) {
    return count === 1 ? singular : plural;
  }
  function buildSessionNameHighlightRegex(rawQuery) {
    const terms = rawQuery.trim().split(/\s+/).filter(Boolean);
    if (terms.length === 0) return null;
    const pattern = terms.map((term) => `(${escapeRegex(escapeHtml(term))})`).join("|");
    try {
      return new RegExp(pattern, "gi");
    } catch (_) {
      return null;
    }
  }
  function highlightSessionName(name, highlightRegex) {
    const escaped = escapeHtml(name);
    if (!highlightRegex) return escaped;
    return escaped.replace(highlightRegex, "<mark>$1</mark>");
  }
  function getSessionListHalfPageStep(shadow) {
    const listEl = shadow.querySelector(".ht-session-list-scroll");
    const itemEl = shadow.querySelector(".ht-session-item");
    const itemHeight = Math.max(1, itemEl?.offsetHeight ?? 34);
    const rows = Math.max(1, Math.floor((listEl?.clientHeight ?? itemHeight * 8) / itemHeight));
    return Math.max(1, Math.floor(rows / 2));
  }
  function buildLoadSummaryHtml(summary, confirmKey, cancelKey) {
    const slotDiffs = Array.isArray(summary.slotDiffs) ? [...summary.slotDiffs].sort((a, b) => a.slot - b.slot) : [];
    const reuseMatches = Array.isArray(summary.reuseMatches) ? summary.reuseMatches : [];
    const reuseBySlot = /* @__PURE__ */ new Map();
    for (const match of reuseMatches) {
      reuseBySlot.set(match.slot, match);
    }
    const renderTabLabel = (title, url) => {
      const display = (title || "").trim() || extractDomain(url || "") || "Untitled";
      return `&ldquo;${escapeHtml(display)}&rdquo;`;
    };
    const planRowsHtml = slotDiffs.length === 0 ? `<div class="ht-session-plan-empty">No slot changes detected.</div>` : slotDiffs.map((row) => {
      const match = reuseBySlot.get(row.slot);
      if (match) {
        return `<div class="ht-session-plan-row ht-session-plan-row-reuse">
          <span class="ht-session-plan-sign">=</span>
          <span class="ht-session-plan-slot">${row.slot}</span>
          <span class="ht-session-plan-text">Session ${renderTabLabel(match.sessionTitle, match.sessionUrl)} &harr; Current ${renderTabLabel(match.openTabTitle, match.openTabUrl)}</span>
        </div>`;
      }
      if (row.change === "replace") {
        return `<div class="ht-session-plan-row ht-session-plan-row-replace">
          <span class="ht-session-plan-sign">~</span>
          <span class="ht-session-plan-slot">${row.slot}</span>
          <span class="ht-session-plan-text">${renderTabLabel(row.currentTitle, row.currentUrl)} &rarr; ${renderTabLabel(row.incomingTitle, row.incomingUrl)}</span>
        </div>`;
      }
      if (row.change === "add") {
        return `<div class="ht-session-plan-row ht-session-plan-row-add">
          <span class="ht-session-plan-sign">+</span>
          <span class="ht-session-plan-slot">${row.slot}</span>
          <span class="ht-session-plan-text">${renderTabLabel(row.incomingTitle, row.incomingUrl)} (new tab)</span>
        </div>`;
      }
      return `<div class="ht-session-plan-row ht-session-plan-row-remove">
        <span class="ht-session-plan-sign">-</span>
        <span class="ht-session-plan-slot">${row.slot}</span>
        <span class="ht-session-plan-text">${renderTabLabel(row.currentTitle, row.currentUrl)} (slot cleared)</span>
      </div>`;
    }).join("");
    return `<div class="ht-session-confirm">
      <div class="ht-session-confirm-icon">&#x21bb;</div>
      <div class="ht-session-confirm-msg">
        Load <span class="ht-session-confirm-title">&ldquo;${escapeHtml(summary.sessionName)}&rdquo;</span>?
        <div class="ht-session-confirm-path">${summary.totalCount} saved ${pluralize2(summary.totalCount, "tab")}</div>
      </div>
      <div class="ht-session-plan-totals">
        NEW <strong>(+)</strong> &middot; DELETED <strong>(-)</strong> &middot; REPLACED <strong>(~)</strong> &middot; UNCHANGED <strong>(=)</strong>
      </div>
      <div class="ht-session-plan-list">${planRowsHtml}</div>
      <div class="ht-session-confirm-hint">
        <span class="ht-confirm-key ht-confirm-key-yes">${escapeHtml(confirmKey)}</span> confirm
        &middot;
        <span class="ht-confirm-key ht-confirm-key-no">${escapeHtml(cancelKey)}</span> cancel
      </div>
    </div>`;
  }
  function buildOverwriteConfirmationHtml(session, confirmKey, cancelKey) {
    const sessionName = session?.name || "session";
    const savedCount = session?.entries.length ?? 0;
    return `<div class="ht-session-confirm">
      <div class="ht-session-confirm-icon">&#x26A0;</div>
      <div class="ht-session-confirm-msg">
        Overwrite <span class="ht-session-confirm-title">&ldquo;${escapeHtml(sessionName)}&rdquo;</span>?
        <div class="ht-session-confirm-path">${savedCount} saved ${pluralize2(savedCount, "tab")} will be replaced</div>
      </div>
      <div class="ht-session-confirm-hint">
        <span class="ht-confirm-key ht-confirm-key-yes">${escapeHtml(confirmKey)}</span> overwrite
        &middot;
        <span class="ht-confirm-key ht-confirm-key-no">${escapeHtml(cancelKey)}</span> cancel
      </div>
    </div>`;
  }
  function buildDeleteConfirmationHtml(session, confirmKey, cancelKey) {
    const sessionName = session?.name || "session";
    const savedCount = session?.entries.length ?? 0;
    return `<div class="ht-session-confirm">
      <div class="ht-session-confirm-icon">&#x26A0;</div>
      <div class="ht-session-confirm-msg">
        Delete <span class="ht-session-confirm-title">&ldquo;${escapeHtml(sessionName)}&rdquo;</span>?
        <div class="ht-session-confirm-path">${savedCount} saved ${pluralize2(savedCount, "tab")} will be removed</div>
      </div>
      <div class="ht-session-confirm-hint">
        <span class="ht-confirm-key ht-confirm-key-yes">${escapeHtml(confirmKey)}</span> delete
        &middot;
        <span class="ht-confirm-key ht-confirm-key-no">${escapeHtml(cancelKey)}</span> cancel
      </div>
    </div>`;
  }
  function buildPreviewEntriesHtml(entries, emptyText) {
    let html = `<div class="ht-session-preview-list">`;
    if (entries.length === 0) {
      html += `<div class="ht-session-preview-empty">${escapeHtml(emptyText)}</div>`;
    } else {
      for (let i = 0; i < entries.length; i++) {
        const entry = entries[i];
        html += `<div class="ht-session-preview-item">
        <span class="ht-session-preview-slot">${i + 1}</span>
        <div class="ht-session-preview-info">
          <div class="ht-session-preview-title">${escapeHtml(entry.title || "Untitled")}</div>
          <div class="ht-session-preview-url">${escapeHtml(extractDomain(entry.url || ""))}</div>
        </div>
      </div>`;
      }
    }
    html += `</div>`;
    return html;
  }
  function buildSessionPreviewHtml(session) {
    if (!session) return "";
    return buildPreviewEntriesHtml(session.entries, "No tabs in this session.");
  }
  function buildSessionPreviewPaneHtml(tabCount, hasPreview, previewHtml, placeholderText) {
    const tabLabel = pluralize2(tabCount, "Tab", "Tabs");
    return `<div class="ht-session-preview-pane ht-preview-pane">
      <div class="ht-preview-header ht-ui-pane-header">
        <span class="ht-session-pane-header-text ht-ui-pane-header-text">Preview - ${tabCount} ${tabLabel}</span>
      </div>
      <div class="ht-preview-placeholder" ${hasPreview ? 'style="display:none;"' : ""}>${escapeHtml(placeholderText)}</div>
      <div class="ht-preview-content" ${hasPreview ? "" : 'style="display:none;"'}>${previewHtml}</div>
    </div>`;
  }
  function buildSaveSessionFooterHtml(config, saveKey, closeKey) {
    return footerRowHtml([
      { key: saveKey, desc: "save" },
      { key: closeKey, desc: "close" }
    ]);
  }
  function buildSessionListFooterHtml(config, transientState) {
    if (hasActiveSessionConfirmation(transientState)) {
      return "";
    }
    const moveUpKey = keyToDisplay(config.bindings.tabManager.moveUp.key);
    const moveDownKey = keyToDisplay(config.bindings.tabManager.moveDown.key);
    const focusListKey = keyToDisplay(config.bindings.session.focusList.key);
    const focusSearchKey = keyToDisplay(config.bindings.session.focusSearch.key);
    const clearSearchKey = keyToDisplay(config.bindings.session.clearSearch.key);
    const renameKey = keyToDisplay(config.bindings.session.rename.key);
    const overwriteKey = keyToDisplay(config.bindings.session.overwrite.key);
    const removeKey = keyToDisplay(config.bindings.tabManager.remove.key);
    const loadKey = keyToDisplay(config.bindings.tabManager.jump.key);
    const closeKey = keyToDisplay(config.bindings.tabManager.close.key);
    const navHints = config.navigationMode === "standard" ? [
      { key: "j/k", desc: "nav" },
      { key: `${moveUpKey}/${moveDownKey}`, desc: "nav" },
      { key: "Ctrl+D/U", desc: "half-page" }
    ] : [
      { key: `${moveUpKey}/${moveDownKey}`, desc: "nav" }
    ];
    return `${footerRowHtml(navHints)}
    ${footerRowHtml([
      { key: focusListKey, desc: "list" },
      { key: focusSearchKey, desc: "search" },
      { key: clearSearchKey, desc: "clear-search" },
      { key: renameKey, desc: "rename" },
      { key: overwriteKey, desc: "overwrite" },
      { key: removeKey, desc: "del" },
      { key: loadKey, desc: "load" },
      { key: closeKey, desc: "close" }
    ])}`;
  }
  function buildReplaceSessionFooterHtml(config) {
    const moveUpKey = keyToDisplay(config.bindings.tabManager.moveUp.key);
    const moveDownKey = keyToDisplay(config.bindings.tabManager.moveDown.key);
    const replaceKey = keyToDisplay(config.bindings.tabManager.jump.key);
    const closeKey = keyToDisplay(config.bindings.tabManager.close.key);
    const navHints = config.navigationMode === "standard" ? [
      { key: "j/k", desc: "nav" },
      { key: `${moveUpKey}/${moveDownKey}`, desc: "nav" }
    ] : [
      { key: `${moveUpKey}/${moveDownKey}`, desc: "nav" }
    ];
    return `${footerRowHtml(navHints)}
    ${footerRowHtml([
      { key: replaceKey, desc: "replace" },
      { key: closeKey, desc: "close" }
    ])}`;
  }

  // src/lib/ui/panels/sessionMenu/session.ts
  var sessionTransientState = createSessionTransientState();
  function resetSessionTransientState2() {
    sessionTransientState = resetSessionTransientState();
  }
  function setSessionTransientState(nextState) {
    sessionTransientState = nextState;
  }
  function reportSessionError(context, feedbackMessage, error) {
    console.error(`[Anchor Tags] ${context}:`, error);
    showFeedback(feedbackMessage);
  }
  async function beginLoadConfirmation(ctx, sessionIdx) {
    const target = ctx.sessions[sessionIdx];
    if (!target) return;
    try {
      const result = await loadSessionPlanByName(target.name);
      if (!result.ok || !result.summary) {
        showFeedback(result.reason || toastMessages.sessionLoadPlanFailed);
        return;
      }
      setSessionTransientState(
        startSessionLoadConfirmation(sessionTransientState, target.name, result.summary)
      );
      ctx.setSessionIndex(sessionIdx);
      ctx.render();
    } catch (error) {
      reportSessionError("Build session load summary failed", "Failed to prepare session load", error);
    }
  }
  async function confirmLoadSession(ctx) {
    if (!sessionTransientState.pendingLoadSessionName) return;
    const target = ctx.sessions.find((session) => session.name === sessionTransientState.pendingLoadSessionName);
    setSessionTransientState(stopSessionLoadConfirmation(sessionTransientState));
    if (!target) {
      showFeedback(toastMessages.sessionNotFound);
      ctx.render();
      return;
    }
    await loadSession(ctx, target);
  }
  function refreshSessionViewFooter(ctx, viewMode) {
    const footerEl = ctx.shadow.querySelector(".ht-footer");
    if (!footerEl) return;
    if (viewMode === "saveSession") {
      const saveKey = keyToDisplay(ctx.config.bindings.tabManager.jump.key);
      const closeKey = keyToDisplay(ctx.config.bindings.tabManager.close.key);
      footerEl.innerHTML = buildSaveSessionFooterHtml(ctx.config, saveKey, closeKey);
      return;
    }
    if (viewMode === "sessionList") {
      footerEl.innerHTML = buildSessionListFooterHtml(ctx.config, sessionTransientState);
      return;
    }
    footerEl.innerHTML = buildReplaceSessionFooterHtml(ctx.config);
  }
  async function renderSaveSession(ctx) {
    const { shadow, container } = ctx;
    const saveKey = keyToDisplay(ctx.config.bindings.tabManager.jump.key);
    const closeKey = keyToDisplay(ctx.config.bindings.tabManager.close.key);
    const [currentSessions, tabManagerEntries] = await Promise.all([
      listSessions(),
      listTabManagerEntries()
    ]);
    ctx.setSessions(currentSessions);
    const count = currentSessions.length;
    const previewHtml = buildPreviewEntriesHtml(tabManagerEntries, "No tabs in Tab Manager.");
    const saveTitleText = count > 0 ? `Save Session (${count})` : "Save Session";
    let html = `<div class="ht-backdrop"></div>
    <div class="ht-tab-manager-container ht-session-list-container ht-session-save-container ht-session-shell">
      <div class="ht-titlebar">
        <div class="ht-traffic-lights">
          <button class="ht-dot ht-dot-close" title="Close (${escapeHtml(closeKey)})"></button>
        </div>
        <span class="ht-titlebar-text">${saveTitleText}</span>
        ${vimBadgeHtml(ctx.config)}
      </div>
      <div class="ht-session-body">
        <div class="ht-session-input-wrap ht-ui-input-wrap">
          <span class="ht-session-prompt ht-ui-input-prompt">Name:</span>
          <input type="text" class="ht-session-input ht-ui-input-field" value="${escapeHtml(ctx.pendingSaveName)}" placeholder="e.g. Research, Debug, Feature..." maxlength="30" />
        </div>
        <div class="ht-session-error" style="display:none; padding: 4px 14px; font-size: 10px; color: #ff5f57;"></div>
        ${buildSessionPreviewPaneHtml(
      tabManagerEntries.length,
      tabManagerEntries.length > 0,
      previewHtml,
      "No tabs in Tab Manager."
    )}
        <div class="ht-footer">
          ${buildSaveSessionFooterHtml(ctx.config, saveKey, closeKey)}
        </div>
      </div>
    </div>`;
    container.innerHTML = html;
    const backdrop = shadow.querySelector(".ht-backdrop");
    const closeBtn = shadow.querySelector(".ht-dot-close");
    const input = shadow.querySelector(".ht-session-input");
    backdrop.addEventListener("click", () => {
      ctx.close();
    });
    backdrop.addEventListener("mousedown", (event) => event.preventDefault());
    closeBtn.addEventListener("click", () => {
      ctx.close();
    });
    input.addEventListener("input", () => {
      ctx.setPendingSaveName(input.value);
    });
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
  }
  function renderSessionList(ctx) {
    const { shadow, container, config, sessions } = ctx;
    const visibleIndices = getFilteredSessionIndices(sessions, ctx.sessionFilterQuery);
    const highlightRegex = buildSessionNameHighlightRegex(ctx.sessionFilterQuery);
    const listModel = deriveSessionListViewModel(
      sessions,
      visibleIndices,
      ctx.sessionIndex,
      ctx.sessionFilterQuery,
      sessionTransientState
    );
    const selectedSessionIndex = listModel.selectedSessionIndex;
    if (listModel.shouldSyncSessionIndex) {
      ctx.setSessionIndex(selectedSessionIndex);
    }
    const selectedSession = listModel.selectedSession;
    const previewTargetSession = listModel.previewTargetSession;
    const titleText = listModel.titleText;
    const closeKey = keyToDisplay(config.bindings.tabManager.close.key);
    const confirmYesKey = keyToDisplay(config.bindings.session.confirmYes.key);
    const confirmNoKey = keyToDisplay(config.bindings.session.confirmNo.key);
    let html = `<div class="ht-backdrop"></div>
    <div class="ht-tab-manager-container ht-session-list-container ht-session-shell">
      <div class="ht-titlebar">
        <div class="ht-traffic-lights">
          <button class="ht-dot ht-dot-close" title="Close (${escapeHtml(closeKey)})"></button>
        </div>
        <span class="ht-titlebar-text">${titleText}</span>
        ${vimBadgeHtml(ctx.config)}
      </div>
      <div class="ht-session-body">
        <div class="ht-session-filter-wrap ht-ui-input-wrap">
          <span class="ht-session-filter-prompt ht-ui-input-prompt">&gt;</span>
          <input
            type="text"
            class="ht-session-filter-input ht-ui-input-field"
            placeholder="Search Sessions . . ."
            value="${escapeHtml(ctx.sessionFilterQuery)}"
            maxlength="40"
          />
        </div>
        <div class="ht-session-columns">
          <div class="ht-session-list-pane">
            <div class="ht-tab-manager-list ht-session-list-scroll">`;
    if (sessions.length === 0) {
      html += `<div class="ht-session-empty">No saved sessions</div>`;
    } else if (visibleIndices.length === 0) {
      html += `<div class="ht-session-empty">No matching sessions</div>`;
    } else {
      for (const globalIdx of visibleIndices) {
        const s = sessions[globalIdx];
        const cls = globalIdx === selectedSessionIndex ? "ht-session-item active" : "ht-session-item";
        const itemTabIndex = globalIdx === selectedSessionIndex ? "0" : "-1";
        const date = new Date(s.savedAt).toLocaleDateString();
        const nameContent = sessionTransientState.isRenameModeActive && globalIdx === selectedSessionIndex ? `<input type="text" class="ht-session-rename-input" value="${escapeHtml(s.name)}" maxlength="30" />` : `<div class="ht-session-name">${highlightSessionName(s.name, highlightRegex)}</div>`;
        html += `<div class="${cls}" data-index="${globalIdx}" tabindex="${itemTabIndex}" role="button" aria-selected="${globalIdx === selectedSessionIndex ? "true" : "false"}">
        ${nameContent}
        <span class="ht-session-meta">${s.entries.length} tabs \xB7 ${date}</span>
        <button class="ht-session-delete" data-index="${globalIdx}" title="Delete" tabindex="-1">\xD7</button>
      </div>`;
      }
    }
    const previewContent = sessionTransientState.isLoadConfirmationActive && sessionTransientState.pendingLoadSummary ? `${buildLoadSummaryHtml(sessionTransientState.pendingLoadSummary, confirmYesKey, confirmNoKey)}${buildSessionPreviewHtml(selectedSession)}` : sessionTransientState.isOverwriteConfirmationActive ? `${buildOverwriteConfirmationHtml(selectedSession, confirmYesKey, confirmNoKey)}${buildSessionPreviewHtml(selectedSession)}` : sessionTransientState.isDeleteConfirmationActive ? `${buildDeleteConfirmationHtml(previewTargetSession, confirmYesKey, confirmNoKey)}${buildSessionPreviewHtml(previewTargetSession)}` : buildSessionPreviewHtml(selectedSession);
    html += `</div>
          </div>
          ${buildSessionPreviewPaneHtml(
      previewTargetSession?.entries.length ?? 0,
      !!previewTargetSession,
      previewContent,
      "Select a session to preview its tabs."
    )}
        </div>`;
    const footerHtml = buildSessionListFooterHtml(config, sessionTransientState);
    html += `${footerHtml ? `<div class="ht-footer">${footerHtml}</div>` : ""}
    </div>
    </div>`;
    container.innerHTML = html;
    const backdrop = shadow.querySelector(".ht-backdrop");
    const closeBtn = shadow.querySelector(".ht-dot-close");
    const filterInput = shadow.querySelector(".ht-session-filter-input");
    const listPane = shadow.querySelector(".ht-session-list-pane");
    function setSessionListPaneFocus(target) {
      setSessionTransientState(withSessionListFocusTarget(sessionTransientState, target));
      if (listPane) {
        listPane.classList.toggle("focused", target === "list");
      }
    }
    backdrop.addEventListener("click", () => {
      ctx.close();
    });
    backdrop.addEventListener("mousedown", (event) => event.preventDefault());
    closeBtn.addEventListener("click", () => {
      ctx.close();
    });
    filterInput.addEventListener("focus", () => {
      setSessionListPaneFocus("filter");
    });
    filterInput.addEventListener("input", () => {
      const nextQuery = filterInput.value;
      const caretPos = filterInput.selectionStart ?? nextQuery.length;
      const nextVisibleIndices = getFilteredSessionIndices(ctx.sessions, nextQuery);
      if (sessionTransientState.isLoadConfirmationActive) {
        setSessionTransientState(stopSessionLoadConfirmation(sessionTransientState));
      }
      setSessionListPaneFocus("filter");
      ctx.setSessionFilterQuery(nextQuery);
      if (nextVisibleIndices.length > 0) {
        ctx.setSessionIndex(nextVisibleIndices[0]);
      } else {
        ctx.setSessionIndex(-1);
      }
      ctx.render();
      const restoredInput = ctx.shadow.querySelector(".ht-session-filter-input");
      if (restoredInput) {
        restoredInput.focus();
        const nextPos = Math.min(caretPos, nextQuery.length);
        restoredInput.setSelectionRange(nextPos, nextPos);
      }
    });
    shadow.querySelectorAll(".ht-session-item").forEach((el) => {
      el.addEventListener("click", (event) => {
        if (event.target.closest(".ht-session-delete")) return;
        if (sessionTransientState.isRenameModeActive || sessionTransientState.isLoadConfirmationActive || sessionTransientState.isOverwriteConfirmationActive || sessionTransientState.isDeleteConfirmationActive) return;
        const idx = parseInt(el.dataset.index);
        if (Number.isNaN(idx)) return;
        setSessionListPaneFocus("list");
        void beginLoadConfirmation(ctx, idx);
      });
    });
    shadow.querySelectorAll(".ht-session-delete").forEach((el) => {
      el.addEventListener("click", (event) => {
        event.stopPropagation();
        if (sessionTransientState.isRenameModeActive) {
          setSessionTransientState(stopSessionRenameMode(sessionTransientState));
          ctx.render();
          return;
        }
        if (sessionTransientState.isLoadConfirmationActive || sessionTransientState.isOverwriteConfirmationActive || sessionTransientState.isDeleteConfirmationActive) return;
        const idx = parseInt(el.dataset.index);
        if (Number.isNaN(idx)) return;
        setSessionListPaneFocus("list");
        beginDeleteConfirmation(ctx, idx);
      });
    });
    shadow.querySelectorAll(".ht-session-rename-input").forEach((el) => {
      const renameInput = el;
      renameInput.addEventListener("mousedown", (event) => event.stopPropagation());
      renameInput.addEventListener("click", (event) => event.stopPropagation());
    });
    const activeEl = shadow.querySelector(".ht-session-item.active");
    if (activeEl) activeEl.scrollIntoView({ block: "nearest" });
    const listScroll = shadow.querySelector(".ht-session-list-scroll");
    if (listScroll) {
      listScroll.addEventListener("focusin", () => {
        setSessionListPaneFocus("list");
      });
    }
    if (listScroll && !sessionTransientState.isRenameModeActive && !sessionTransientState.isOverwriteConfirmationActive && !sessionTransientState.isDeleteConfirmationActive && !sessionTransientState.isLoadConfirmationActive) {
      listScroll.addEventListener("wheel", (event) => {
        event.preventDefault();
        event.stopPropagation();
        const indices = getFilteredSessionIndices(ctx.sessions, ctx.sessionFilterQuery);
        if (indices.length === 0) return;
        const nextIndex = moveVisibleSelectionFromWheel(indices, ctx.sessionIndex, event.deltaY);
        if (nextIndex === ctx.sessionIndex) return;
        setSessionListPaneFocus("list");
        ctx.setSessionIndex(nextIndex);
        ctx.render();
      });
    }
    if (filterInput && !sessionTransientState.isRenameModeActive && !sessionTransientState.isOverwriteConfirmationActive && !sessionTransientState.isDeleteConfirmationActive && !sessionTransientState.isLoadConfirmationActive) {
      if (sessionTransientState.sessionListFocusTarget === "filter") {
        setSessionListPaneFocus("filter");
        const end = filterInput.value.length;
        filterInput.focus();
        filterInput.setSelectionRange(end, end);
      } else {
        const activeSessionItem = shadow.querySelector(".ht-session-item.active");
        if (activeSessionItem) {
          setSessionListPaneFocus("list");
          activeSessionItem.focus();
        } else {
          setSessionListPaneFocus("filter");
          const end = filterInput.value.length;
          filterInput.focus();
          filterInput.setSelectionRange(end, end);
        }
      }
    }
  }
  function renderReplaceSession(ctx) {
    const { shadow, container, sessions, sessionIndex } = ctx;
    let html = `<div class="ht-backdrop"></div>
    <div class="ht-tab-manager-container">
      <div class="ht-titlebar">
        <div class="ht-traffic-lights">
          <button class="ht-dot ht-dot-close" title="Close (${escapeHtml(keyToDisplay(ctx.config.bindings.tabManager.close.key))})"></button>
        </div>
        <span class="ht-titlebar-text">Replace which session?</span>
        ${vimBadgeHtml(ctx.config)}
      </div>
      <div class="ht-tab-manager-list">`;
    for (let i = 0; i < sessions.length; i++) {
      const s = sessions[i];
      const cls = i === sessionIndex ? "ht-session-item active" : "ht-session-item";
      const date = new Date(s.savedAt).toLocaleDateString();
      html += `<div class="${cls}" data-index="${i}">
      <div class="ht-session-name">${escapeHtml(s.name)}</div>
      <span class="ht-session-meta">${s.entries.length} tabs \xB7 ${date}</span>
    </div>`;
    }
    html += `</div><div class="ht-footer">
    ${buildReplaceSessionFooterHtml(ctx.config)}
  </div></div>`;
    container.innerHTML = html;
    const backdrop = shadow.querySelector(".ht-backdrop");
    const closeBtn = shadow.querySelector(".ht-dot-close");
    backdrop.addEventListener("click", () => {
      ctx.close();
    });
    backdrop.addEventListener("mousedown", (event) => event.preventDefault());
    closeBtn.addEventListener("click", () => {
      ctx.close();
    });
    shadow.querySelectorAll(".ht-session-item").forEach((el) => {
      el.addEventListener("click", () => {
        const idx = parseInt(el.dataset.index);
        replaceSession2(ctx, idx);
      });
    });
    const listEl = shadow.querySelector(".ht-tab-manager-list");
    if (listEl) {
      listEl.addEventListener("wheel", (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (sessions.length === 0) return;
        const next = moveVisibleSelectionFromWheel(
          sessions.map((_, index) => index),
          ctx.sessionIndex,
          event.deltaY
        );
        if (next === ctx.sessionIndex) return;
        ctx.setSessionIndex(next);
        ctx.render();
      });
    }
    const activeEl = shadow.querySelector(".ht-session-item.active");
    if (activeEl) activeEl.scrollIntoView({ block: "nearest" });
  }
  async function replaceSession2(ctx, idx) {
    try {
      const oldName = ctx.sessions[idx].name;
      const result = await replaceSession(oldName, ctx.pendingSaveName);
      if (result.ok) {
        showFeedback(toastMessages.sessionSaveReplacing(ctx.pendingSaveName, oldName));
      } else {
        showFeedback(result.reason || toastMessages.sessionSaveFailed);
      }
      ctx.setViewMode("tabManager");
      ctx.render();
    } catch (error) {
      reportSessionError("Replace session failed", "Failed to replace session", error);
      ctx.render();
    }
  }
  function handleReplaceSessionKey(ctx, event) {
    if (matchesAction(event, ctx.config, "tabManager", "close")) {
      event.preventDefault();
      event.stopPropagation();
      ctx.close();
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "jump")) {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions[ctx.sessionIndex]) replaceSession2(ctx, ctx.sessionIndex);
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "moveDown")) {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions.length > 0) {
        const nextIndex = moveVisibleSelectionByDirection(
          ctx.sessions.map((_, index) => index),
          ctx.sessionIndex,
          "down"
        );
        ctx.setSessionIndex(nextIndex);
        ctx.render();
      }
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "moveUp")) {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions.length > 0) {
        const nextIndex = moveVisibleSelectionByDirection(
          ctx.sessions.map((_, index) => index),
          ctx.sessionIndex,
          "up"
        );
        ctx.setSessionIndex(nextIndex);
        ctx.render();
      }
      return true;
    }
    event.stopPropagation();
    return true;
  }
  async function saveSession(ctx, name) {
    if (!name.trim()) return;
    try {
      const result = await saveSessionByName(name.trim());
      if (result.ok) {
        ctx.setPendingSaveName("");
        showFeedback(toastMessages.sessionSave(name.trim()));
        ctx.setViewMode("tabManager");
        ctx.render();
      } else if (result.reason && result.reason.includes(`Max ${MAX_SESSIONS}`)) {
        ctx.setPendingSaveName(name.trim());
        const sessions = await listSessions();
        ctx.setSessions(sessions);
        ctx.setSessionIndex(0);
        ctx.setViewMode("replaceSession");
        ctx.render();
      } else if (result.reason && result.reason.startsWith("Identical to ")) {
        ctx.close();
        showFeedback(toastMessages.sessionSaveReopenRequired);
      } else if (result.reason) {
        showSaveSessionInlineError(ctx, result.reason);
      } else {
        ctx.setPendingSaveName("");
        showFeedback(result.reason || toastMessages.sessionSaveFailed);
        ctx.setViewMode("tabManager");
        ctx.render();
      }
    } catch (error) {
      ctx.setPendingSaveName("");
      reportSessionError("Save session failed", "Failed to save session", error);
      ctx.setViewMode("tabManager");
      ctx.render();
    }
  }
  async function loadSession(ctx, session) {
    try {
      ctx.close();
      const result = await loadSessionByName(session.name);
      if (result.ok) {
        const count = result.count ?? 0;
        showFeedback(toastMessages.sessionLoad(session.name, count));
      }
    } catch (error) {
      reportSessionError("Load session failed", "Failed to load session", error);
    }
  }
  async function deleteSessionByName2(ctx, name) {
    try {
      await deleteSessionByName(name);
      const sessions = await listSessions();
      setSessionTransientState(stopSessionDeleteConfirmation(sessionTransientState));
      ctx.setSessions(sessions);
      ctx.setSessionIndex(Math.min(ctx.sessionIndex, Math.max(sessions.length - 1, 0)));
      ctx.render();
    } catch (error) {
      setSessionTransientState(stopSessionDeleteConfirmation(sessionTransientState));
      reportSessionError("Delete session failed", "Failed to delete session", error);
      ctx.render();
    }
  }
  function beginDeleteConfirmation(ctx, sessionIdx) {
    const target = ctx.sessions[sessionIdx];
    if (!target) return;
    setSessionTransientState(startSessionDeleteConfirmation(sessionTransientState, target.name));
    ctx.setSessionIndex(sessionIdx);
    ctx.render();
  }
  async function confirmDeleteSession(ctx) {
    if (!sessionTransientState.pendingDeleteSessionName) return;
    const targetName = sessionTransientState.pendingDeleteSessionName;
    await deleteSessionByName2(ctx, targetName);
  }
  function showSaveSessionInlineError(ctx, message) {
    const input = ctx.shadow.querySelector(".ht-session-input");
    const errorEl = ctx.shadow.querySelector(".ht-session-error");
    if (!input || !errorEl) return false;
    errorEl.textContent = message;
    errorEl.style.display = "";
    input.style.borderBottom = "1px solid #ff5f57";
    setTimeout(() => {
      errorEl.style.display = "none";
      input.style.borderBottom = "";
    }, 2e3);
    return true;
  }
  function handleSaveSessionKey(ctx, event) {
    const input = ctx.shadow.querySelector(".ht-session-input");
    if (matchesAction(event, ctx.config, "tabManager", "close")) {
      event.preventDefault();
      event.stopPropagation();
      ctx.close();
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "jump")) {
      event.preventDefault();
      event.stopPropagation();
      if (input && !input.value.trim()) {
        showSaveSessionInlineError(ctx, "A session name is required");
        return true;
      }
      if (input) {
        void (async () => {
          await saveSession(ctx, input.value);
        })();
      }
      return true;
    }
    event.stopPropagation();
    return true;
  }
  function handleSessionListKey(ctx, event) {
    const standardNav = ctx.config.navigationMode === "standard";
    const filterInput = ctx.shadow.querySelector(".ht-session-filter-input");
    const filterInputFocused = !!filterInput && ctx.shadow.activeElement === filterInput;
    const isSessionConfirmYes = matchesAction(event, ctx.config, "session", "confirmYes");
    const isSessionConfirmNo = matchesAction(event, ctx.config, "session", "confirmNo");
    const getVisibleSelectedSession = () => {
      const visibleIndices = getFilteredSessionIndices(ctx.sessions, ctx.sessionFilterQuery);
      if (!visibleIndices.includes(ctx.sessionIndex)) return void 0;
      return ctx.sessions[ctx.sessionIndex];
    };
    if (sessionTransientState.isRenameModeActive) {
      if (matchesAction(event, ctx.config, "tabManager", "close")) {
        event.preventDefault();
        event.stopPropagation();
        setSessionTransientState(stopSessionRenameMode(sessionTransientState));
        ctx.render();
        return true;
      }
      if (matchesAction(event, ctx.config, "tabManager", "jump")) {
        event.preventDefault();
        event.stopPropagation();
        const input = ctx.shadow.querySelector(".ht-session-rename-input");
        if (input && input.value.trim()) {
          const target = ctx.sessions[ctx.sessionIndex];
          if (!target) {
            setSessionTransientState(stopSessionRenameMode(sessionTransientState));
            ctx.render();
            return true;
          }
          const oldName = target.name;
          const newName = input.value.trim();
          (async () => {
            try {
              const result = await renameSession(oldName, newName);
              setSessionTransientState(stopSessionRenameMode(sessionTransientState));
              if (result.ok) {
                showFeedback(toastMessages.sessionRename(newName));
                const sessions = await listSessions();
                ctx.setSessions(sessions);
              } else {
                showFeedback(result.reason || toastMessages.sessionRenameFailed);
              }
            } catch (error) {
              setSessionTransientState(stopSessionRenameMode(sessionTransientState));
              reportSessionError("Rename session failed", "Rename failed", error);
            }
            ctx.render();
          })();
        }
        return true;
      }
      event.stopPropagation();
      return true;
    }
    if (sessionTransientState.isOverwriteConfirmationActive) {
      event.preventDefault();
      event.stopPropagation();
      if (isSessionConfirmYes) {
        const session = ctx.sessions[ctx.sessionIndex];
        setSessionTransientState(stopSessionOverwriteConfirmation(sessionTransientState));
        (async () => {
          try {
            const result = await updateSession(session.name);
            if (result.ok) {
              showFeedback(toastMessages.sessionOverwrite(session.name));
              const sessions = await listSessions();
              ctx.setSessions(sessions);
            } else {
              showFeedback(result.reason || toastMessages.sessionOverwriteFailed);
            }
          } catch (error) {
            reportSessionError("Overwrite session failed", "Overwrite failed", error);
          }
          ctx.render();
        })();
      } else if (isSessionConfirmNo) {
        setSessionTransientState(stopSessionOverwriteConfirmation(sessionTransientState));
        ctx.render();
      }
      return true;
    }
    if (sessionTransientState.isDeleteConfirmationActive) {
      event.preventDefault();
      event.stopPropagation();
      if (isSessionConfirmYes) {
        void confirmDeleteSession(ctx);
      } else if (isSessionConfirmNo) {
        setSessionTransientState(stopSessionDeleteConfirmation(sessionTransientState));
        ctx.render();
      }
      return true;
    }
    if (sessionTransientState.isLoadConfirmationActive) {
      event.preventDefault();
      event.stopPropagation();
      if (isSessionConfirmYes) {
        void confirmLoadSession(ctx);
      } else if (isSessionConfirmNo) {
        setSessionTransientState(stopSessionLoadConfirmation(sessionTransientState));
        ctx.render();
      }
      return true;
    }
    if (matchesAction(event, ctx.config, "session", "clearSearch")) {
      event.preventDefault();
      event.stopPropagation();
      setSessionTransientState(withSessionListFocusTarget(sessionTransientState, "filter"));
      ctx.setSessionFilterQuery("");
      const visibleIndices = getFilteredSessionIndices(ctx.sessions, "");
      if (visibleIndices.length > 0) {
        ctx.setSessionIndex(visibleIndices[0]);
      }
      ctx.render();
      const restoredInput = ctx.shadow.querySelector(".ht-session-filter-input");
      if (restoredInput) {
        restoredInput.focus();
        restoredInput.setSelectionRange(0, 0);
      }
      return true;
    }
    if (matchesAction(event, ctx.config, "session", "focusList")) {
      event.preventDefault();
      event.stopPropagation();
      const visibleIndices = getFilteredSessionIndices(ctx.sessions, ctx.sessionFilterQuery);
      if (filterInputFocused) {
        setSessionTransientState(withSessionListFocusTarget(sessionTransientState, "list"));
        const topMatch = visibleIndices[0];
        if (typeof topMatch === "number" && ctx.sessionIndex !== topMatch) {
          ctx.setSessionIndex(topMatch);
          ctx.render();
        } else if (typeof topMatch === "number") {
          filterInput.blur();
          const activeSessionItem = ctx.shadow.querySelector(`.ht-session-item[data-index="${topMatch}"]`);
          if (activeSessionItem) {
            activeSessionItem.focus();
            activeSessionItem.scrollIntoView({ block: "nearest" });
          }
        } else {
          filterInput.blur();
        }
        return true;
      }
      return true;
    }
    if (filterInputFocused) {
      if (matchesAction(event, ctx.config, "tabManager", "close")) {
        if (!standardNav) {
          event.preventDefault();
          event.stopPropagation();
          filterInput.blur();
          return true;
        }
      }
      if (matchesAction(event, ctx.config, "tabManager", "jump")) {
        event.preventDefault();
        event.stopPropagation();
        if (getVisibleSelectedSession()) {
          setSessionTransientState(withSessionListFocusTarget(sessionTransientState, "list"));
          void beginLoadConfirmation(ctx, ctx.sessionIndex);
        }
        return true;
      }
      if (!matchesAction(event, ctx.config, "tabManager", "close")) {
        event.stopPropagation();
        return true;
      }
    }
    if (standardNav && !filterInputFocused && event.ctrlKey && !event.altKey && !event.metaKey) {
      const lowerKey = event.key.toLowerCase();
      if (lowerKey === "d" || lowerKey === "u") {
        event.preventDefault();
        event.stopPropagation();
        const visibleIndices = getFilteredSessionIndices(ctx.sessions, ctx.sessionFilterQuery);
        if (visibleIndices.length > 0) {
          const jump = getSessionListHalfPageStep(ctx.shadow);
          const nextIndex = moveVisibleSelectionHalfPage(
            visibleIndices,
            ctx.sessionIndex,
            jump,
            lowerKey === "d" ? "down" : "up"
          );
          setSessionTransientState(withSessionListFocusTarget(sessionTransientState, "list"));
          ctx.setSessionIndex(nextIndex);
          ctx.render();
        }
        return true;
      }
    }
    if (filterInput && matchesAction(event, ctx.config, "session", "focusSearch")) {
      event.preventDefault();
      event.stopPropagation();
      setSessionTransientState(withSessionListFocusTarget(sessionTransientState, "filter"));
      filterInput.focus();
      filterInput.setSelectionRange(filterInput.value.length, filterInput.value.length);
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "close")) {
      event.preventDefault();
      event.stopPropagation();
      ctx.close();
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "moveDown")) {
      event.preventDefault();
      event.stopPropagation();
      const visibleIndices = getFilteredSessionIndices(ctx.sessions, ctx.sessionFilterQuery);
      if (visibleIndices.length > 0) {
        const nextIndex = moveVisibleSelectionByDirection(visibleIndices, ctx.sessionIndex, "down");
        ctx.setSessionIndex(nextIndex);
        setSessionTransientState(withSessionListFocusTarget(sessionTransientState, "list"));
        ctx.render();
      }
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "moveUp")) {
      event.preventDefault();
      event.stopPropagation();
      const visibleIndices = getFilteredSessionIndices(ctx.sessions, ctx.sessionFilterQuery);
      if (visibleIndices.length > 0) {
        const nextIndex = moveVisibleSelectionByDirection(visibleIndices, ctx.sessionIndex, "up");
        ctx.setSessionIndex(nextIndex);
        setSessionTransientState(withSessionListFocusTarget(sessionTransientState, "list"));
        ctx.render();
      }
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "jump")) {
      event.preventDefault();
      event.stopPropagation();
      if (getVisibleSelectedSession()) {
        setSessionTransientState(withSessionListFocusTarget(sessionTransientState, "list"));
        void beginLoadConfirmation(ctx, ctx.sessionIndex);
      }
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "remove")) {
      event.preventDefault();
      event.stopPropagation();
      if (getVisibleSelectedSession()) beginDeleteConfirmation(ctx, ctx.sessionIndex);
      return true;
    }
    if (matchesAction(event, ctx.config, "session", "rename")) {
      event.preventDefault();
      event.stopPropagation();
      if (!getVisibleSelectedSession()) return true;
      setSessionTransientState(startSessionRenameMode(sessionTransientState));
      ctx.render();
      const input = ctx.shadow.querySelector(".ht-session-rename-input");
      if (input) {
        input.focus();
        const end = input.value.length;
        input.setSelectionRange(end, end);
      }
      return true;
    }
    if (matchesAction(event, ctx.config, "session", "overwrite")) {
      event.preventDefault();
      event.stopPropagation();
      if (!getVisibleSelectedSession()) return true;
      setSessionTransientState(startSessionOverwriteConfirmation(sessionTransientState));
      ctx.render();
      return true;
    }
    event.stopPropagation();
    return true;
  }

  // src/lib/ui/panels/sessionMenu/sessionMenu.ts
  async function fetchSessionsWithRetry() {
    return listSessionsWithRetry();
  }
  async function fetchTabManagerEntriesWithRetry() {
    return listTabManagerEntriesWithRetry();
  }
  async function openSessionMenu(config, initialView = "sessionList") {
    try {
      let close2 = function() {
        document.removeEventListener("keydown", keyHandler2, true);
        window.removeEventListener("ht-navigation-mode-changed", onNavigationModeChanged2);
        resetSessionTransientState2();
        removePanelHost();
      }, failClose2 = function(context, error) {
        console.error(`[Anchor Tags] ${context}; dismissing session menu.`, error);
        showFeedback(toastMessages.sessionMenuFailed);
        close2();
      }, onNavigationModeChanged2 = function() {
        refreshSessionViewFooter(sessionCtx, viewMode);
      }, render2 = function() {
        if (viewMode === "saveSession") {
          void renderSaveSession(sessionCtx).catch((error) => {
            failClose2("Render save-session view failed", error);
          });
          return;
        }
        if (viewMode === "sessionList") {
          renderSessionList(sessionCtx);
          return;
        }
        renderReplaceSession(sessionCtx);
      }, keyHandler2 = function(event) {
        if (!document.getElementById("ht-panel-host")) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (viewMode === "saveSession") {
          handleSaveSessionKey(sessionCtx, event);
          return;
        }
        if (viewMode === "sessionList") {
          handleSessionListKey(sessionCtx, event);
          return;
        }
        handleReplaceSessionKey(sessionCtx, event);
      };
      var close = close2, failClose = failClose2, onNavigationModeChanged = onNavigationModeChanged2, render = render2, keyHandler = keyHandler2;
      if (initialView === "saveSession") {
        try {
          const [tabManagerEntries, savedSessions] = await Promise.all([
            fetchTabManagerEntriesWithRetry(),
            fetchSessionsWithRetry()
          ]);
          const currentUrls = tabManagerEntries.map((entry) => normalizeUrlForMatch(entry.url)).join("\n");
          const identicalSession = savedSessions.find((session) => {
            const sessionUrls = session.entries.map((entry) => normalizeUrlForMatch(entry.url)).join("\n");
            return sessionUrls === currentUrls;
          });
          if (identicalSession) {
            showFeedback(toastMessages.alreadyUsingSavedSessionFromList(identicalSession.name));
            return;
          }
        } catch (error) {
          console.error("[Anchor Tags] Pre-save identical-session guard failed; continuing.", error);
        }
      }
      const { host, shadow } = createPanelHost();
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + previewPane_default + tabManager_default + session_default + sessionMenu_default;
      shadow.appendChild(style);
      const container = document.createElement("div");
      shadow.appendChild(container);
      let viewMode = initialView;
      let sessions = [];
      let sessionIndex = 0;
      let pendingSaveName = "";
      let sessionFilterQuery = "";
      resetSessionTransientState2();
      async function refreshSessions() {
        try {
          sessions = await fetchSessionsWithRetry();
        } catch (error) {
          sessions = [];
          console.error("[Anchor Tags] Session fetch failed.", error);
        }
      }
      const sessionCtx = {
        shadow,
        container,
        config,
        get sessions() {
          return sessions;
        },
        get sessionIndex() {
          return sessionIndex;
        },
        get pendingSaveName() {
          return pendingSaveName;
        },
        get sessionFilterQuery() {
          return sessionFilterQuery;
        },
        setSessionIndex(index) {
          sessionIndex = index;
        },
        setSessions(nextSessions) {
          sessions = nextSessions;
        },
        setPendingSaveName(name) {
          pendingSaveName = name;
        },
        setSessionFilterQuery(query) {
          sessionFilterQuery = query;
        },
        setViewMode(mode) {
          viewMode = mode === "tabManager" ? initialView : mode;
        },
        render: render2,
        close: close2
      };
      if (viewMode === "sessionList") {
        sessions = [];
        sessionIndex = 0;
        sessionFilterQuery = "";
      } else if (viewMode === "saveSession") {
        pendingSaveName = "";
      }
      document.addEventListener("keydown", keyHandler2, true);
      window.addEventListener("ht-navigation-mode-changed", onNavigationModeChanged2);
      registerPanelCleanup(close2);
      render2();
      if (viewMode === "sessionList") {
        void (async () => {
          await refreshSessions();
          if (!document.getElementById("ht-panel-host")) return;
          if (sessions.length > 0) {
            sessionIndex = Math.min(sessionIndex, sessions.length - 1);
          } else {
            sessionIndex = 0;
          }
          render2();
        })();
      }
      host.focus();
    } catch (error) {
      console.error("[Anchor Tags] Failed to open session menu:", error);
      dismissPanel();
    }
  }

  // src/lib/ui/panels/help/help.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());

  // src/lib/ui/panels/help/help.css
  var help_default = ".ht-help-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(94vw, 680px); max-height: min(88vh, 760px); background: var(--ht-color-bg);\n  border: 1px solid var(--ht-color-border); border-radius: var(--ht-radius);\n  display: flex; flex-direction: column; overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-help-titlebar-text {\n  flex: 1; text-align: left; font-size: 12px; color: var(--ht-color-text);\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n}\n.ht-help-title-label { color: var(--ht-color-text-title); }\n.ht-help-body {\n  flex: 1; overflow-y: auto; padding: 8px 0;\n  scroll-behavior: auto;\n}\n.ht-help-section { margin-bottom: 4px; }\n.ht-help-header {\n  display: flex; align-items: center; padding: 6px 20px;\n  font-size: 11px; font-weight: 700; text-transform: uppercase;\n  letter-spacing: 0.8px; color: var(--ht-color-accent);\n  user-select: none;\n}\n.ht-help-items { overflow: hidden; }\n.ht-help-row {\n  display: flex; align-items: center; justify-content: space-between;\n  padding: 4px 20px 4px 38px; font-size: 12px; cursor: default;\n}\n.ht-help-label { color: var(--ht-color-text-soft); }\n.ht-help-key {\n  font-size: 11px; color: var(--ht-color-text); background: var(--ht-color-surface);\n  padding: 2px 8px; border-radius: 4px; font-weight: 600;\n  white-space: nowrap; flex-shrink: 0; margin-left: 12px;\n}\n.ht-help-tip {\n  font-size: 11px; color: var(--ht-color-text-muted); padding: 10px 20px;\n  border-top: 1px solid var(--ht-color-border-soft);\n  text-align: center; line-height: 1.6;\n}\n\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-help-container { border-radius: 8px; }\n  .ht-help-row { padding: 4px 10px 4px 12px; font-size: 11px; }\n  .ht-help-header { padding: 6px 10px; }\n  .ht-help-key { margin-left: 8px; padding: 2px 6px; }\n}\n";

  // src/lib/ui/panels/help/help.ts
  var SCROLL_STEP = 80;
  function buildSections(config) {
    const g = config.bindings.global;
    const h = config.bindings.tabManager;
    const a = config.bindings.anchorTags;
    const p = config.bindings.session;
    const k = (b) => keyToDisplay(b.key);
    return [
      {
        title: "Open Panels",
        items: [
          { label: "Tab Manager", key: k(g.openTabManager) },
          { label: "Anchor Tags", key: k(g.openAnchorTags) },
          { label: "Sessions", key: k(g.openSessions) },
          { label: "Save Session", key: k(g.openSessionSave) },
          { label: "Help (this menu)", key: k(g.openHelp) }
        ]
      },
      {
        title: "Navigation Mode",
        items: [
          { label: "Standard mode", key: "always on" },
          { label: "Adds j / k for up / down", key: "all list panels" }
        ]
      },
      {
        title: "Inside Any Panel",
        items: [
          { label: "Navigate up / down", key: `${k(h.moveUp)} / ${k(h.moveDown)}` },
          { label: "Built-in alias (always on)", key: "j / k" },
          { label: "Half-page jump (list-focused)", key: "Ctrl+D / Ctrl+U" },
          { label: "Accept selected row", key: `${k(h.jump)} (tab/session)` },
          { label: "Close panel", key: k(h.close) },
          { label: "Click item to select or open", key: "mouse" },
          { label: "Scroll wheel to navigate", key: "mouse" }
        ]
      },
      {
        title: "Tab Manager Panel",
        items: [
          { label: "Add current tab to Tab Manager", key: k(g.addTab) },
          { label: "Jump to slot 1 \u2014 4", key: `${k(g.jumpSlot1)} \u2014 ${k(g.jumpSlot4)}` },
          { label: "Cycle prev / next slot", key: `${k(g.cyclePrev)} / ${k(g.cycleNext)}` },
          { label: "Swap mode", key: k(h.swap) },
          { label: "Rename entry", key: k(h.rename) },
          { label: "Del entry", key: k(h.remove) },
          { label: "Undo remove", key: k(h.undo) },
          { label: "Jump selected row", key: k(h.jump) },
          { label: "Close panel", key: k(h.close) }
        ]
      },
      {
        title: "Anchor Tags",
        items: [
          { label: "Open Anchor Tags panel", key: k(g.openAnchorTags) },
          { label: "Add current page position", key: k(g.addAnchorTag) },
          { label: "Cycle previous / next tag", key: `${k(g.cycleAnchorPrev)} / ${k(g.cycleAnchorNext)}` },
          { label: "Panel add tag", key: k(a.add) },
          { label: "Panel rename tag", key: k(a.rename) },
          { label: "Panel delete tag", key: k(a.remove) },
          { label: "Panel undo delete", key: k(a.undo) },
          { label: "Panel jump selected", key: k(a.jump) },
          { label: "Close panel", key: k(a.close) }
        ]
      },
      {
        title: "Session Menu",
        items: [
          { label: "Open session menu", key: k(g.openSessions) },
          { label: "Main view", key: "Load sessions list" },
          { label: "Open save session", key: k(g.openSessionSave) },
          { label: "Load selected session", key: `${k(h.jump)} (opens confirmation)` },
          { label: "Save mode preview", key: "current tab-manager tabs" },
          { label: "Session list focus list", key: k(p.focusList) },
          { label: "Session search focus", key: k(p.focusSearch) },
          { label: "Session clear-search", key: k(p.clearSearch) },
          { label: "Session list half-page jump", key: "Ctrl+D / Ctrl+U" },
          { label: "Delete session (in session list)", key: `${k(h.remove)} then ${k(p.confirmYes)} / ${k(p.confirmNo)}` },
          { label: "Overwrite session (in session list)", key: `${k(p.overwrite)} then ${k(p.confirmYes)} / ${k(p.confirmNo)}` },
          { label: "Rename session (in session list)", key: k(p.rename) },
          { label: "Rename cancel", key: `${k(h.close)} or \xD7` },
          { label: "Load plan symbols", key: "NEW (+) \xB7 DELETED (-) \xB7 REPLACED (~) \xB7 UNCHANGED (=)" },
          { label: "Confirmation dialogs", key: `${k(p.confirmYes)} confirm / ${k(p.confirmNo)} cancel` },
          { label: "Close panel", key: k(h.close) }
        ]
      }
    ];
  }
  function openHelpOverlay(config) {
    try {
      let renderSections2 = function() {
        sectionsHost.innerHTML = "";
        const sections = buildSections(liveConfig);
        for (const section of sections) {
          const sectionEl = document.createElement("div");
          sectionEl.className = "ht-help-section";
          const header = document.createElement("div");
          header.className = "ht-help-header";
          const titleSpan = document.createElement("span");
          titleSpan.textContent = section.title;
          header.appendChild(titleSpan);
          sectionEl.appendChild(header);
          const itemsEl = document.createElement("div");
          itemsEl.className = "ht-help-items";
          for (const item of section.items) {
            const row = document.createElement("div");
            row.className = "ht-help-row";
            const label = document.createElement("span");
            label.className = "ht-help-label";
            label.textContent = item.label;
            const key = document.createElement("span");
            key.className = "ht-help-key";
            key.textContent = item.key;
            row.appendChild(label);
            row.appendChild(key);
            itemsEl.appendChild(row);
          }
          sectionEl.appendChild(itemsEl);
          sectionsHost.appendChild(sectionEl);
        }
        const tip = document.createElement("div");
        tip.className = "ht-help-tip";
        tip.innerHTML = "Help Uses Your Current <strong>Options Keybindings</strong> And Updates While Open";
        sectionsHost.appendChild(tip);
      }, renderFooter2 = function() {
        const closeKey = keyToDisplay(liveConfig.bindings.tabManager.close.key);
        const moveUpKey = keyToDisplay(liveConfig.bindings.tabManager.moveUp.key);
        const moveDownKey = keyToDisplay(liveConfig.bindings.tabManager.moveDown.key);
        closeButton.title = `Close (${escapeHtml(closeKey)})`;
        const scrollHints = liveConfig.navigationMode === "standard" ? [
          { key: "j/k", desc: "scroll" },
          { key: `${moveUpKey}/${moveDownKey}`, desc: "scroll" }
        ] : [
          { key: `${moveUpKey}/${moveDownKey}`, desc: "scroll" }
        ];
        footer.innerHTML = `${footerRowHtml(scrollHints)}
      ${footerRowHtml([
          { key: "Wheel", desc: "scroll" },
          { key: closeKey, desc: "close" }
        ])}`;
      }, onNavigationModeChanged2 = function() {
        renderSections2();
        renderFooter2();
      }, close2 = function() {
        document.removeEventListener("keydown", keyHandler2, true);
        window.removeEventListener("ht-navigation-mode-changed", onNavigationModeChanged2);
        import_webextension_polyfill4.default.storage.onChanged.removeListener(onStorageChanged);
        removePanelHost();
      }, keyHandler2 = function(event) {
        if (!document.getElementById("ht-panel-host")) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (matchesAction(event, liveConfig, "tabManager", "close")) {
          event.preventDefault();
          event.stopPropagation();
          close2();
          return;
        }
        const isDown = matchesAction(event, liveConfig, "tabManager", "moveDown");
        const isUp = matchesAction(event, liveConfig, "tabManager", "moveUp");
        if (isDown) {
          event.preventDefault();
          event.stopPropagation();
          body.scrollTop += SCROLL_STEP;
          return;
        }
        if (isUp) {
          event.preventDefault();
          event.stopPropagation();
          body.scrollTop -= SCROLL_STEP;
          return;
        }
        event.stopPropagation();
      };
      var renderSections = renderSections2, renderFooter = renderFooter2, onNavigationModeChanged = onNavigationModeChanged2, close = close2, keyHandler = keyHandler2;
      let liveConfig = config;
      const { host, shadow } = createPanelHost();
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + help_default;
      shadow.appendChild(style);
      const backdrop = document.createElement("div");
      backdrop.className = "ht-backdrop";
      shadow.appendChild(backdrop);
      const panel = document.createElement("div");
      panel.className = "ht-help-container";
      shadow.appendChild(panel);
      const titlebar = document.createElement("div");
      titlebar.className = "ht-titlebar";
      titlebar.innerHTML = `
      <div class="ht-traffic-lights">
        <button class="ht-dot ht-dot-close"></button>
      </div>
      <span class="ht-help-titlebar-text">
        <span class="ht-help-title-label">Help</span>
      </span>
      ${vimBadgeHtml(liveConfig)}`;
      panel.appendChild(titlebar);
      const body = document.createElement("div");
      body.className = "ht-help-body";
      panel.appendChild(body);
      const sectionsHost = document.createElement("div");
      body.appendChild(sectionsHost);
      const footer = document.createElement("div");
      footer.className = "ht-footer";
      const closeButton = titlebar.querySelector(".ht-dot-close");
      const onStorageChanged = (changes, area) => {
        if (area !== "local" || !changes.keybindings) return;
        const nextConfig = changes.keybindings.newValue;
        if (!nextConfig || typeof nextConfig !== "object") return;
        nextConfig.navigationMode = "standard";
        liveConfig = nextConfig;
        renderSections2();
        renderFooter2();
      };
      renderSections2();
      renderFooter2();
      panel.appendChild(footer);
      backdrop.addEventListener("click", close2);
      backdrop.addEventListener("mousedown", (event) => event.preventDefault());
      titlebar.querySelector(".ht-dot-close").addEventListener("click", close2);
      document.addEventListener("keydown", keyHandler2, true);
      window.addEventListener("ht-navigation-mode-changed", onNavigationModeChanged2);
      import_webextension_polyfill4.default.storage.onChanged.addListener(onStorageChanged);
      registerPanelCleanup(close2);
      host.focus();
    } catch (err) {
      console.error("[Anchor Tags] Failed to open help overlay:", err);
      dismissPanel();
    }
  }

  // src/lib/ui/panels/sessionMenu/sessionRestoreOverlay.ts
  function reportSessionError2(context, feedbackMessage, error) {
    console.error(`[Anchor Tags] ${context}:`, error);
    showFeedback(feedbackMessage);
  }
  async function openSessionRestoreOverlay() {
    try {
      let close2 = function() {
        document.removeEventListener("keydown", keyHandler2, true);
        window.removeEventListener("ht-navigation-mode-changed", onNavigationModeChanged2);
        removePanelHost();
      }, renderRestoreFooter2 = function() {
        const footer = shadow.querySelector(".ht-footer");
        if (!footer) return;
        const moveUpKey = keyToDisplay(config.bindings.tabManager.moveUp.key);
        const moveDownKey = keyToDisplay(config.bindings.tabManager.moveDown.key);
        const restoreKey = keyToDisplay(config.bindings.tabManager.jump.key);
        const closeKey = keyToDisplay(config.bindings.tabManager.close.key);
        const navHints = config.navigationMode === "standard" ? [
          { key: "j/k", desc: "nav" },
          { key: `${moveUpKey}/${moveDownKey}`, desc: "nav" }
        ] : [
          { key: `${moveUpKey}/${moveDownKey}`, desc: "nav" }
        ];
        footer.innerHTML = `${footerRowHtml(navHints)}
      ${footerRowHtml([
          { key: restoreKey, desc: "restore" },
          { key: closeKey, desc: "decline" }
        ])}`;
      }, onNavigationModeChanged2 = function() {
        renderRestoreFooter2();
      }, render2 = function() {
        let html = `<div class="ht-backdrop"></div>
        <div class="ht-session-restore-container">
          <div class="ht-titlebar">
            <div class="ht-traffic-lights">
              <button class="ht-dot ht-dot-close" title="Decline (${escapeHtml(keyToDisplay(config.bindings.tabManager.close.key))})"></button>
            </div>
            <span class="ht-titlebar-text">Restore Session?</span>
            ${vimBadgeHtml(config)}
          </div>
          <div class="ht-session-restore-list">`;
        for (let i = 0; i < sessions.length; i++) {
          const session = sessions[i];
          const cls = i === activeIndex ? "ht-session-restore-item active" : "ht-session-restore-item";
          const date = new Date(session.savedAt).toLocaleDateString();
          html += `<div class="${cls}" data-index="${i}">
          <div class="ht-session-restore-name">${escapeHtml(session.name)}</div>
          <span class="ht-session-restore-meta">${session.entries.length} tabs &middot; ${date}</span>
        </div>`;
        }
        html += `</div>
        <div class="ht-footer"></div>
      </div>`;
        container.innerHTML = html;
        renderRestoreFooter2();
        const backdrop = shadow.querySelector(".ht-backdrop");
        const closeBtn = shadow.querySelector(".ht-dot-close");
        backdrop.addEventListener("click", close2);
        backdrop.addEventListener("mousedown", (event) => event.preventDefault());
        closeBtn.addEventListener("click", close2);
        shadow.querySelectorAll(".ht-session-restore-item").forEach((el) => {
          el.addEventListener("click", () => {
            const idx = parseInt(el.dataset.index || "", 10);
            if (Number.isNaN(idx)) return;
            void restoreSession(sessions[idx]);
          });
        });
        const listEl = shadow.querySelector(".ht-session-restore-list");
        if (listEl) {
          listEl.addEventListener("wheel", (event) => {
            event.preventDefault();
            event.stopPropagation();
            if (sessions.length === 0) return;
            const next = moveVisibleSelectionFromWheel(
              sessions.map((_, index) => index),
              activeIndex,
              event.deltaY
            );
            if (next === activeIndex) return;
            activeIndex = next;
            render2();
          });
        }
        const activeEl = shadow.querySelector(".ht-session-restore-item.active");
        if (activeEl) activeEl.scrollIntoView({ block: "nearest" });
      }, keyHandler2 = function(event) {
        if (!document.getElementById("ht-panel-host")) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (matchesAction(event, config, "tabManager", "close")) {
          event.preventDefault();
          event.stopPropagation();
          close2();
          return;
        }
        if (matchesAction(event, config, "tabManager", "jump")) {
          event.preventDefault();
          event.stopPropagation();
          if (sessions[activeIndex]) void restoreSession(sessions[activeIndex]);
          return;
        }
        if (matchesAction(event, config, "tabManager", "moveDown")) {
          event.preventDefault();
          event.stopPropagation();
          activeIndex = moveVisibleSelectionByDirection(
            sessions.map((_, index) => index),
            activeIndex,
            "down"
          );
          render2();
          return;
        }
        if (matchesAction(event, config, "tabManager", "moveUp")) {
          event.preventDefault();
          event.stopPropagation();
          activeIndex = moveVisibleSelectionByDirection(
            sessions.map((_, index) => index),
            activeIndex,
            "up"
          );
          render2();
          return;
        }
        event.stopPropagation();
      };
      var close = close2, renderRestoreFooter = renderRestoreFooter2, onNavigationModeChanged = onNavigationModeChanged2, render = render2, keyHandler = keyHandler2;
      const sessions = await listSessions();
      if (sessions.length === 0) return;
      const config = await loadKeybindings();
      const { host, shadow } = createPanelHost();
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + session_default;
      shadow.appendChild(style);
      const container = document.createElement("div");
      shadow.appendChild(container);
      let activeIndex = 0;
      async function restoreSession(session) {
        try {
          close2();
          const result = await loadSessionByName(session.name);
          if (result.ok) {
            showFeedback(toastMessages.sessionRestore(session.name, result.count ?? 0));
          }
        } catch (error) {
          reportSessionError2("Restore session failed", "Failed to restore session", error);
        }
      }
      document.addEventListener("keydown", keyHandler2, true);
      window.addEventListener("ht-navigation-mode-changed", onNavigationModeChanged2);
      registerPanelCleanup(close2);
      render2();
      host.focus();
    } catch (error) {
      console.error("[Anchor Tags] Failed to open session restore overlay:", error);
      dismissPanel();
    }
  }

  // src/lib/adapters/runtime/keybindingsApi.ts
  function fetchKeybindings() {
    return sendRuntimeMessage({ type: "GET_KEYBINDINGS" });
  }

  // src/lib/adapters/runtime/contentLifecycleApi.ts
  function notifyContentScriptReady() {
    return sendRuntimeMessage({ type: "CONTENT_SCRIPT_READY" });
  }

  // src/lib/appInit/appInit.ts
  function initApp() {
    if (window.__anchorTagsCleanup) {
      window.__anchorTagsCleanup();
    }
    const anchorTagPageOverlay = initAnchorTagPageOverlay();
    let cachedConfig = null;
    let configLoadPromise = null;
    function requestConfigLoad() {
      if (cachedConfig) return Promise.resolve(cachedConfig);
      if (configLoadPromise) return configLoadPromise;
      configLoadPromise = fetchKeybindings().then((loadedConfig) => {
        cachedConfig = loadedConfig;
        cachedConfig.navigationMode = "standard";
        return cachedConfig;
      }).finally(() => {
        configLoadPromise = null;
      });
      return configLoadPromise;
    }
    requestConfigLoad().catch(() => {
    });
    async function getConfig() {
      if (cachedConfig) return cachedConfig;
      return requestConfigLoad();
    }
    import_webextension_polyfill5.default.storage.onChanged.addListener((changes) => {
      if (changes.keybindings) {
        const nextConfig = changes.keybindings.newValue;
        if (nextConfig && typeof nextConfig === "object") {
          nextConfig.navigationMode = "standard";
          cachedConfig = nextConfig;
        } else {
          cachedConfig = null;
          requestConfigLoad().catch(() => {
          });
        }
      }
    });
    let panelDebounce = 0;
    const PANEL_DEBOUNCE_MS = 50;
    function openPanel(fn) {
      const now = Date.now();
      if (now - panelDebounce < PANEL_DEBOUNCE_MS) return;
      panelDebounce = now;
      try {
        const maybePromise = fn();
        if (maybePromise && typeof maybePromise.then === "function") {
          void maybePromise.catch((err) => {
            console.error("[Anchor Tags] panel open failed:", err);
            dismissPanel();
            showFeedback(toastMessages.panelOpenFailed);
          });
        }
      } catch (err) {
        console.error("[Anchor Tags] panel open failed:", err);
        dismissPanel();
        showFeedback(toastMessages.panelOpenFailed);
      }
    }
    function hasLivePanelHost() {
      const host = document.getElementById("ht-panel-host");
      if (!host) return false;
      const shadow = host.shadowRoot;
      if (!shadow || shadow.childElementCount === 0) {
        dismissPanel();
        return false;
      }
      return true;
    }
    function getMaxScrollY3() {
      const documentElement = document.documentElement;
      const body = document.body;
      const scrollHeight = Math.max(
        documentElement?.scrollHeight || 0,
        body?.scrollHeight || 0,
        documentElement?.offsetHeight || 0,
        body?.offsetHeight || 0
      );
      return Math.max(0, scrollHeight - window.innerHeight);
    }
    function clampScrollY(scrollY) {
      return Math.max(0, Math.min(scrollY, getMaxScrollY3()));
    }
    function normalizeAnchorLabel(text) {
      return text.replace(/\s+/g, " ").trim().slice(0, 30);
    }
    function isElementVisible(element) {
      const style = window.getComputedStyle(element);
      if (style.display === "none" || style.visibility === "hidden") return false;
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    }
    function findNearestHeadingLabel(scrollY) {
      const targetY = scrollY + Math.max(80, Math.floor(window.innerHeight / 3));
      const headings = document.querySelectorAll("h1, h2, h3, h4, h5, h6");
      let bestLabel = "";
      let bestTop = -Infinity;
      for (const heading of headings) {
        if (!(heading instanceof HTMLElement) || !isElementVisible(heading)) continue;
        const text = normalizeAnchorLabel(heading.textContent || "");
        if (!text) continue;
        const top = heading.getBoundingClientRect().top + window.scrollY;
        if (top <= targetY && top > bestTop) {
          bestTop = top;
          bestLabel = text;
        }
      }
      return bestLabel;
    }
    function findNearbyTextLabel(scrollY) {
      if (!document.body) return "";
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(node2) {
          const parent = node2.parentElement;
          if (!parent || !isElementVisible(parent)) return NodeFilter.FILTER_REJECT;
          const text = normalizeAnchorLabel(node2.textContent || "");
          return text ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        }
      });
      const minY = scrollY - 80;
      const maxY = scrollY + window.innerHeight;
      let node;
      while (node = walker.nextNode()) {
        const range = document.createRange();
        range.selectNodeContents(node);
        const rect = range.getBoundingClientRect();
        range.detach();
        const absoluteTop = rect.top + window.scrollY;
        if (absoluteTop < minY || absoluteTop > maxY) continue;
        const text = normalizeAnchorLabel(node.textContent || "");
        if (text) return text;
      }
      return "";
    }
    function getAnchorLabelContext(scrollY) {
      const heading = findNearestHeadingLabel(scrollY);
      if (heading) return { label: heading };
      const nearbyText = findNearbyTextLabel(scrollY);
      if (nearbyText) return { label: nearbyText };
      const maxScrollY = getMaxScrollY3();
      const percent = maxScrollY > 0 ? Math.round(clampScrollY(scrollY) / maxScrollY * 100) : 0;
      const title = normalizeAnchorLabel(document.title || "");
      return { label: title ? `${title} ${percent}%`.slice(0, 30) : `Page ${percent}%` };
    }
    const globalActionRegistry = [
      {
        action: "openTabManager",
        run: (config) => openPanel(() => openTabManager(config))
      },
      {
        action: "addTab",
        run: () => {
          void addCurrentTabToTabManager();
        }
      },
      {
        action: "jumpSlot1",
        run: () => {
          void jumpToTabManagerSlot(1);
        }
      },
      {
        action: "jumpSlot2",
        run: () => {
          void jumpToTabManagerSlot(2);
        }
      },
      {
        action: "jumpSlot3",
        run: () => {
          void jumpToTabManagerSlot(3);
        }
      },
      {
        action: "jumpSlot4",
        run: () => {
          void jumpToTabManagerSlot(4);
        }
      },
      {
        action: "cyclePrev",
        run: () => {
          void cycleTabManagerSlot("prev");
        }
      },
      {
        action: "cycleNext",
        run: () => {
          void cycleTabManagerSlot("next");
        }
      },
      {
        action: "openAnchorTags",
        run: (config) => openPanel(() => openAnchorTags(config))
      },
      {
        action: "addAnchorTag",
        run: () => {
          void addCurrentAnchorTag();
        }
      },
      {
        action: "cycleAnchorPrev",
        run: () => {
          void cycleAnchorTag("prev");
        }
      },
      {
        action: "cycleAnchorNext",
        run: () => {
          void cycleAnchorTag("next");
        }
      },
      {
        action: "openSessions",
        run: (config) => openPanel(() => openSessionMenu(config))
      },
      {
        action: "openSessionSave",
        run: (config) => openPanel(() => openSessionMenu(config, "saveSession"))
      },
      {
        action: "openHelp",
        run: (config) => openPanel(() => openHelpOverlay(config))
      }
    ];
    function tryHandleGlobalActions(event, config) {
      if (hasLivePanelHost()) return false;
      for (const registration of globalActionRegistry) {
        if (!matchesAction(event, config, "global", registration.action)) continue;
        event.preventDefault();
        event.stopPropagation();
        registration.run(config);
        return true;
      }
      return false;
    }
    function globalKeyHandler(event) {
      if (!cachedConfig) {
        requestConfigLoad().catch(() => {
        });
        if (tryHandleGlobalActions(event, DEFAULT_KEYBINDINGS)) return;
        return;
      }
      const config = cachedConfig;
      void tryHandleGlobalActions(event, config);
    }
    document.addEventListener("keydown", globalKeyHandler, true);
    function messageHandler(message) {
      const receivedMessage = message;
      switch (receivedMessage.type) {
        case "GET_SCROLL":
          return Promise.resolve({
            scrollX: window.scrollX,
            scrollY: window.scrollY
          });
        case "SET_SCROLL":
          window.scrollTo({
            left: Math.max(0, receivedMessage.scrollX),
            top: clampScrollY(receivedMessage.scrollY),
            behavior: receivedMessage.smooth ? "smooth" : "auto"
          });
          return Promise.resolve({ ok: true });
        case "GET_ANCHOR_LABEL_CONTEXT":
          return Promise.resolve(getAnchorLabelContext(receivedMessage.scrollY));
        case "OPEN_ANCHOR_TAGS":
          if (!hasLivePanelHost())
            getConfig().then((config) => openPanel(() => openAnchorTags(config))).catch(() => showFeedback(toastMessages.panelOpenFailed));
          return Promise.resolve({ ok: true });
        case "OPEN_TAB_MANAGER":
          if (!hasLivePanelHost())
            getConfig().then((config) => openPanel(() => openTabManager(config))).catch(() => showFeedback(toastMessages.panelOpenFailed));
          return Promise.resolve({ ok: true });
        case "OPEN_SESSIONS":
          if (!hasLivePanelHost())
            getConfig().then((config) => openPanel(() => openSessionMenu(config))).catch(() => showFeedback(toastMessages.panelOpenFailed));
          return Promise.resolve({ ok: true });
        case "SHOW_SESSION_RESTORE":
          if (!hasLivePanelHost())
            openSessionRestoreOverlay();
          return Promise.resolve({ ok: true });
        case "ANCHOR_TAG_FEEDBACK":
          showFeedback(receivedMessage.message);
          return Promise.resolve({ ok: true });
        case "ANCHOR_TAGS_UPDATED":
          anchorTagPageOverlay.update(receivedMessage.entries, receivedMessage.activeSlot);
          return Promise.resolve({ ok: true });
        case "TAB_MANAGER_ADDED_FEEDBACK":
          showFeedback(
            receivedMessage.alreadyAdded ? toastMessages.tabManagerAlreadyAdded(receivedMessage.slot) : toastMessages.tabManagerAdded(receivedMessage.slot)
          );
          return Promise.resolve({ ok: true });
        case "TAB_MANAGER_FULL_FEEDBACK":
          showFeedback(toastMessages.tabManagerFull(receivedMessage.max));
          return Promise.resolve({ ok: true });
      }
    }
    import_webextension_polyfill5.default.runtime.onMessage.addListener(messageHandler);
    notifyContentScriptReady().catch(() => {
    });
    function visibilityHandler() {
      if (document.visibilityState === "hidden") {
        dismissPanel();
      }
    }
    document.addEventListener("visibilitychange", visibilityHandler);
    window.__anchorTagsCleanup = () => {
      document.removeEventListener("keydown", globalKeyHandler, true);
      document.removeEventListener("visibilitychange", visibilityHandler);
      import_webextension_polyfill5.default.runtime.onMessage.removeListener(messageHandler);
      const host = document.getElementById("ht-panel-host");
      if (host) host.remove();
      const toast = document.getElementById("ht-feedback-toast");
      if (toast) toast.remove();
      anchorTagPageOverlay.destroy();
    };
  }

  // src/entryPoints/contentScript/contentScript.ts
  initApp();
})();
