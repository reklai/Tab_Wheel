import { MAX_ANCHOR_TAGS, keyToDisplay, matchesAction } from "../../../common/contracts/keybindings";
import {
  calculateAnchorPagePercent,
} from "../../../core/anchorTags/anchorTagsCore";
import {
  createPanelHost,
  footerRowHtml,
  getBaseStyles,
  registerPanelCleanup,
  removePanelHost,
  vimBadgeHtml,
  dismissPanel,
} from "../../../common/utils/panelHost";
import { escapeHtml, extractDomain } from "../../../common/utils/helpers";
import { showFeedback } from "../../../common/utils/feedback";
import { toastMessages } from "../../../common/utils/toastMessages";
import {
  addCurrentAnchorTag,
  jumpToAnchorTag,
  listAnchorTagsWithRetry,
  removeAnchorTag,
  renameAnchorTag,
  restoreAnchorTag,
} from "../../../adapters/runtime/anchorTagsApi";
import {
  movePanelListIndexByDirection,
  movePanelListIndexFromWheel,
} from "../../../core/panel/panelListController";
import anchorTagsStyles from "./anchorTags.css";

function getMaxScrollY(): number {
  const documentElement = document.documentElement;
  const body = document.body;
  const scrollHeight = Math.max(
    documentElement?.scrollHeight || 0,
    body?.scrollHeight || 0,
    documentElement?.offsetHeight || 0,
    body?.offsetHeight || 0,
  );
  return Math.max(0, scrollHeight - window.innerHeight);
}

function formatAnchorPercent(entry: AnchorTagEntry): string {
  return `${calculateAnchorPagePercent(entry.scrollY, getMaxScrollY())}%`;
}

function buildFooterHtml(config: KeybindingsConfig, hasUndo: boolean): string {
  const upKey = keyToDisplay(config.bindings.anchorTags.moveUp.key);
  const downKey = keyToDisplay(config.bindings.anchorTags.moveDown.key);
  const jumpKey = keyToDisplay(config.bindings.anchorTags.jump.key);
  const addKey = keyToDisplay(config.bindings.anchorTags.add.key);
  const renameKey = keyToDisplay(config.bindings.anchorTags.rename.key);
  const removeKey = keyToDisplay(config.bindings.anchorTags.remove.key);
  const undoKey = keyToDisplay(config.bindings.anchorTags.undo.key);
  const closeKey = keyToDisplay(config.bindings.anchorTags.close.key);
  const navHints = config.navigationMode === "standard"
    ? [
      { key: "j/k", desc: "nav" },
      { key: `${upKey}/${downKey}`, desc: "nav" },
    ]
    : [
      { key: `${upKey}/${downKey}`, desc: "nav" },
    ];

  return `${footerRowHtml(navHints)}
    ${footerRowHtml([
      { key: addKey, desc: "add" },
      { key: renameKey, desc: "rename" },
      { key: removeKey, desc: "del" },
      { key: undoKey, desc: "undo", active: hasUndo },
      { key: jumpKey, desc: "jump" },
      { key: closeKey, desc: "close" },
    ])}`;
}

export async function openAnchorTags(config: KeybindingsConfig): Promise<void> {
  try {
    const { host, shadow } = createPanelHost();

    const style = document.createElement("style");
    style.textContent = getBaseStyles() + anchorTagsStyles;
    shadow.appendChild(style);

    const container = document.createElement("div");
    shadow.appendChild(container);

    let tags = await listAnchorTagsWithRetry();
    let activeIndex = 0;
    let undoEntry: AnchorTagEntry | null = null;
    let renameSlot: number | null = null;

    function close(): void {
      document.removeEventListener("keydown", keyHandler, true);
      window.removeEventListener("ht-navigation-mode-changed", onNavigationModeChanged);
      removePanelHost();
    }

    function getSelectedTag(): AnchorTagEntry | null {
      if (tags.length === 0) return null;
      return tags[Math.max(0, Math.min(tags.length - 1, activeIndex))] || null;
    }

    async function refreshTags(): Promise<void> {
      tags = await listAnchorTagsWithRetry();
      if (tags.length === 0) {
        activeIndex = 0;
      } else {
        activeIndex = Math.max(0, Math.min(tags.length - 1, activeIndex));
      }
      if (renameSlot != null && !tags.some((tag) => tag.slot === renameSlot)) {
        renameSlot = null;
      }
    }

    function onNavigationModeChanged(): void {
      render();
    }

    function render(): void {
      const closeKey = keyToDisplay(config.bindings.anchorTags.close.key);
      let html = `<div class="ht-backdrop"></div>
        <div class="ht-anchor-tags-container">
          <div class="ht-titlebar">
            <div class="ht-traffic-lights">
              <button class="ht-dot ht-dot-close" title="Close (${escapeHtml(closeKey)})"></button>
            </div>
            <span class="ht-titlebar-text">Anchor Tags</span>
            ${vimBadgeHtml(config)}
          </div>
          <div class="ht-anchor-tags-body">
            <div class="ht-anchor-tags-list">`;

      for (let i = 0; i < MAX_ANCHOR_TAGS; i++) {
        const tag = tags[i];
        if (!tag) {
          html += `<div class="ht-anchor-tag-empty" data-index="${i}">
            <span class="ht-anchor-tag-slot">${i + 1}</span>
            <span class="ht-anchor-tag-empty-label">---</span>
          </div>`;
          continue;
        }

        const classes = ["ht-anchor-tag-item"];
        if (i === activeIndex) classes.push("active");
        const labelHtml = renameSlot === tag.slot
          ? `<input type="text" class="ht-anchor-tag-rename-input" value="${escapeHtml(tag.label)}" maxlength="30" />`
          : `<div class="ht-anchor-tag-label">${escapeHtml(tag.label)}</div>`;
        html += `<div class="${classes.join(" ")}" data-index="${i}" data-slot="${tag.slot}" tabindex="${i === activeIndex ? "0" : "-1"}">
          <span class="ht-anchor-tag-slot">${tag.slot}</span>
          <div class="ht-anchor-tag-info">
            ${labelHtml}
            <div class="ht-anchor-tag-meta">${formatAnchorPercent(tag)} · ${escapeHtml(extractDomain(tag.url))}</div>
          </div>
          <button class="ht-anchor-tag-rename" data-slot="${tag.slot}" title="Rename">R</button>
          <button class="ht-anchor-tag-delete" data-slot="${tag.slot}" title="Remove">&times;</button>
        </div>`;
      }

      html += `</div>
            <div class="ht-footer">${buildFooterHtml(config, !!undoEntry)}</div>
          </div>
        </div>`;

      container.innerHTML = html;

      const backdrop = shadow.querySelector(".ht-backdrop") as HTMLElement;
      const closeBtn = shadow.querySelector(".ht-dot-close") as HTMLElement;
      const listEl = shadow.querySelector(".ht-anchor-tags-list") as HTMLElement | null;
      backdrop.addEventListener("click", close);
      backdrop.addEventListener("mousedown", (event) => event.preventDefault());
      closeBtn.addEventListener("click", close);

      shadow.querySelectorAll(".ht-anchor-tag-item").forEach((row) => {
        row.addEventListener("click", (event) => {
          const target = event.target as HTMLElement;
          if (target.closest("button") || target.closest("input")) return;
          const index = Number((row as HTMLElement).dataset.index);
          if (Number.isNaN(index) || !tags[index]) return;
          activeIndex = index;
          void jumpSelectedTag();
        });
      });

      shadow.querySelectorAll(".ht-anchor-tag-delete").forEach((button) => {
        button.addEventListener("click", (event) => {
          event.stopPropagation();
          const slot = Number((button as HTMLElement).dataset.slot);
          if (!Number.isNaN(slot)) void deleteTag(slot);
        });
      });

      shadow.querySelectorAll(".ht-anchor-tag-rename").forEach((button) => {
        button.addEventListener("click", (event) => {
          event.stopPropagation();
          const slot = Number((button as HTMLElement).dataset.slot);
          if (Number.isNaN(slot)) return;
          renameSlot = slot;
          render();
          focusRenameInput();
        });
      });

      const renameInput = shadow.querySelector(".ht-anchor-tag-rename-input") as HTMLInputElement | null;
      if (renameInput) {
        renameInput.addEventListener("click", (event) => event.stopPropagation());
        renameInput.addEventListener("mousedown", (event) => event.stopPropagation());
      }

      if (listEl) {
        listEl.addEventListener("wheel", (event) => {
          event.preventDefault();
          event.stopPropagation();
          if (tags.length === 0 || renameSlot != null) return;
          activeIndex = movePanelListIndexFromWheel(tags.length, activeIndex, event.deltaY);
          render();
        });
      }

      const activeEl = shadow.querySelector(".ht-anchor-tag-item.active") as HTMLElement | null;
      if (activeEl && renameSlot == null) {
        activeEl.focus({ preventScroll: true });
      }
    }

    function focusRenameInput(): void {
      const input = shadow.querySelector(".ht-anchor-tag-rename-input") as HTMLInputElement | null;
      if (!input) return;
      input.focus();
      input.setSelectionRange(input.value.length, input.value.length);
    }

    async function addTag(): Promise<void> {
      const result = await addCurrentAnchorTag();
      undoEntry = null;
      if (!result.ok && result.reason) {
        showFeedback(result.reason);
      }
      await refreshTags();
      if (result.slot != null) {
        const nextIndex = tags.findIndex((tag) => tag.slot === result.slot);
        if (nextIndex >= 0) activeIndex = nextIndex;
      }
      render();
    }

    async function deleteTag(slot: number): Promise<void> {
      const result = await removeAnchorTag(slot);
      if (result.ok && result.entry) {
        undoEntry = result.entry;
        renameSlot = null;
      } else if (result.reason) {
        showFeedback(result.reason);
      }
      await refreshTags();
      render();
    }

    async function undoDelete(): Promise<void> {
      if (!undoEntry) return;
      const result = await restoreAnchorTag(undoEntry);
      if (result.ok) {
        undoEntry = null;
        showFeedback("Restored Anchor Tag");
      } else if (result.reason) {
        showFeedback(result.reason);
      }
      await refreshTags();
      render();
    }

    async function confirmRename(): Promise<void> {
      if (renameSlot == null) return;
      const input = shadow.querySelector(".ht-anchor-tag-rename-input") as HTMLInputElement | null;
      if (!input) return;
      const nextLabel = input.value.trim();
      if (!nextLabel) {
        showFeedback("Name cannot be empty");
        return;
      }
      const result = await renameAnchorTag(renameSlot, nextLabel);
      if (result.ok) {
        showFeedback("Renamed Anchor Tag");
        renameSlot = null;
      } else if (result.reason) {
        showFeedback(result.reason);
      }
      await refreshTags();
      render();
    }

    async function jumpSelectedTag(): Promise<void> {
      const tag = getSelectedTag();
      if (!tag) return;
      close();
      const result = await jumpToAnchorTag(tag.slot);
      if (!result.ok) {
        showFeedback(result.reason || toastMessages.anchorTagJumpFailed);
      }
    }

    function keyHandler(event: KeyboardEvent): void {
      if (!document.getElementById("ht-panel-host")) {
        document.removeEventListener("keydown", keyHandler, true);
        return;
      }

      if (renameSlot != null) {
        if (matchesAction(event, config, "anchorTags", "close")) {
          event.preventDefault();
          event.stopPropagation();
          renameSlot = null;
          render();
          return;
        }
        if (matchesAction(event, config, "anchorTags", "jump")) {
          event.preventDefault();
          event.stopPropagation();
          void confirmRename();
          return;
        }
        event.stopPropagation();
        return;
      }

      if (matchesAction(event, config, "anchorTags", "close")) {
        event.preventDefault();
        event.stopPropagation();
        close();
        return;
      }

      if (matchesAction(event, config, "anchorTags", "add")) {
        event.preventDefault();
        event.stopPropagation();
        void addTag();
        return;
      }

      if (matchesAction(event, config, "anchorTags", "undo")) {
        event.preventDefault();
        event.stopPropagation();
        void undoDelete();
        return;
      }

      if (matchesAction(event, config, "anchorTags", "rename")) {
        event.preventDefault();
        event.stopPropagation();
        const tag = getSelectedTag();
        if (!tag) return;
        renameSlot = tag.slot;
        render();
        focusRenameInput();
        return;
      }

      if (matchesAction(event, config, "anchorTags", "remove")) {
        event.preventDefault();
        event.stopPropagation();
        const tag = getSelectedTag();
        if (tag) void deleteTag(tag.slot);
        return;
      }

      if (matchesAction(event, config, "anchorTags", "jump")) {
        event.preventDefault();
        event.stopPropagation();
        void jumpSelectedTag();
        return;
      }

      if (matchesAction(event, config, "anchorTags", "moveDown")) {
        event.preventDefault();
        event.stopPropagation();
        if (tags.length > 0) {
          activeIndex = movePanelListIndexByDirection(tags.length, activeIndex, "down");
          render();
        }
        return;
      }

      if (matchesAction(event, config, "anchorTags", "moveUp")) {
        event.preventDefault();
        event.stopPropagation();
        if (tags.length > 0) {
          activeIndex = movePanelListIndexByDirection(tags.length, activeIndex, "up");
          render();
        }
        return;
      }

      event.stopPropagation();
    }

    document.addEventListener("keydown", keyHandler, true);
    window.addEventListener("ht-navigation-mode-changed", onNavigationModeChanged);
    registerPanelCleanup(close);
    render();
    host.focus();
  } catch (error) {
    console.error("[Anchor Tags] Failed to open Anchor Tags panel:", error);
    dismissPanel();
  }
}
