// Session menu shell — wires session views (load/save/replace) to shared panel lifecycle.
// View-specific rendering and key handling live in session.ts.

import {
  createPanelHost,
  removePanelHost,
  registerPanelCleanup,
  getBaseStyles,
  dismissPanel,
} from "../../../common/utils/panelHost";
import { showFeedback } from "../../../common/utils/feedback";
import { toastMessages } from "../../../common/utils/toastMessages";
import previewPaneStyles from "../../../common/utils/previewPane.css";
import tabManagerStyles from "../tabManager/tabManager.css";
import sessionStyles from "./session.css";
import sessionMenuStyles from "./sessionMenu.css";
import {
  SessionContext,
  SessionPanelMode,
  refreshSessionViewFooter,
  renderSaveSession,
  renderSessionList,
  renderReplaceSession,
  handleSaveSessionKey,
  handleSessionListKey,
  handleReplaceSessionKey,
  resetSessionTransientState,
} from "./session";
import { normalizeUrlForMatch } from "../../../common/utils/helpers";
import { listSessionsWithRetry } from "../../../adapters/runtime/sessionApi";
import { listTabManagerEntriesWithRetry } from "../../../adapters/runtime/tabManagerApi";

type SessionMenuView = SessionPanelMode;

async function fetchSessionsWithRetry(): Promise<TabManagerSession[]> {
  return listSessionsWithRetry();
}

async function fetchTabManagerEntriesWithRetry(): Promise<TabManagerEntry[]> {
  return listTabManagerEntriesWithRetry();
}

export async function openSessionMenu(
  config: KeybindingsConfig,
  initialView: SessionPanelMode = "sessionList",
): Promise<void> {
  try {
    // Pre-guard save mode: skip opening when tab-manager state already matches a saved session.
    if (initialView === "saveSession") {
      try {
        const [tabManagerEntries, savedSessions] = await Promise.all([
          fetchTabManagerEntriesWithRetry(),
          fetchSessionsWithRetry(),
        ]);
        const currentUrls = tabManagerEntries
          .map((entry) => normalizeUrlForMatch(entry.url))
          .join("\n");
        const identicalSession = savedSessions.find((session) => {
          const sessionUrls = session.entries
            .map((entry) => normalizeUrlForMatch(entry.url))
            .join("\n");
          return sessionUrls === currentUrls;
        });
        if (identicalSession) {
          showFeedback(toastMessages.alreadyUsingSavedSessionFromList(identicalSession.name));
          return;
        }
      } catch (error) {
        console.error("[Anchor Tags] Pre-save identical-session guard failed; continuing.", error);
      }
    }

    const { host, shadow } = createPanelHost();

    const style = document.createElement("style");
    style.textContent = getBaseStyles() + previewPaneStyles + tabManagerStyles + sessionStyles + sessionMenuStyles;
    shadow.appendChild(style);

    const container = document.createElement("div");
    shadow.appendChild(container);

    let viewMode: SessionMenuView = initialView;
    let sessions: TabManagerSession[] = [];
    let sessionIndex = 0;
    let pendingSaveName = "";
    let sessionFilterQuery = "";
    resetSessionTransientState();

    function close(): void {
      document.removeEventListener("keydown", keyHandler, true);
      window.removeEventListener("ht-navigation-mode-changed", onNavigationModeChanged);
      resetSessionTransientState();
      removePanelHost();
    }

    function failClose(context: string, error: unknown): void {
      console.error(`[Anchor Tags] ${context}; dismissing session menu.`, error);
      showFeedback(toastMessages.sessionMenuFailed);
      close();
    }

    async function refreshSessions(): Promise<void> {
      try {
        sessions = await fetchSessionsWithRetry();
      } catch (error) {
        sessions = [];
        console.error("[Anchor Tags] Session fetch failed.", error);
      }
    }

    const sessionCtx: SessionContext = {
      shadow,
      container,
      config,
      get sessions() { return sessions; },
      get sessionIndex() { return sessionIndex; },
      get pendingSaveName() { return pendingSaveName; },
      get sessionFilterQuery() { return sessionFilterQuery; },
      setSessionIndex(index: number) { sessionIndex = index; },
      setSessions(nextSessions: TabManagerSession[]) { sessions = nextSessions; },
      setPendingSaveName(name: string) { pendingSaveName = name; },
      setSessionFilterQuery(query: string) { sessionFilterQuery = query; },
      setViewMode(mode: "tabManager" | SessionPanelMode) {
        viewMode = mode === "tabManager" ? initialView : mode;
      },
      render,
      close,
    };

    function onNavigationModeChanged(): void {
      refreshSessionViewFooter(sessionCtx, viewMode);
    }

    function render(): void {
      if (viewMode === "saveSession") {
        void renderSaveSession(sessionCtx).catch((error) => {
          failClose("Render save-session view failed", error);
        });
        return;
      }

      if (viewMode === "sessionList") {
        renderSessionList(sessionCtx);
        return;
      }

      renderReplaceSession(sessionCtx);
    }

    function keyHandler(event: KeyboardEvent): void {
      if (!document.getElementById("ht-panel-host")) {
        document.removeEventListener("keydown", keyHandler, true);
        return;
      }

      if (viewMode === "saveSession") {
        handleSaveSessionKey(sessionCtx, event);
        return;
      }
      if (viewMode === "sessionList") {
        handleSessionListKey(sessionCtx, event);
        return;
      }
      handleReplaceSessionKey(sessionCtx, event);
    }

    if (viewMode === "sessionList") {
      // Render immediately so the search input is ready without waiting
      // on background session fetch retries / worker warm-up.
      sessions = [];
      sessionIndex = 0;
      sessionFilterQuery = "";
    } else if (viewMode === "saveSession") {
      pendingSaveName = "";
    }

    document.addEventListener("keydown", keyHandler, true);
    window.addEventListener("ht-navigation-mode-changed", onNavigationModeChanged);
    registerPanelCleanup(close);
    render();

    if (viewMode === "sessionList") {
      void (async () => {
        await refreshSessions();
        if (!document.getElementById("ht-panel-host")) return;
        if (sessions.length > 0) {
          sessionIndex = Math.min(sessionIndex, sessions.length - 1);
        } else {
          sessionIndex = 0;
        }
        render();
      })();
    }

    host.focus();
  } catch (error) {
    console.error("[Anchor Tags] Failed to open session menu:", error);
    dismissPanel();
  }
}
