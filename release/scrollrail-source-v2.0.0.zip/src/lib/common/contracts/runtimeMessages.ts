// Runtime message contracts between background and content scripts.

// Messages handled by contentScript listeners (sent from background).
export type ContentRuntimeMessage =
  | { type: "GET_SCROLL" }
  | { type: "SET_SCROLL"; scrollX: number; scrollY: number; smooth?: boolean }
  | { type: "GET_ANCHOR_LABEL_CONTEXT"; scrollX: number; scrollY: number }
  | { type: "OPEN_TAB_MANAGER" }
  | { type: "OPEN_ANCHOR_TAGS" }
  | { type: "OPEN_SESSIONS" }
  | { type: "SHOW_SESSION_RESTORE" }
  | { type: "ANCHOR_TAG_FEEDBACK"; message: string }
  | { type: "ANCHOR_TAGS_UPDATED"; entries: AnchorTagEntry[]; activeSlot?: number }
  | {
      type: "TAB_MANAGER_ADDED_FEEDBACK";
      slot: number;
      title?: string;
      alreadyAdded?: boolean;
    }
  | { type: "TAB_MANAGER_FULL_FEEDBACK"; max: number };

// Messages handled by the background runtime listener.
export type BackgroundRuntimeMessage =
  | { type: "TAB_MANAGER_ADD" }
  | { type: "TAB_MANAGER_REMOVE"; tabId: number }
  | { type: "TAB_MANAGER_RENAME"; tabId: number; label: string }
  | { type: "TAB_MANAGER_LIST" }
  | { type: "TAB_MANAGER_JUMP"; slot: number }
  | { type: "TAB_MANAGER_CYCLE"; direction: "prev" | "next" }
  | { type: "TAB_MANAGER_SAVE_SCROLL" }
  | { type: "TAB_MANAGER_REORDER"; list: TabManagerEntry[] }
  | { type: "ANCHOR_TAG_ADD" }
  | { type: "ANCHOR_TAG_LIST" }
  | { type: "ANCHOR_TAG_REMOVE"; slot: number }
  | { type: "ANCHOR_TAG_RENAME"; slot: number; label: string }
  | { type: "ANCHOR_TAG_RESTORE"; entry: AnchorTagEntry }
  | { type: "ANCHOR_TAG_CYCLE"; direction: "prev" | "next" }
  | { type: "ANCHOR_TAG_JUMP"; slot: number }
  | { type: "GET_CURRENT_TAB" }
  | { type: "GET_KEYBINDINGS" }
  | { type: "SAVE_KEYBINDINGS"; config: KeybindingsConfig }
  | { type: "CONTENT_SCRIPT_READY" }
  | { type: "SESSION_SAVE"; name: string }
  | { type: "SESSION_LIST" }
  | { type: "SESSION_LOAD_PLAN"; name: string }
  | { type: "SESSION_LOAD"; name: string }
  | { type: "SESSION_DELETE"; name: string }
  | { type: "SESSION_RENAME"; oldName: string; newName: string }
  | { type: "SESSION_UPDATE"; name: string }
  | { type: "SESSION_REPLACE"; oldName: string; newName: string };
