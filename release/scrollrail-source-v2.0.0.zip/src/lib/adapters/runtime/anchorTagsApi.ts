import { sendRuntimeMessage, sendRuntimeMessageWithRetry, RuntimeRetryPolicy } from "./runtimeClient";

export interface AnchorTagMutationResult {
  ok: boolean;
  reason?: string;
  entry?: AnchorTagEntry;
  slot?: number;
}

export function listAnchorTags(): Promise<AnchorTagEntry[]> {
  return sendRuntimeMessage<AnchorTagEntry[]>({ type: "ANCHOR_TAG_LIST" });
}

export function listAnchorTagsWithRetry(
  policy: RuntimeRetryPolicy = { retryDelaysMs: [0, 90, 240, 450] },
): Promise<AnchorTagEntry[]> {
  return sendRuntimeMessageWithRetry<AnchorTagEntry[]>(
    { type: "ANCHOR_TAG_LIST" },
    policy,
  );
}

export function addCurrentAnchorTag(): Promise<AnchorTagMutationResult> {
  return sendRuntimeMessage<AnchorTagMutationResult>({ type: "ANCHOR_TAG_ADD" });
}

export function removeAnchorTag(slot: number): Promise<AnchorTagMutationResult> {
  return sendRuntimeMessage<AnchorTagMutationResult>({ type: "ANCHOR_TAG_REMOVE", slot });
}

export function renameAnchorTag(
  slot: number,
  label: string,
): Promise<AnchorTagMutationResult> {
  return sendRuntimeMessage<AnchorTagMutationResult>({
    type: "ANCHOR_TAG_RENAME",
    slot,
    label,
  });
}

export function restoreAnchorTag(
  entry: AnchorTagEntry,
): Promise<AnchorTagMutationResult> {
  return sendRuntimeMessage<AnchorTagMutationResult>({
    type: "ANCHOR_TAG_RESTORE",
    entry,
  });
}

export function cycleAnchorTag(
  direction: "prev" | "next",
): Promise<AnchorTagMutationResult> {
  return sendRuntimeMessage<AnchorTagMutationResult>({
    type: "ANCHOR_TAG_CYCLE",
    direction,
  });
}

export function jumpToAnchorTag(slot: number): Promise<AnchorTagMutationResult> {
  return sendRuntimeMessage<AnchorTagMutationResult>({ type: "ANCHOR_TAG_JUMP", slot });
}
