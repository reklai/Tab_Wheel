import { AnchorTagsDomain } from "../domains/anchorTagsDomain";
import { RuntimeMessageHandler, UNHANDLED } from "./runtimeRouter";

export function createAnchorTagsMessageHandler(
  domain: AnchorTagsDomain,
): RuntimeMessageHandler {
  return async (message, sender) => {
    switch (message.type) {
      case "ANCHOR_TAG_ADD":
        return await domain.addCurrentTab();

      case "ANCHOR_TAG_LIST":
        return await domain.listCurrentTab(sender.tab?.id, sender.tab?.url || "");

      case "ANCHOR_TAG_REMOVE":
        return await domain.removeCurrentTabSlot(message.slot);

      case "ANCHOR_TAG_RENAME":
        return await domain.renameCurrentTabSlot(message.slot, message.label);

      case "ANCHOR_TAG_RESTORE":
        return await domain.restoreCurrentTabEntry(message.entry);

      case "ANCHOR_TAG_CYCLE":
        return await domain.cycleCurrentTab(message.direction);

      case "ANCHOR_TAG_JUMP":
        return await domain.jumpCurrentTabSlot(message.slot);

      default:
        return UNHANDLED;
    }
  };
}
