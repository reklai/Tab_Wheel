export const ANCHOR_TAG_DUPLICATE_DISTANCE_PX = 24;
export const ANCHOR_TAG_CYCLE_TOLERANCE_PX = 8;

export function sortAndCompactAnchorTags(
  entries: AnchorTagEntry[],
): AnchorTagEntry[] {
  return entries
    .slice()
    .sort((left, right) => {
      if (left.scrollY !== right.scrollY) return left.scrollY - right.scrollY;
      return left.createdAt - right.createdAt;
    })
    .map((entry, index) => ({
      ...entry,
      slot: index + 1,
    }));
}

export function isDuplicateAnchorTag(
  entries: AnchorTagEntry[],
  scrollY: number,
  thresholdPx: number = ANCHOR_TAG_DUPLICATE_DISTANCE_PX,
): boolean {
  return entries.some((entry) => Math.abs(entry.scrollY - scrollY) <= thresholdPx);
}

export function findAnchorCycleTarget(
  entries: AnchorTagEntry[],
  currentScrollY: number,
  direction: "prev" | "next",
  tolerancePx: number = ANCHOR_TAG_CYCLE_TOLERANCE_PX,
): AnchorTagEntry | null {
  const sorted = sortAndCompactAnchorTags(entries);
  if (sorted.length === 0) return null;

  if (direction === "next") {
    return sorted.find((entry) => entry.scrollY > currentScrollY + tolerancePx)
      || sorted[0];
  }

  for (let i = sorted.length - 1; i >= 0; i--) {
    if (sorted[i].scrollY < currentScrollY - tolerancePx) {
      return sorted[i];
    }
  }
  return sorted[sorted.length - 1];
}

export function clampAnchorScrollY(scrollY: number, maxScrollY: number): number {
  return Math.max(0, Math.min(scrollY, Math.max(0, maxScrollY)));
}

export function calculateAnchorPagePercent(
  scrollY: number,
  maxScrollY: number,
): number {
  if (maxScrollY <= 0) return 0;
  const clamped = clampAnchorScrollY(scrollY, maxScrollY);
  return Math.max(0, Math.min(100, Math.round((clamped / maxScrollY) * 100)));
}
