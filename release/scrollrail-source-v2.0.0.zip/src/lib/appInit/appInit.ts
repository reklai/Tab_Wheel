// App init — wires up keybindings, message routing, and panel lifecycle.
// Imported by contentScript.ts as the single bootstrap for all content-side logic.

import browser from "webextension-polyfill";
import { DEFAULT_KEYBINDINGS, matchesAction } from "../common/contracts/keybindings";
import { showFeedback } from "../common/utils/feedback";
import { toastMessages } from "../common/utils/toastMessages";
import { openAnchorTags } from "../ui/panels/anchorTags/anchorTags";
import { initAnchorTagPageOverlay } from "../ui/overlays/anchorTagPageOverlay";
import { openTabManager } from "../ui/panels/tabManager/tabManager";
import { openSessionMenu } from "../ui/panels/sessionMenu/sessionMenu";
import { openHelpOverlay } from "../ui/panels/help/help";
import { dismissPanel } from "../common/utils/panelHost";
import { ContentRuntimeMessage } from "../common/contracts/runtimeMessages";
import { openSessionRestoreOverlay } from "../ui/panels/sessionMenu/sessionRestoreOverlay";
import {
  addCurrentTabToTabManager,
  cycleTabManagerSlot,
  jumpToTabManagerSlot,
} from "../adapters/runtime/tabManagerApi";
import {
  addCurrentAnchorTag,
  cycleAnchorTag,
} from "../adapters/runtime/anchorTagsApi";
import { fetchKeybindings } from "../adapters/runtime/keybindingsApi";
import { notifyContentScriptReady } from "../adapters/runtime/contentLifecycleApi";

// Extend Window to track injection state
declare global {
  interface Window {
    __anchorTagsCleanup?: () => void;
  }
}

export function initApp(): void {
  // Clean up previous injection when extension reloads
  if (window.__anchorTagsCleanup) {
    window.__anchorTagsCleanup();
  }

  // Cached keybinding config — loaded eagerly on startup so the keydown
  // handler never needs to await. Reloaded on storage changes.
  const anchorTagPageOverlay = initAnchorTagPageOverlay();
  let cachedConfig: KeybindingsConfig | null = null;
  let configLoadPromise: Promise<KeybindingsConfig> | null = null;

  function requestConfigLoad(): Promise<KeybindingsConfig> {
    if (cachedConfig) return Promise.resolve(cachedConfig);
    if (configLoadPromise) return configLoadPromise;

    configLoadPromise = fetchKeybindings()
      .then((loadedConfig) => {
        cachedConfig = loadedConfig;
        cachedConfig.navigationMode = "standard";
        return cachedConfig;
      })
      .finally(() => {
        configLoadPromise = null;
      });

    return configLoadPromise;
  }

  requestConfigLoad().catch(() => {});

  // Keep config for the message handler (async callers)
  async function getConfig(): Promise<KeybindingsConfig> {
    if (cachedConfig) return cachedConfig;
    return requestConfigLoad();
  }

  browser.storage.onChanged.addListener((changes) => {
    if (changes.keybindings) {
      const nextConfig = changes.keybindings.newValue as KeybindingsConfig | undefined;
      if (nextConfig && typeof nextConfig === "object") {
        nextConfig.navigationMode = "standard";
        cachedConfig = nextConfig;
      } else {
        cachedConfig = null;
        requestConfigLoad().catch(() => {});
      }
    }
  });

  // Debounce panel-open actions to let cleanup settle between rapid presses.
  // Module-scoped so both globalKeyHandler and the message handler share it.
  let panelDebounce = 0;
  const PANEL_DEBOUNCE_MS = 50;

  /** Debounced panel opener — prevents rapid/concurrent opens from racing */
  function openPanel(fn: () => void | Promise<void>): void {
    const now = Date.now();
    if (now - panelDebounce < PANEL_DEBOUNCE_MS) return;
    panelDebounce = now;
    try {
      const maybePromise = fn();
      if (maybePromise && typeof (maybePromise as Promise<void>).then === "function") {
        void (maybePromise as Promise<void>).catch((err) => {
          console.error("[Anchor Tags] panel open failed:", err);
          dismissPanel();
          showFeedback(toastMessages.panelOpenFailed);
        });
      }
    } catch (err) {
      console.error("[Anchor Tags] panel open failed:", err);
      dismissPanel();
      showFeedback(toastMessages.panelOpenFailed);
    }
  }

  // Defensive host integrity check:
  // if a prior panel open crashed before rendering, clear the stale host so
  // the next shortcut can proceed instead of getting blocked forever.
  function hasLivePanelHost(): boolean {
    const host = document.getElementById("ht-panel-host");
    if (!host) return false;
    const shadow = host.shadowRoot;
    if (!shadow || shadow.childElementCount === 0) {
      dismissPanel();
      return false;
    }
    return true;
  }

  function getMaxScrollY(): number {
    const documentElement = document.documentElement;
    const body = document.body;
    const scrollHeight = Math.max(
      documentElement?.scrollHeight || 0,
      body?.scrollHeight || 0,
      documentElement?.offsetHeight || 0,
      body?.offsetHeight || 0,
    );
    return Math.max(0, scrollHeight - window.innerHeight);
  }

  function clampScrollY(scrollY: number): number {
    return Math.max(0, Math.min(scrollY, getMaxScrollY()));
  }

  function normalizeAnchorLabel(text: string): string {
    return text.replace(/\s+/g, " ").trim().slice(0, 30);
  }

  function isElementVisible(element: HTMLElement): boolean {
    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function findNearestHeadingLabel(scrollY: number): string {
    const targetY = scrollY + Math.max(80, Math.floor(window.innerHeight / 3));
    const headings = document.querySelectorAll("h1, h2, h3, h4, h5, h6");
    let bestLabel = "";
    let bestTop = -Infinity;

    for (const heading of headings) {
      if (!(heading instanceof HTMLElement) || !isElementVisible(heading)) continue;
      const text = normalizeAnchorLabel(heading.textContent || "");
      if (!text) continue;
      const top = heading.getBoundingClientRect().top + window.scrollY;
      if (top <= targetY && top > bestTop) {
        bestTop = top;
        bestLabel = text;
      }
    }

    return bestLabel;
  }

  function findNearbyTextLabel(scrollY: number): string {
    if (!document.body) return "";
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node: Node): number {
        const parent = node.parentElement;
        if (!parent || !isElementVisible(parent)) return NodeFilter.FILTER_REJECT;
        const text = normalizeAnchorLabel(node.textContent || "");
        return text ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      },
    });

    const minY = scrollY - 80;
    const maxY = scrollY + window.innerHeight;
    let node: Node | null;
    while ((node = walker.nextNode())) {
      const range = document.createRange();
      range.selectNodeContents(node);
      const rect = range.getBoundingClientRect();
      range.detach();
      const absoluteTop = rect.top + window.scrollY;
      if (absoluteTop < minY || absoluteTop > maxY) continue;
      const text = normalizeAnchorLabel(node.textContent || "");
      if (text) return text;
    }

    return "";
  }

  function getAnchorLabelContext(scrollY: number): AnchorLabelContext {
    const heading = findNearestHeadingLabel(scrollY);
    if (heading) return { label: heading };

    const nearbyText = findNearbyTextLabel(scrollY);
    if (nearbyText) return { label: nearbyText };

    const maxScrollY = getMaxScrollY();
    const percent = maxScrollY > 0
      ? Math.round((clampScrollY(scrollY) / maxScrollY) * 100)
      : 0;
    const title = normalizeAnchorLabel(document.title || "");
    return { label: title ? `${title} ${percent}%`.slice(0, 30) : `Page ${percent}%` };
  }

  // -- Global Keybinding Handler --
  // Runs on capture phase so pages that call stopPropagation() on keydown
  // can't break our keybinds. Fully synchronous — no microtask overhead.

  interface GlobalActionRegistration {
    action: keyof KeybindingsConfig["bindings"]["global"] | string;
    run: (config: KeybindingsConfig) => void;
  }

  const globalActionRegistry: GlobalActionRegistration[] = [
    {
      action: "openTabManager",
      run: (config) => openPanel(() => openTabManager(config)),
    },
    {
      action: "addTab",
      run: () => { void addCurrentTabToTabManager(); },
    },
    {
      action: "jumpSlot1",
      run: () => { void jumpToTabManagerSlot(1); },
    },
    {
      action: "jumpSlot2",
      run: () => { void jumpToTabManagerSlot(2); },
    },
    {
      action: "jumpSlot3",
      run: () => { void jumpToTabManagerSlot(3); },
    },
    {
      action: "jumpSlot4",
      run: () => { void jumpToTabManagerSlot(4); },
    },
    {
      action: "cyclePrev",
      run: () => { void cycleTabManagerSlot("prev"); },
    },
    {
      action: "cycleNext",
      run: () => { void cycleTabManagerSlot("next"); },
    },
    {
      action: "openAnchorTags",
      run: (config) => openPanel(() => openAnchorTags(config)),
    },
    {
      action: "addAnchorTag",
      run: () => { void addCurrentAnchorTag(); },
    },
    {
      action: "cycleAnchorPrev",
      run: () => { void cycleAnchorTag("prev"); },
    },
    {
      action: "cycleAnchorNext",
      run: () => { void cycleAnchorTag("next"); },
    },
    {
      action: "openSessions",
      run: (config) => openPanel(() => openSessionMenu(config)),
    },
    {
      action: "openSessionSave",
      run: (config) => openPanel(() => openSessionMenu(config, "saveSession")),
    },
    {
      action: "openHelp",
      run: (config) => openPanel(() => openHelpOverlay(config)),
    },
  ];

  function tryHandleGlobalActions(event: KeyboardEvent, config: KeybindingsConfig): boolean {
    // Block all actions when a panel is already open — user must close it first.
    if (hasLivePanelHost()) return false;

    for (const registration of globalActionRegistry) {
      if (!matchesAction(event, config, "global", registration.action)) continue;
      event.preventDefault();
      event.stopPropagation();
      registration.run(config);
      return true;
    }

    return false;
  }

  function globalKeyHandler(event: KeyboardEvent): void {
    if (!cachedConfig) {
      // Retry in-case initial keybinding fetch failed during tab startup.
      requestConfigLoad().catch(() => {});
      // Fallback to defaults so first keypress on a fresh tab still works.
      if (tryHandleGlobalActions(event, DEFAULT_KEYBINDINGS)) return;
      return;
    }
    const config = cachedConfig;

    void tryHandleGlobalActions(event, config);
  }

  document.addEventListener("keydown", globalKeyHandler, true);

  // -- Message Router --
  function messageHandler(message: unknown): Promise<unknown> | undefined {
    const receivedMessage = message as ContentRuntimeMessage;
    switch (receivedMessage.type) {
      case "GET_SCROLL":
        return Promise.resolve({
          scrollX: window.scrollX,
          scrollY: window.scrollY,
        });
      case "SET_SCROLL":
        window.scrollTo({
          left: Math.max(0, receivedMessage.scrollX),
          top: clampScrollY(receivedMessage.scrollY),
          behavior: receivedMessage.smooth ? "smooth" : "auto",
        });
        return Promise.resolve({ ok: true });
      case "GET_ANCHOR_LABEL_CONTEXT":
        return Promise.resolve(getAnchorLabelContext(receivedMessage.scrollY));
      case "OPEN_ANCHOR_TAGS":
        if (!hasLivePanelHost())
          getConfig().then((config) => openPanel(() => openAnchorTags(config)))
            .catch(() => showFeedback(toastMessages.panelOpenFailed));
        return Promise.resolve({ ok: true });
      case "OPEN_TAB_MANAGER":
        if (!hasLivePanelHost())
          getConfig().then((config) => openPanel(() => openTabManager(config)))
            .catch(() => showFeedback(toastMessages.panelOpenFailed));
        return Promise.resolve({ ok: true });
      case "OPEN_SESSIONS":
        if (!hasLivePanelHost())
          getConfig().then((config) => openPanel(() => openSessionMenu(config)))
            .catch(() => showFeedback(toastMessages.panelOpenFailed));
        return Promise.resolve({ ok: true });
      case "SHOW_SESSION_RESTORE":
        if (!hasLivePanelHost())
          openSessionRestoreOverlay();
        return Promise.resolve({ ok: true });
      case "ANCHOR_TAG_FEEDBACK":
        showFeedback(receivedMessage.message);
        return Promise.resolve({ ok: true });
      case "ANCHOR_TAGS_UPDATED":
        anchorTagPageOverlay.update(receivedMessage.entries, receivedMessage.activeSlot);
        return Promise.resolve({ ok: true });
      case "TAB_MANAGER_ADDED_FEEDBACK":
        showFeedback(
          receivedMessage.alreadyAdded
            ? toastMessages.tabManagerAlreadyAdded(receivedMessage.slot)
            : toastMessages.tabManagerAdded(receivedMessage.slot),
        );
        return Promise.resolve({ ok: true });
      case "TAB_MANAGER_FULL_FEEDBACK":
        showFeedback(toastMessages.tabManagerFull(receivedMessage.max));
        return Promise.resolve({ ok: true });
    }
  }

  browser.runtime.onMessage.addListener(messageHandler);

  // Signal background that this content script is ready to receive messages
  // (used for deferred scroll restoration on re-opened tabs)
  notifyContentScriptReady().catch(() => {});

  // Auto-close panels when switching tabs/windows
  function visibilityHandler(): void {
    if (document.visibilityState === "hidden") {
      dismissPanel();
    }
  }

  document.addEventListener("visibilitychange", visibilityHandler);

  // Allow next injection to clean up this one
  window.__anchorTagsCleanup = () => {
    document.removeEventListener("keydown", globalKeyHandler, true);
    document.removeEventListener("visibilitychange", visibilityHandler);
    browser.runtime.onMessage.removeListener(messageHandler);
    const host = document.getElementById("ht-panel-host");
    if (host) host.remove();
    const toast = document.getElementById("ht-feedback-toast");
    if (toast) toast.remove();
    anchorTagPageOverlay.destroy();
  };
}
