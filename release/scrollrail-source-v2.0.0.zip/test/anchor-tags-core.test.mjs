import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { transform } from "esbuild";

const ROOT = process.cwd();

async function loadAnchorTagsCoreModule() {
  const source = readFileSync(
    resolve(ROOT, "src/lib/core/anchorTags/anchorTagsCore.ts"),
    "utf8",
  );

  const transformed = await transform(source, {
    loader: "ts",
    format: "esm",
    target: "es2022",
  });

  const encoded = Buffer.from(transformed.code, "utf8").toString("base64");
  return import(`data:text/javascript;base64,${encoded}`);
}

function anchor(scrollY, createdAt = scrollY) {
  return {
    tabId: 1,
    url: "https://example.com",
    slot: 99,
    scrollX: 0,
    scrollY,
    label: `Anchor ${scrollY}`,
    isCustomLabel: false,
    createdAt,
  };
}

test("anchorTagsCore sorts top-down and compacts slots", async () => {
  const core = await loadAnchorTagsCoreModule();
  const sorted = core.sortAndCompactAnchorTags([
    anchor(600, 3),
    anchor(100, 2),
    anchor(100, 1),
  ]);

  assert.deepEqual(
    sorted.map((entry) => [entry.scrollY, entry.createdAt, entry.slot]),
    [
      [100, 1, 1],
      [100, 2, 2],
      [600, 3, 3],
    ],
  );
});

test("anchorTagsCore detects near-duplicate anchors", async () => {
  const core = await loadAnchorTagsCoreModule();
  const entries = [anchor(200), anchor(500)];

  assert.equal(core.isDuplicateAnchorTag(entries, 223), true);
  assert.equal(core.isDuplicateAnchorTag(entries, 225), false);
});

test("anchorTagsCore cycles next by viewport position and wraps", async () => {
  const core = await loadAnchorTagsCoreModule();
  const entries = [anchor(100), anchor(400), anchor(900)];

  assert.equal(core.findAnchorCycleTarget(entries, 120, "next").scrollY, 400);
  assert.equal(core.findAnchorCycleTarget(entries, 900, "next").scrollY, 100);
});

test("anchorTagsCore cycles previous by viewport position and wraps", async () => {
  const core = await loadAnchorTagsCoreModule();
  const entries = [anchor(100), anchor(400), anchor(900)];

  assert.equal(core.findAnchorCycleTarget(entries, 880, "prev").scrollY, 400);
  assert.equal(core.findAnchorCycleTarget(entries, 100, "prev").scrollY, 900);
});

test("anchorTagsCore calculates clamped page percentages", async () => {
  const core = await loadAnchorTagsCoreModule();

  assert.equal(core.calculateAnchorPagePercent(250, 1000), 25);
  assert.equal(core.calculateAnchorPagePercent(1200, 1000), 100);
  assert.equal(core.calculateAnchorPagePercent(50, 0), 0);
});
