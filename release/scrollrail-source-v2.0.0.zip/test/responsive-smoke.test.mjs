import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const ROOT = process.cwd();

function readText(pathFromRoot) {
  return readFileSync(resolve(ROOT, pathFromRoot), "utf8");
}

const SINGLE_PANEL_FILES = [
  "src/lib/ui/panels/anchorTags/anchorTags.css",
  "src/lib/ui/panels/sessionMenu/sessionMenu.css",
  "src/lib/ui/panels/tabManager/tabManager.css",
  "src/lib/ui/panels/sessionMenu/session.css",
  "src/lib/ui/panels/help/help.css",
];

test("split overlays collapse into one column on narrow viewports", () => {
  const splitLayoutFiles = ["src/lib/ui/panels/sessionMenu/sessionMenu.css"];
  for (const file of splitLayoutFiles) {
    const css = readText(file);
    assert.match(css, /@media \(max-width:\s*860px\)/, `${file} missing 860px responsive media query`);
    assert.match(css, /grid-template-columns:\s*minmax\(0,\s*1fr\)/, `${file} must collapse columns on small screens`);
  }
});

test("all overlays include mobile tightening for small devices", () => {
  for (const file of SINGLE_PANEL_FILES) {
    const css = readText(file);
    assert.match(css, /@media \(max-width:/, `${file} missing responsive media query`);
  }
});

test("single-panel overlays reduce corner radius on compact screens", () => {
  for (const file of SINGLE_PANEL_FILES) {
    const css = readText(file);
    assert.match(css, /border-radius:\s*8px/, `${file} should tighten radius in compact media query`);
  }
});
