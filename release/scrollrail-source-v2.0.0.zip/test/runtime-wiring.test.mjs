import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, "..");

function readText(pathFromRoot) {
  return readFileSync(resolve(root, pathFromRoot), "utf8");
}

test("background runtime entry composes handlers/domains/lifecycle modules", () => {
  const source = readText("src/entryPoints/backgroundRuntime/background.ts");

  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/handlers\/anchorTagsMessageHandler"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/handlers\/commandRouter"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/handlers\/runtimeRouter"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/handlers\/sessionMessageHandler"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/handlers\/tabManagerMessageHandler"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/domains\/anchorTagsDomain"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/domains\/tabManagerDomain"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/lifecycle\/startupRestore"/);

  assert.match(source, /registerRuntimeMessageRouter\(\s*\[/);
  assert.match(source, /createAnchorTagsMessageHandler\(anchorTags\)/);
  assert.match(source, /createTabManagerMessageHandler\(tabManager\)/);
  assert.match(source, /createSessionMessageHandler\(tabManager\.state\)/);
  assert.match(source, /miscMessageHandler/);

  assert.match(source, /registerStartupRestore\(/);
  assert.match(source, /clearTabManager:\s*async\s*\(\)\s*=>\s*await tabManager\.clearAll\(\)/);
});

test("anchor tags runtime handler preserves core message routing", () => {
  const source = readText("src/lib/backgroundRuntime/handlers/anchorTagsMessageHandler.ts");

  assert.match(source, /case "ANCHOR_TAG_ADD":[\s\S]*domain\.addCurrentTab\(\)/);
  assert.match(source, /case "ANCHOR_TAG_LIST":[\s\S]*domain\.listCurrentTab\(sender\.tab\?\.id,\s*sender\.tab\?\.url/);
  assert.match(source, /case "ANCHOR_TAG_REMOVE":[\s\S]*domain\.removeCurrentTabSlot\(message\.slot\)/);
  assert.match(source, /case "ANCHOR_TAG_RENAME":[\s\S]*domain\.renameCurrentTabSlot\(message\.slot,\s*message\.label\)/);
  assert.match(source, /case "ANCHOR_TAG_RESTORE":[\s\S]*domain\.restoreCurrentTabEntry\(message\.entry\)/);
  assert.match(source, /case "ANCHOR_TAG_CYCLE":[\s\S]*domain\.cycleCurrentTab\(message\.direction\)/);
  assert.match(source, /case "ANCHOR_TAG_JUMP":[\s\S]*domain\.jumpCurrentTabSlot\(message\.slot\)/);
});

test("tab manager runtime handler preserves core message routing", () => {
  const source = readText("src/lib/backgroundRuntime/handlers/tabManagerMessageHandler.ts");

  assert.match(source, /case "TAB_MANAGER_ADD":[\s\S]*domain\.add\(tab\)/);
  assert.match(source, /case "TAB_MANAGER_REMOVE":[\s\S]*domain\.remove\(message\.tabId\)/);
  assert.match(source, /case "TAB_MANAGER_RENAME":[\s\S]*domain\.rename\(message\.tabId,\s*message\.label\)/);
  assert.match(source, /case "TAB_MANAGER_LIST":[\s\S]*domain\.list\(\)/);
  assert.match(source, /case "TAB_MANAGER_JUMP":[\s\S]*domain\.jump\(message\.slot\)/);
  assert.match(source, /case "TAB_MANAGER_CYCLE":[\s\S]*domain\.cycle\(message\.direction\)/);
  assert.match(source, /case "TAB_MANAGER_REORDER":[\s\S]*domain\.reorder\(message\.list\)/);
});

test("session runtime handler preserves save-load-delete-rename routing", () => {
  const source = readText("src/lib/backgroundRuntime/handlers/sessionMessageHandler.ts");

  assert.match(source, /case "SESSION_SAVE":[\s\S]*sessionSave\(tabManagerState,\s*message\.name\)/);
  assert.match(source, /case "SESSION_LIST":[\s\S]*sessionList\(\)/);
  assert.match(source, /case "SESSION_LOAD_PLAN":[\s\S]*sessionLoadPlan\(tabManagerState,\s*message\.name\)/);
  assert.match(source, /case "SESSION_LOAD":[\s\S]*sessionLoad\(tabManagerState,\s*message\.name\)/);
  assert.match(source, /case "SESSION_DELETE":[\s\S]*sessionDelete\(message\.name\)/);
  assert.match(source, /case "SESSION_RENAME":[\s\S]*sessionRename\(message\.oldName,\s*message\.newName\)/);
  assert.match(source, /case "SESSION_UPDATE":[\s\S]*sessionUpdate\(tabManagerState,\s*message\.name\)/);
  assert.match(source, /case "SESSION_REPLACE":[\s\S]*sessionReplace\(tabManagerState,\s*message\.oldName,\s*message\.newName\)/);
});

test("session panel keeps save/load preflight + execution wiring", () => {
  const source = readText("src/lib/ui/panels/sessionMenu/session.ts");

  assert.match(source, /loadSessionPlanByName\(target\.name\)/);
  assert.match(source, /await loadSessionByName\(session\.name\)/);
  assert.match(source, /await saveSessionByName\(name\.trim\(\)\)/);
  assert.match(source, /await updateSession\(session\.name\)/);
  assert.match(source, /await deleteSessionByNameRemote\(name\)/);
});

test("anchor tags panel keeps add-cycle-editing wiring", () => {
  const source = readText("src/lib/ui/panels/anchorTags/anchorTags.ts");

  assert.match(source, /addCurrentAnchorTag\(\)/);
  assert.match(source, /jumpToAnchorTag\(tag\.slot\)/);
  assert.match(source, /renameAnchorTag\(renameSlot,\s*nextLabel\)/);
  assert.match(source, /removeAnchorTag\(slot\)/);
  assert.match(source, /restoreAnchorTag\(undoEntry\)/);
  assert.doesNotMatch(source, /buildMarkerRailHtml/);
});

test("tab manager panel keeps rename wiring", () => {
  const source = readText("src/lib/ui/panels/tabManager/tabManager.ts");

  assert.match(source, /renameTabManagerEntry\(renameTabId,\s*nextLabel\)/);
  assert.match(source, /matchesAction\(event,\s*config,\s*"tabManager",\s*"rename"\)/);
  assert.match(source, /class="ht-tab-manager-rename-input"/);
  assert.match(source, /config\.bindings\.tabManager\.rename\.key/);
});

test("anchor tags page overlay is initialized and updated from content messages", () => {
  const appInitSource = readText("src/lib/appInit/appInit.ts");
  const overlaySource = readText("src/lib/ui/overlays/anchorTagPageOverlay.ts");

  assert.match(appInitSource, /from "\.\.\/ui\/overlays\/anchorTagPageOverlay"/);
  assert.match(appInitSource, /initAnchorTagPageOverlay\(\)/);
  assert.match(appInitSource, /case "ANCHOR_TAGS_UPDATED":[\s\S]*anchorTagPageOverlay\.update\(receivedMessage\.entries,\s*receivedMessage\.activeSlot\)/);
  assert.match(appInitSource, /anchorTagPageOverlay\.destroy\(\)/);

  assert.match(overlaySource, /listAnchorTagsWithRetry\(\)/);
  assert.match(overlaySource, /calculateAnchorPagePercent\(tag\.scrollY,\s*maxScrollY\)/);
  assert.match(overlaySource, /sortAndCompactAnchorTags\(entries\)/);
});
