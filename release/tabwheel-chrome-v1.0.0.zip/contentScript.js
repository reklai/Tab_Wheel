"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/appInit/appInit.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/tabWheel.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var TABWHEEL_STORAGE_KEYS = {
    settings: "tabWheelSettings",
    scrollMemory: "tabWheelScrollMemory",
    wheelList: "tabWheelWheelList"
  };
  var TABWHEEL_MODIFIER_KEYS = [
    "alt",
    "ctrl",
    "meta"
  ];
  var TABWHEEL_CYCLE_SCOPES = ["general", "tagged"];
  var TABWHEEL_PRESETS = ["precise", "balanced", "fast", "custom"];
  var MIN_WHEEL_SENSITIVITY = 0.5;
  var MAX_WHEEL_SENSITIVITY = 2;
  var MIN_WHEEL_COOLDOWN_MS = 60;
  var MAX_WHEEL_COOLDOWN_MS = 400;
  var TABWHEEL_PRESET_VALUES = {
    precise: {
      wheelSensitivity: 0.8,
      wheelCooldownMs: 220,
      wheelAcceleration: false,
      overshootGuard: true
    },
    balanced: {
      wheelSensitivity: 1,
      wheelCooldownMs: 160,
      wheelAcceleration: false,
      overshootGuard: true
    },
    fast: {
      wheelSensitivity: 1.35,
      wheelCooldownMs: 90,
      wheelAcceleration: true,
      overshootGuard: true
    }
  };
  var DEFAULT_TABWHEEL_SETTINGS = {
    invertScroll: false,
    gestureModifier: "alt",
    gestureWithShift: false,
    allowGesturesInEditableFields: true,
    cycleScope: "general",
    skipPinnedTabs: false,
    wrapAround: true,
    wheelPreset: "balanced",
    wheelSensitivity: 1,
    wheelCooldownMs: 160,
    wheelAcceleration: false,
    horizontalWheel: true,
    overshootGuard: true
  };
  function normalizeModifierKey(value, fallback) {
    return TABWHEEL_MODIFIER_KEYS.includes(value) ? value : fallback;
  }
  function normalizeShiftRequirement(value) {
    return value === true;
  }
  function normalizeEnabledFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeNumberInRange(value, fallback, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.max(min, Math.min(max, numeric));
  }
  function normalizeTabWheelCycleScope(value) {
    return TABWHEEL_CYCLE_SCOPES.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.cycleScope;
  }
  function normalizeWheelPreset(value) {
    return TABWHEEL_PRESETS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.wheelPreset;
  }
  function detectTabWheelPreset(settings) {
    for (const preset of ["precise", "balanced", "fast"]) {
      const presetValues = TABWHEEL_PRESET_VALUES[preset];
      if (settings.wheelSensitivity === presetValues.wheelSensitivity && settings.wheelCooldownMs === presetValues.wheelCooldownMs && settings.wheelAcceleration === presetValues.wheelAcceleration && settings.overshootGuard === presetValues.overshootGuard) {
        return preset;
      }
    }
    return "custom";
  }
  function normalizeTabWheelSettings(value) {
    if (typeof value !== "object" || value === null) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
    const settings = value;
    const normalizedSettings = {
      invertScroll: settings.invertScroll === true,
      gestureModifier: normalizeModifierKey(
        settings.gestureModifier,
        DEFAULT_TABWHEEL_SETTINGS.gestureModifier
      ),
      gestureWithShift: normalizeShiftRequirement(settings.gestureWithShift),
      allowGesturesInEditableFields: normalizeEnabledFlag(
        settings.allowGesturesInEditableFields,
        DEFAULT_TABWHEEL_SETTINGS.allowGesturesInEditableFields
      ),
      cycleScope: normalizeTabWheelCycleScope(settings.cycleScope),
      skipPinnedTabs: normalizeEnabledFlag(
        settings.skipPinnedTabs,
        DEFAULT_TABWHEEL_SETTINGS.skipPinnedTabs
      ),
      wrapAround: normalizeEnabledFlag(
        settings.wrapAround,
        DEFAULT_TABWHEEL_SETTINGS.wrapAround
      ),
      wheelPreset: normalizeWheelPreset(settings.wheelPreset),
      wheelSensitivity: normalizeNumberInRange(
        settings.wheelSensitivity,
        DEFAULT_TABWHEEL_SETTINGS.wheelSensitivity,
        MIN_WHEEL_SENSITIVITY,
        MAX_WHEEL_SENSITIVITY
      ),
      wheelCooldownMs: normalizeNumberInRange(
        settings.wheelCooldownMs,
        DEFAULT_TABWHEEL_SETTINGS.wheelCooldownMs,
        MIN_WHEEL_COOLDOWN_MS,
        MAX_WHEEL_COOLDOWN_MS
      ),
      wheelAcceleration: normalizeEnabledFlag(
        settings.wheelAcceleration,
        DEFAULT_TABWHEEL_SETTINGS.wheelAcceleration
      ),
      horizontalWheel: normalizeEnabledFlag(
        settings.horizontalWheel,
        DEFAULT_TABWHEEL_SETTINGS.horizontalWheel
      ),
      overshootGuard: normalizeEnabledFlag(
        settings.overshootGuard,
        DEFAULT_TABWHEEL_SETTINGS.overshootGuard
      )
    };
    normalizedSettings.wheelPreset = settings.wheelPreset == null ? detectTabWheelPreset(normalizedSettings) : normalizedSettings.wheelPreset;
    return normalizedSettings;
  }
  function formatTabWheelModifierKey(modifier) {
    if (modifier === "ctrl") return "Ctrl";
    if (modifier === "meta") return "Meta";
    return "Alt";
  }
  function formatTabWheelModifierCombo(modifier, withShift) {
    const baseModifier = formatTabWheelModifierKey(modifier);
    return withShift ? `${baseModifier} + Shift` : baseModifier;
  }
  async function loadTabWheelSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.settings);
      return normalizeTabWheelSettings(data[TABWHEEL_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
  }

  // src/lib/common/utils/panelHost.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/common/utils/helpers.ts
  var HTML_ESCAPE = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  var HTML_ESCAPE_RE = /[&<>"']/;
  function escapeHtml(text) {
    if (!HTML_ESCAPE_RE.test(text)) return text;
    return text.replace(/[&<>"']/g, (character) => HTML_ESCAPE[character]);
  }

  // src/lib/common/utils/panelHost.ts
  var activePanelCleanup = null;
  var activePanelFailSafeCleanup = null;
  function invokeCleanupSafely(label, cleanup) {
    if (!cleanup) return;
    try {
      cleanup();
    } catch (error) {
      console.error(`[TabWheel] ${label}:`, error);
    }
  }
  function cleanupPanelFailSafe() {
    const cleanup = activePanelFailSafeCleanup;
    activePanelFailSafeCleanup = null;
    invokeCleanupSafely("Panel fail-safe cleanup failed", cleanup);
  }
  function handlePanelRuntimeFault(label, reason) {
    if (!document.getElementById("ht-panel-host")) return;
    console.error(`[TabWheel] ${label}; dismissing panel.`, reason);
    dismissPanel();
  }
  var EXTENSION_BASE_URL = import_webextension_polyfill2.default.runtime.getURL("");
  function reasonLooksExtensionScoped(reason) {
    if (!reason) return false;
    if (typeof reason === "string") return reason.includes(EXTENSION_BASE_URL);
    if (typeof reason === "object") {
      const maybeError = reason;
      if (typeof maybeError.stack === "string" && maybeError.stack.includes(EXTENSION_BASE_URL)) {
        return true;
      }
      if (typeof maybeError.message === "string" && maybeError.message.includes(EXTENSION_BASE_URL)) {
        return true;
      }
    }
    return false;
  }
  function isPanelRuntimeFaultFromExtension(event) {
    if (typeof event.filename === "string" && event.filename.startsWith(EXTENSION_BASE_URL)) {
      return true;
    }
    if (reasonLooksExtensionScoped(event.error)) return true;
    return reasonLooksExtensionScoped(event.message);
  }
  function registerPanelCleanup(fn) {
    activePanelCleanup = fn;
  }
  function createPanelHost() {
    if (activePanelCleanup) {
      const cleanup = activePanelCleanup;
      activePanelCleanup = null;
      invokeCleanupSafely("Panel cleanup failed while opening a new panel", cleanup);
    }
    cleanupPanelFailSafe();
    const existing = document.getElementById("ht-panel-host");
    if (existing) existing.remove();
    const host = document.createElement("div");
    host.id = "ht-panel-host";
    host.tabIndex = -1;
    host.style.cssText = "position:fixed;inset:0;z-index:2147483647;pointer-events:auto;overscroll-behavior:contain;isolation:isolate;";
    const shadow = host.attachShadow({ mode: "open" });
    document.body.appendChild(host);
    let lastFocusedInPanel = null;
    let pointerInteractionInPanel = false;
    shadow.addEventListener("focusin", (event) => {
      const target = event.target;
      if (target instanceof HTMLElement) {
        lastFocusedInPanel = target;
      }
    });
    shadow.addEventListener("pointerdown", () => {
      pointerInteractionInPanel = true;
    });
    const onGlobalPointerEnd = () => {
      pointerInteractionInPanel = false;
    };
    window.addEventListener("pointerup", onGlobalPointerEnd, true);
    window.addEventListener("pointercancel", onGlobalPointerEnd, true);
    const focusPreferredPanelTarget = () => {
      if (!document.getElementById("ht-panel-host")) return;
      if (lastFocusedInPanel && shadow.contains(lastFocusedInPanel)) {
        lastFocusedInPanel.focus({ preventScroll: true });
        return;
      }
      host.focus({ preventScroll: true });
    };
    let reclaimId = 0;
    host.addEventListener("focusout", () => {
      cancelAnimationFrame(reclaimId);
      reclaimId = requestAnimationFrame(() => {
        if (document.visibilityState !== "visible") return;
        if (pointerInteractionInPanel) return;
        if (!document.getElementById("ht-panel-host")) return;
        const activeInHostTree = document.activeElement === host || host.contains(document.activeElement);
        const activeInShadow = !!shadow.activeElement && shadow.contains(shadow.activeElement);
        if (!activeInHostTree && !activeInShadow) {
          focusPreferredPanelTarget();
        }
      });
    });
    const onVisibilityChange = () => {
      if (document.visibilityState !== "visible") return;
      if (!document.getElementById("ht-panel-host")) return;
      const activeInHostTree = document.activeElement === host || host.contains(document.activeElement);
      const activeInShadow = !!shadow.activeElement && shadow.contains(shadow.activeElement);
      if (!activeInHostTree && !activeInShadow) {
        focusPreferredPanelTarget();
      }
    };
    document.addEventListener("visibilitychange", onVisibilityChange);
    const onError = (event) => {
      if (!isPanelRuntimeFaultFromExtension(event)) return;
      handlePanelRuntimeFault("Panel runtime error", event.error || event.message);
    };
    const onUnhandledRejection = (event) => {
      if (!reasonLooksExtensionScoped(event.reason)) return;
      handlePanelRuntimeFault("Panel unhandled rejection", event.reason);
    };
    let lastAnimationFrameAt = performance.now();
    let frameProbeId = 0;
    const frameProbe = (ts) => {
      lastAnimationFrameAt = ts;
      frameProbeId = requestAnimationFrame(frameProbe);
    };
    frameProbeId = requestAnimationFrame(frameProbe);
    const watchdogIntervalId = window.setInterval(() => {
      if (!document.getElementById("ht-panel-host")) return;
      if (document.visibilityState !== "visible") return;
      const gapMs = performance.now() - lastAnimationFrameAt;
      if (gapMs > 3e3) {
        handlePanelRuntimeFault("Panel watchdog detected UI stall", { gapMs });
      }
    }, 1e3);
    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onUnhandledRejection);
    activePanelFailSafeCleanup = () => {
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onUnhandledRejection);
      window.removeEventListener("pointerup", onGlobalPointerEnd, true);
      window.removeEventListener("pointercancel", onGlobalPointerEnd, true);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      cancelAnimationFrame(frameProbeId);
      window.clearInterval(watchdogIntervalId);
    };
    return { host, shadow };
  }
  function removePanelHost() {
    cleanupPanelFailSafe();
    const host = document.getElementById("ht-panel-host");
    if (host) host.remove();
    activePanelCleanup = null;
  }
  function dismissPanel() {
    const cleanup = activePanelCleanup;
    activePanelCleanup = null;
    invokeCleanupSafely("Panel cleanup failed during dismiss", cleanup);
    removePanelHost();
  }
  function footerHintHtml(hint) {
    const activeClass = hint.active ? " ht-footer-hint-active" : "";
    return `<span class="ht-footer-hint${activeClass}">
    <strong class="ht-footer-key">${escapeHtml(hint.key)}</strong>
    <span class="ht-footer-desc">${escapeHtml(hint.desc)}</span>
  </span>`;
  }
  function footerRowHtml(hints) {
    if (hints.length === 0) return `<div class="ht-footer-row"></div>`;
    const pieces = [];
    for (let i = 0; i < hints.length; i++) {
      if (i > 0) {
        pieces.push(`<span class="ht-footer-sep" aria-hidden="true">|</span>`);
      }
      pieces.push(footerHintHtml(hints[i]));
    }
    return `<div class="ht-footer-row">${pieces.join("")}</div>`;
  }
  function getBaseStyles() {
    return `
    * { margin: 0; padding: 0; box-sizing: border-box; }

    :host {
      all: initial;
      --ht-font-mono: 'SF Mono', 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
      --ht-color-bg: #1e1e1e;
      --ht-color-bg-elevated: #252525;
      --ht-color-bg-soft: #3a3a3c;
      --ht-color-bg-detail-focus: #1a2230;
      --ht-color-bg-detail-focus-header: #1e2a3a;
      --ht-color-bg-code: #1a1a1a;
      --ht-color-text: #e0e0e0;
      --ht-color-text-soft: #c0c0c0;
      --ht-color-text-muted: #808080;
      --ht-color-text-title: #a0a0a0;
      --ht-color-text-detail-focus: #a0c0e0;
      --ht-color-text-dim: #666;
      --ht-color-text-faint: #555;
      --ht-color-text-strong: #fff;
      --ht-color-accent: #0a84ff;
      --ht-color-accent-soft: rgba(10,132,255,0.1);
      --ht-color-accent-active: rgba(10,132,255,0.15);
      --ht-color-accent-soft-strong: rgba(10,132,255,0.12);
      --ht-color-accent-soft-faint: rgba(10,132,255,0.08);
      --ht-color-accent-alt: #af82ff;
      --ht-color-accent-alt-soft: rgba(175,130,255,0.15);
      --ht-color-success: #32d74b;
      --ht-color-tree-cursor: #4ec970;
      --ht-color-tree-cursor-bg: rgba(78,201,112,0.15);
      --ht-color-tree-cursor-bg-soft: rgba(78,201,112,0.18);
      --ht-color-tree-cursor-bg-strong: rgba(78,201,112,0.20);
      --ht-color-danger: #ff5f57;
      --ht-color-warning: #febc2e;
      --ht-color-mark-bg: #f9d45c;
      --ht-color-mark-fg: #1e1e1e;
      --ht-color-border: rgba(255,255,255,0.1);
      --ht-color-border-soft: rgba(255,255,255,0.06);
      --ht-color-border-faint: rgba(255,255,255,0.04);
      --ht-color-border-ultra-faint: rgba(255,255,255,0.03);
      --ht-color-hover: rgba(255,255,255,0.06);
      --ht-color-focus-active: rgba(255,255,255,0.13);
      --ht-color-surface: rgba(255,255,255,0.08);
      --ht-color-surface-dim: rgba(255,255,255,0.04);
      --ht-color-surface-strong: rgba(255,255,255,0.15);
      --ht-shadow-overlay: 0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.05);
      --ht-radius: 10px;
      --ht-input-row-pad-y: 8px;
      --ht-input-row-pad-x: 14px;
      --ht-input-row-pad-x-compact: 10px;
      --ht-input-prompt-gap: 8px;
      --ht-input-prompt-size: 14px;
      --ht-input-prompt-weight: 600;
      --ht-input-font-size: 13px;
      --ht-input-caret-color: var(--ht-color-text-strong);
      --ht-pane-header-pad-y: 5px;
      --ht-pane-header-pad-x: 14px;
      --ht-pane-header-font-size: 11px;
      --ht-pane-header-weight: 500;
      font-family: var(--ht-font-mono);
      font-size: 13px;
      color: var(--ht-color-text);
      -webkit-font-smoothing: antialiased;
      text-rendering: optimizeLegibility;
    }

    .ht-backdrop {
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
      width: 100dvw; height: 100dvh;
      background: rgba(0, 0, 0, 0.55);
    }

    /* Keep every overlay shell truly centered, even if panel-specific
       rules regress or are partially overridden. */
    .ht-help-container {
      position: fixed !important;
      top: 50% !important;
      left: 50% !important;
      transform: translate(-50%, -50%) !important;
      margin: 0 !important;
    }

    .ht-titlebar {
      display: flex; align-items: center;
      padding: 10px 14px;
      background: var(--ht-color-bg-soft);
      border-bottom: 1px solid var(--ht-color-border-soft);
      border-radius: var(--ht-radius) var(--ht-radius) 0 0;
      user-select: none;
    }
    .ht-traffic-lights {
      display: flex; gap: 7px; margin-right: 14px; flex-shrink: 0;
    }
    .ht-dot {
      width: 12px; height: 12px; border-radius: 50%;
      cursor: pointer; border: none;
      transition: filter 0.15s;
    }
    .ht-dot:hover { filter: brightness(1.2); }
    .ht-dot-close { background: var(--ht-color-danger); }
    .ht-titlebar-text {
      flex: 1; text-align: center; font-size: 12px;
      color: var(--ht-color-text-title); font-weight: 500;
    }

    /* Reusable UI primitives (input rows + pane headers) for panel consistency */
    .ht-ui-input-wrap {
      display: flex;
      align-items: center;
      padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x);
      border-bottom: 1px solid var(--ht-color-border-soft);
      background: var(--ht-color-bg-elevated);
    }
    .ht-ui-input-prompt {
      color: var(--ht-color-accent);
      margin-right: var(--ht-input-prompt-gap);
      font-weight: var(--ht-input-prompt-weight);
      font-size: var(--ht-input-prompt-size);
    }
    .ht-ui-input-field {
      flex: 1;
      background: transparent;
      border: none;
      outline: none;
      color: var(--ht-color-text);
      font-family: inherit;
      font-size: var(--ht-input-font-size);
      caret-color: var(--ht-input-caret-color);
    }
    input,
    textarea {
      user-select: text;
      -webkit-user-select: text;
    }
    .ht-ui-input-field::placeholder {
      color: var(--ht-color-text-dim);
    }
    .ht-ui-pane-header {
      padding: var(--ht-pane-header-pad-y) var(--ht-pane-header-pad-x);
      font-size: var(--ht-pane-header-font-size);
      color: var(--ht-color-text-muted);
      background: var(--ht-color-bg-elevated);
      border-bottom: 1px solid var(--ht-color-border-faint);
      font-weight: var(--ht-pane-header-weight);
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .ht-ui-pane-header-text {
      flex: 1;
    }
    .ht-ui-pane-header-meta {
      font-size: 10px;
      color: var(--ht-color-text-dim);
      flex-shrink: 0;
    }

    .ht-vim-badge {
      font-size: 9px; font-weight: 700; letter-spacing: 0.5px;
      padding: 2px 6px; border-radius: 4px;
      text-transform: uppercase; flex-shrink: 0;
      line-height: 1; margin-left: 8px;
    }
    .ht-vim-badge.on {
      background: var(--ht-color-success); color: #1a1a1a;
    }
    .ht-vim-badge.off {
      background: var(--ht-color-surface); color: var(--ht-color-text-dim);
    }

    .ht-footer {
      display: flex; gap: 16px; padding: 8px 14px;
      background: var(--ht-color-bg-elevated); border-top: 1px solid var(--ht-color-border-soft);
      font-size: 11px; color: var(--ht-color-text-muted); flex-wrap: wrap;
      border-radius: 0 0 var(--ht-radius) var(--ht-radius); justify-content: center;
    }
    .ht-footer-row {
      display: flex; gap: 8px; justify-content: center; width: 100%; flex-wrap: wrap;
      align-items: center;
    }
    .ht-footer-hint {
      display: inline-flex;
      align-items: baseline;
      gap: 4px;
      white-space: nowrap;
      color: var(--ht-color-text-muted);
    }
    .ht-footer-key {
      color: var(--ht-color-text-soft);
      font-weight: 700;
    }
    .ht-footer-sep {
      color: var(--ht-color-text-dim);
      font-weight: 600;
    }

    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation: none !important;
        transition: none !important;
      }
    }

    @media (max-width: 520px), (max-height: 560px) {
      .ht-ui-input-wrap {
        padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x-compact);
      }
    }
  `;
  }

  // src/lib/core/tabWheel/tabWheelCore.ts
  function resolveWheelDirection(wheelDeltaY, invertScroll) {
    const normalDirection = wheelDeltaY > 0 ? "next" : "prev";
    if (!invertScroll) return normalDirection;
    return normalDirection === "next" ? "prev" : "next";
  }
  function normalizeWheelDeltaY(event, pageHeight) {
    if (event.deltaMode === 1) return event.deltaY * 16;
    if (event.deltaMode === 2) return event.deltaY * pageHeight;
    return event.deltaY;
  }
  function normalizeWheelDelta(event, pageHeight, pageWidth, horizontalWheel) {
    const normalizedY = normalizeWheelDeltaY(event, pageHeight);
    if (!horizontalWheel) return normalizedY;
    const normalizedX = event.deltaMode === 1 ? event.deltaX * 16 : event.deltaMode === 2 ? event.deltaX * pageWidth : event.deltaX;
    return Math.abs(normalizedX) > Math.abs(normalizedY) ? normalizedX : normalizedY;
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());
  var DEFAULT_RUNTIME_RETRY_POLICY = {
    retryDelaysMs: [0, 80, 220, 420]
  };
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill3.default.runtime.sendMessage(message);
  }
  async function sendRuntimeMessageWithRetry(message, policy = DEFAULT_RUNTIME_RETRY_POLICY) {
    let lastError = null;
    for (const delay of policy.retryDelaysMs) {
      if (delay > 0) {
        await sleep(delay);
      }
      try {
        return await sendRuntimeMessage(message);
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error(`Runtime message failed: ${message.type}`);
  }

  // src/lib/adapters/runtime/tabWheelApi.ts
  function getTabWheelOverviewWithRetry(windowId, policy = { retryDelaysMs: [0, 90, 240, 450] }) {
    return sendRuntimeMessageWithRetry(
      { type: "TABWHEEL_GET_OVERVIEW", windowId },
      policy
    );
  }
  function cycleTabWheel(direction) {
    return sendRuntimeMessage({
      type: "TABWHEEL_CYCLE",
      direction
    });
  }
  function toggleCurrentTabWheelTag(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_TOGGLE_CURRENT_TAG",
      windowId
    });
  }
  function toggleTabWheelCycleScope(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_TOGGLE_CYCLE_SCOPE",
      windowId
    });
  }
  function fetchTabWheelFaviconData(href) {
    return sendRuntimeMessage({
      type: "TABWHEEL_FETCH_FAVICON",
      href
    });
  }
  function saveTabWheelScrollPosition(scrollX, scrollY) {
    return sendRuntimeMessage({
      type: "TABWHEEL_SAVE_SCROLL_POSITION",
      scrollX,
      scrollY
    });
  }
  function openTabWheelOptions() {
    return sendRuntimeMessage({ type: "TABWHEEL_OPEN_OPTIONS" });
  }

  // src/lib/ui/panels/help/help.css
  var help_default = ".ht-help-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(94vw, 680px); max-height: min(88vh, 760px); background: var(--ht-color-bg);\n  border: 1px solid var(--ht-color-border); border-radius: var(--ht-radius);\n  display: flex; flex-direction: column; overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-help-titlebar-text {\n  flex: 1; text-align: left; font-size: 12px; color: var(--ht-color-text);\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n}\n.ht-help-title-label { color: var(--ht-color-text-title); }\n.ht-help-settings {\n  width: 26px; height: 26px; border-radius: 6px; border: 1px solid var(--ht-color-border-soft);\n  background: var(--ht-color-surface-dim); color: var(--ht-color-text);\n  font: inherit; line-height: 1; cursor: pointer; flex-shrink: 0;\n}\n.ht-help-settings:hover { background: var(--ht-color-hover); }\n.ht-help-settings:focus-visible {\n  outline: 1px solid var(--ht-color-accent);\n  outline-offset: 2px;\n}\n.ht-help-body {\n  flex: 1; overflow-y: auto; padding: 8px 0;\n  scroll-behavior: auto;\n}\n.ht-help-section { margin-bottom: 4px; }\n.ht-help-header {\n  display: flex; align-items: center; padding: 6px 20px;\n  font-size: 11px; font-weight: 700; text-transform: uppercase;\n  letter-spacing: 0; color: var(--ht-color-accent);\n  user-select: none;\n}\n.ht-help-section-centered {\n  padding: 8px 18px 12px;\n  text-align: center;\n}\n.ht-help-section-centered .ht-help-header {\n  justify-content: center;\n  padding: 6px 0 8px;\n}\n.ht-help-steps {\n  display: grid;\n  gap: 7px;\n  justify-items: center;\n}\n.ht-help-step {\n  width: min(100%, 520px);\n  padding: 7px 10px;\n  border: 1px solid var(--ht-color-border-soft);\n  border-radius: 6px;\n  background: var(--ht-color-surface-dim);\n  color: var(--ht-color-text);\n  font-size: 12px;\n  line-height: 1.45;\n  overflow-wrap: anywhere;\n}\n.ht-help-items { overflow: hidden; }\n.ht-help-row {\n  display: flex; align-items: center; justify-content: space-between;\n  padding: 4px 20px 4px 38px; font-size: 12px; cursor: default;\n}\n.ht-help-label { color: var(--ht-color-text-soft); min-width: 0; }\n.ht-help-key {\n  font-size: 11px; color: var(--ht-color-text); background: var(--ht-color-surface);\n  padding: 2px 8px; border-radius: 4px; font-weight: 600;\n  white-space: normal; flex-shrink: 1; margin-left: 12px;\n  max-width: 70%; text-align: right; overflow-wrap: anywhere;\n}\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-help-container { border-radius: 8px; }\n  .ht-help-row { padding: 4px 10px 4px 12px; font-size: 11px; }\n  .ht-help-header { padding: 6px 10px; }\n  .ht-help-key { margin-left: 8px; padding: 2px 6px; }\n  .ht-help-section-centered { padding: 6px 10px 10px; }\n  .ht-help-step { font-size: 11px; padding: 6px 8px; }\n}\n";

  // src/lib/ui/panels/help/help.ts
  var SCROLL_STEP = 80;
  function buildHelpSections(settings) {
    const gestureModifier = formatTabWheelModifierCombo(settings.gestureModifier, settings.gestureWithShift);
    const editableFields = settings.allowGesturesInEditableFields ? "Allow wheel-cycling when cursor is inside text boxes, search fields, and editors/docs" : "Skip wheel-cycling when cursor is inside text boxes, search fields, and editors/docs";
    const cycleScope = settings.cycleScope === "tagged" ? "Wheel List" : "General";
    return [
      {
        title: "How To Use",
        layout: "centered",
        items: [
          { value: `${gestureModifier} + Wheel switches tabs using the current cycle mode` },
          { value: `${gestureModifier} + Left Click adds or removes this tab from the Wheel List` },
          { value: `${gestureModifier} + Right Click switches between General and Wheel List mode` }
        ]
      },
      {
        title: "Caveats",
        layout: "centered",
        items: [
          { value: "Modifier-click caveat: modifier + left/right click can be reserved by sites, browsers, or the OS; change modifier or require Shift if it conflicts" },
          { value: "Extension constraints: page gestures work on normal web pages; browser UI, stores, PDFs, and internal pages can block content scripts" }
        ]
      },
      {
        title: "Shortcuts",
        items: [
          { label: "Switch tabs", value: `${gestureModifier} + Wheel` },
          { label: "Add/remove tab", value: `${gestureModifier} + Left Click` },
          { label: "Change mode", value: `${gestureModifier} + Right Click` },
          { label: "Editable fields", value: editableFields },
          { label: "Wheel down/right", value: settings.invertScroll ? "goes to previous tab" : "goes to next tab" },
          { label: "Wheel up/left", value: settings.invertScroll ? "goes to next tab" : "goes to previous tab" }
        ]
      },
      {
        title: "Cycle Modes",
        items: [
          { label: "Current mode", value: cycleScope },
          { label: "General", value: "switch through eligible tabs in visible tab order" },
          { label: "Wheel List", value: "switch only through tabs you added to the Wheel List" },
          { label: "Pinned tabs", value: settings.skipPinnedTabs ? "left out of cycling" : "included in cycling" },
          { label: "Wrap around", value: settings.wrapAround ? "last tab continues to first tab" : "stop at the first or last tab" }
        ]
      },
      {
        title: "Wheel Feel",
        items: [
          { label: "Preset", value: `${settings.wheelPreset} timing profile` },
          { label: "Sensitivity", value: `${settings.wheelSensitivity.toFixed(1)}x wheel distance before switching` },
          { label: "Cooldown", value: `${Math.round(settings.wheelCooldownMs)}ms minimum delay between switches` },
          { label: "Acceleration", value: settings.wheelAcceleration ? "repeated wheel bursts switch faster" : "repeated wheel bursts keep the same delay" },
          { label: "Horizontal wheel", value: settings.horizontalWheel ? "sideways wheel or trackpad motion also switches tabs" : "only vertical wheel movement switches tabs" },
          { label: "Safe overshoot guard", value: settings.overshootGuard ? "prevents extra tab jumps from trackpad or wheel momentum" : "every qualified wheel tick can switch tabs" }
        ]
      }
    ];
  }
  function buildSectionsHtml(sections) {
    return sections.map((section) => {
      const isCentered = section.layout === "centered";
      const itemsHtml = isCentered ? section.items.map((item) => `
          <div class="ht-help-step">${escapeHtml(item.value)}</div>
        `).join("") : section.items.map((item) => `
          <div class="ht-help-row">
            <span class="ht-help-label">${escapeHtml(item.label || "")}</span>
            <span class="ht-help-key">${escapeHtml(item.value)}</span>
          </div>
        `).join("");
      return `
      <section class="ht-help-section${isCentered ? " ht-help-section-centered" : ""}">
        <div class="ht-help-header">${escapeHtml(section.title)}</div>
        <div class="${isCentered ? "ht-help-steps" : "ht-help-items"}">
          ${itemsHtml}
        </div>
      </section>
    `;
    }).join("");
  }
  async function openTabWheelHelpOverlay() {
    try {
      let close2 = function() {
        document.removeEventListener("keydown", keyHandler2, true);
        removePanelHost();
      }, keyHandler2 = function(event) {
        if (!document.getElementById("ht-panel-host")) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopPropagation();
          close2();
          return;
        }
        if (event.key === "ArrowDown" || event.key.toLowerCase() === "j") {
          event.preventDefault();
          event.stopPropagation();
          body.scrollTop += SCROLL_STEP;
          return;
        }
        if (event.key === "ArrowUp" || event.key.toLowerCase() === "k") {
          event.preventDefault();
          event.stopPropagation();
          body.scrollTop -= SCROLL_STEP;
          return;
        }
        event.stopPropagation();
      };
      var close = close2, keyHandler = keyHandler2;
      const settings = await loadTabWheelSettings();
      const { host, shadow } = createPanelHost();
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + help_default;
      shadow.appendChild(style);
      const backdrop = document.createElement("div");
      backdrop.className = "ht-backdrop";
      shadow.appendChild(backdrop);
      const panel = document.createElement("div");
      panel.className = "ht-help-container";
      shadow.appendChild(panel);
      panel.innerHTML = `
      <div class="ht-titlebar">
        <div class="ht-traffic-lights">
          <button class="ht-dot ht-dot-close" title="Close"></button>
        </div>
        <span class="ht-help-titlebar-text">
          <span class="ht-help-title-label">TabWheel Help</span>
        </span>
        <button class="ht-help-settings" data-action="settings" title="Settings" aria-label="Open settings">&#9881;</button>
      </div>
      <div class="ht-help-body">
        ${buildSectionsHtml(buildHelpSections(settings))}
      </div>
      <div class="ht-footer">
        ${footerRowHtml([
        { key: "j/k", desc: "scroll" },
        { key: "ArrowUp/ArrowDown", desc: "scroll" }
      ])}
        ${footerRowHtml([
        { key: "Wheel", desc: "scroll" },
        { key: "Esc", desc: "close" }
      ])}
      </div>
    `;
      const body = panel.querySelector(".ht-help-body");
      const closeButton = panel.querySelector(".ht-dot-close");
      const settingsButton = panel.querySelector('[data-action="settings"]');
      backdrop.addEventListener("click", close2);
      backdrop.addEventListener("mousedown", (event) => event.preventDefault());
      closeButton.addEventListener("click", close2);
      settingsButton.addEventListener("click", async () => {
        const result = await openTabWheelOptions();
        if (!result.ok) {
          console.warn("[TabWheel] Failed to open options:", result.reason);
          return;
        }
        close2();
      });
      document.addEventListener("keydown", keyHandler2, true);
      registerPanelCleanup(close2);
      host.focus();
    } catch (error) {
      console.error("[TabWheel] Failed to open help overlay:", error);
      dismissPanel();
    }
  }

  // src/lib/appInit/appInit.ts
  var SCROLL_SAVE_DEBOUNCE_MS = 700;
  var SCROLL_RESTORE_SUPPRESS_SAVE_MS = 450;
  var WHEEL_TRIGGER_THRESHOLD_PX = 80;
  var WHEEL_ACCELERATION_WINDOW_MS = 700;
  var MIN_ACCELERATED_COOLDOWN_MS = 80;
  var OVERSHOOT_GUARD_MS = 260;
  var STATUS_TIMEOUT_MS = 1500;
  var TAGGED_PILL_ID = "tw-tagged-pill";
  var TAGGED_FAVICON_ATTR = "data-tabwheel-tagged-favicon";
  var TAGGED_FAVICON_RESTORE_ATTR = "data-tabwheel-favicon-restore";
  var TAGGED_INDICATOR_DEBOUNCE_MS = 90;
  var TAGGED_FAVICON_SIZE_PX = 64;
  var TAGGED_FAVICON_LOAD_TIMEOUT_MS = 1200;
  var MAX_ORIGINAL_FAVICON_CACHE_ENTRIES = 20;
  var STATUS_ID = "tw-status-indicator";
  var MOUSE_GESTURE_CLAIM_MS = 900;
  var EVENT_MODIFIER_KEYS = ["alt", "ctrl", "shift", "meta"];
  var SCROLL_RESTORE_DELAYS_MS = [0, 80, 220, 500, 900, 1500, 2400, 3600];
  function isEditableTarget(target) {
    if (!(target instanceof Element)) return false;
    const editable = target.closest(
      "input, textarea, select, [contenteditable=''], [contenteditable='true'], [role='textbox']"
    );
    return editable !== null;
  }
  function isTabWheelModifier(event, modifier, withShift) {
    const modifierState = {
      alt: event.altKey,
      ctrl: event.ctrlKey,
      shift: event.shiftKey,
      meta: event.metaKey
    };
    if (!TABWHEEL_MODIFIER_KEYS.includes(modifier)) return false;
    return EVENT_MODIFIER_KEYS.every((key) => {
      if (key === modifier) return modifierState[key];
      if (key === "shift") return modifierState.shift === withShift;
      return !modifierState[key];
    });
  }
  function clampScrollY(scrollY) {
    const documentElement = document.documentElement;
    const body = document.body;
    const scrollHeight = Math.max(
      documentElement?.scrollHeight || 0,
      body?.scrollHeight || 0,
      documentElement?.offsetHeight || 0,
      body?.offsetHeight || 0
    );
    const maxScrollY = Math.max(0, scrollHeight - window.innerHeight);
    return Math.max(0, Math.min(scrollY, maxScrollY));
  }
  function sleep2(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }
  function suppressPageEvent(event) {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
  }
  function isTopFrame() {
    try {
      return window.top === window;
    } catch (_) {
      return false;
    }
  }
  function cycleScopeLabel(cycleScope) {
    return cycleScope === "tagged" ? "Wheel List" : "General";
  }
  function initApp() {
    if (window.__tabWheelCleanup) {
      window.__tabWheelCleanup();
    }
    const isTopFrameContext = isTopFrame();
    let settings = { ...DEFAULT_TABWHEEL_SETTINGS };
    let statusTimer = 0;
    let scrollSaveTimer = 0;
    let lastScrollSaveX = Number.NaN;
    let lastScrollSaveY = Number.NaN;
    let suppressScrollSaveUntil = 0;
    let scrollRestoreToken = 0;
    let wheelAccumulator = 0;
    let lastWheelCycleAt = 0;
    let wheelBurstCount = 0;
    let overshootGuardDirection = null;
    let overshootGuardUntil = 0;
    let areSettingsLoaded = false;
    let taggedIndicatorRenderTimer = 0;
    let isTaggedIndicatorActive = false;
    let activeTaggedCycleScope = settings.cycleScope;
    const originalFaviconHrefByPageUrl = /* @__PURE__ */ new Map();
    let lastTaggedFaviconHref = "";
    let lastTaggedFaviconSourceHref = "";
    let taggedFaviconRenderId = 0;
    let faviconObserver = null;
    let faviconObserverTarget = null;
    let claimedMouseGesture = null;
    void loadTabWheelSettings().then((loadedSettings) => {
      settings = loadedSettings;
      activeTaggedCycleScope = loadedSettings.cycleScope;
    }).finally(() => {
      areSettingsLoaded = true;
    });
    function showStatus(message) {
      let status = document.getElementById(STATUS_ID);
      if (!status) {
        status = document.createElement("div");
        status.id = STATUS_ID;
        status.setAttribute("role", "status");
        status.style.cssText = [
          "position:fixed",
          "left:50%",
          "top:50%",
          "transform:translate(-50%,-50%)",
          "z-index:2147483646",
          "width:min(360px,calc(100vw - 32px))",
          "min-height:42px",
          "display:flex",
          "align-items:center",
          "justify-content:center",
          "text-align:center",
          "padding:10px 14px",
          "border-radius:8px",
          "border:1px solid rgba(255,255,255,0.14)",
          "background:#1e1e1e",
          "color:#e0e0e0",
          "box-shadow:0 18px 54px rgba(0,0,0,0.44)",
          "font:12px/1.35 'SF Mono','JetBrains Mono','Fira Code','Consolas',monospace",
          "pointer-events:none"
        ].join(";");
        document.documentElement.appendChild(status);
      }
      status.textContent = message;
      if (statusTimer) window.clearTimeout(statusTimer);
      statusTimer = window.setTimeout(() => {
        status?.remove();
        statusTimer = 0;
      }, STATUS_TIMEOUT_MS);
    }
    function getIconLinks(includeTaggedFavicon) {
      return Array.from(document.querySelectorAll("link[rel]")).filter((link) => link.relList.contains("icon")).filter((link) => includeTaggedFavicon || link.getAttribute(TAGGED_FAVICON_ATTR) !== "true");
    }
    function resolveFaviconHref(rawHref) {
      try {
        return new URL(rawHref, document.baseURI).href;
      } catch (_) {
        return rawHref;
      }
    }
    function getCurrentFaviconHref() {
      const iconLinks = getIconLinks(false);
      for (let index = iconLinks.length - 1; index >= 0; index -= 1) {
        const rawHref = iconLinks[index]?.getAttribute("href");
        if (rawHref) return resolveFaviconHref(rawHref);
      }
      return "";
    }
    function getDefaultFaviconHref() {
      try {
        return new URL("/favicon.ico", window.location.origin).href;
      } catch (_) {
        return "";
      }
    }
    function getFaviconCacheKey() {
      return window.location.href;
    }
    function cacheOriginalFaviconHref(pageUrl, originalHref) {
      if (!pageUrl || !originalHref) return;
      if (originalFaviconHrefByPageUrl.has(pageUrl)) {
        originalFaviconHrefByPageUrl.delete(pageUrl);
      }
      originalFaviconHrefByPageUrl.set(pageUrl, originalHref);
      while (originalFaviconHrefByPageUrl.size > MAX_ORIGINAL_FAVICON_CACHE_ENTRIES) {
        const oldestPageUrl = originalFaviconHrefByPageUrl.keys().next().value;
        if (!oldestPageUrl) break;
        originalFaviconHrefByPageUrl.delete(oldestPageUrl);
      }
    }
    function getCachedOriginalFaviconHref(pageUrl) {
      return originalFaviconHrefByPageUrl.get(pageUrl) || "";
    }
    function removeCachedOriginalFaviconHref(pageUrl) {
      originalFaviconHrefByPageUrl.delete(pageUrl);
    }
    function loadTaggedFaviconImage(originalHref) {
      return new Promise((resolve) => {
        const image = new Image();
        let hasSettled = false;
        const timeout = window.setTimeout(() => settle(null), TAGGED_FAVICON_LOAD_TIMEOUT_MS);
        function settle(result) {
          if (hasSettled) return;
          hasSettled = true;
          window.clearTimeout(timeout);
          image.onload = null;
          image.onerror = null;
          resolve(result);
        }
        image.onload = () => settle(image);
        image.onerror = () => settle(null);
        if (originalHref.startsWith("http://") || originalHref.startsWith("https://")) {
          image.crossOrigin = "anonymous";
        }
        image.decoding = "async";
        image.src = originalHref;
      });
    }
    async function buildTaggedFaviconHref(originalHref) {
      if (!originalHref) return null;
      const fetchedFavicon = await fetchTabWheelFaviconData(originalHref).catch(() => null);
      const sourceHref = fetchedFavicon?.ok && fetchedFavicon.dataUrl ? fetchedFavicon.dataUrl : originalHref;
      const image = await loadTaggedFaviconImage(sourceHref);
      if (!image) return null;
      const canvas = document.createElement("canvas");
      canvas.width = TAGGED_FAVICON_SIZE_PX;
      canvas.height = TAGGED_FAVICON_SIZE_PX;
      const context = canvas.getContext("2d");
      if (!context) return null;
      const sourceWidth = image.naturalWidth || image.width || TAGGED_FAVICON_SIZE_PX;
      const sourceHeight = image.naturalHeight || image.height || TAGGED_FAVICON_SIZE_PX;
      const scale = Math.min(TAGGED_FAVICON_SIZE_PX / sourceWidth, TAGGED_FAVICON_SIZE_PX / sourceHeight);
      const width = sourceWidth * scale;
      const height = sourceHeight * scale;
      const x = (TAGGED_FAVICON_SIZE_PX - width) / 2;
      const y = (TAGGED_FAVICON_SIZE_PX - height) / 2;
      context.clearRect(0, 0, TAGGED_FAVICON_SIZE_PX, TAGGED_FAVICON_SIZE_PX);
      context.drawImage(image, x, y, width, height);
      context.beginPath();
      context.fillStyle = "rgba(16, 18, 20, 0.88)";
      context.arc(50, 14, 11, 0, Math.PI * 2);
      context.fill();
      context.beginPath();
      context.fillStyle = "#32d74b";
      context.arc(50, 14, 6.25, 0, Math.PI * 2);
      context.fill();
      try {
        return canvas.toDataURL("image/png");
      } catch (_) {
        return null;
      }
    }
    function removeFaviconRestoreLinks() {
      document.querySelectorAll(`link[${TAGGED_FAVICON_RESTORE_ATTR}="true"]`).forEach((link) => link.remove());
    }
    function restoreOriginalFavicon(originalHref) {
      const head = document.head;
      if (!head || !originalHref) return;
      removeFaviconRestoreLinks();
      const link = document.createElement("link");
      link.setAttribute(TAGGED_FAVICON_RESTORE_ATTR, "true");
      link.rel = "icon";
      link.href = originalHref;
      head.appendChild(link);
    }
    function removeTaggedFavicon() {
      taggedFaviconRenderId += 1;
      const pageUrl = getFaviconCacheKey();
      const originalHref = getCachedOriginalFaviconHref(pageUrl) || lastTaggedFaviconSourceHref || getCurrentFaviconHref() || getDefaultFaviconHref();
      document.querySelectorAll(`link[${TAGGED_FAVICON_ATTR}="true"]`).forEach((link) => link.remove());
      removeCachedOriginalFaviconHref(pageUrl);
      lastTaggedFaviconHref = "";
      lastTaggedFaviconSourceHref = "";
      restoreOriginalFavicon(originalHref);
    }
    function ensureTaggedFavicon() {
      const head = document.head;
      if (!head) return;
      const pageUrl = getFaviconCacheKey();
      const originalHref = getCurrentFaviconHref() || getDefaultFaviconHref();
      if (!originalHref) return;
      cacheOriginalFaviconHref(pageUrl, originalHref);
      removeFaviconRestoreLinks();
      const existingLink = document.querySelector(`link[${TAGGED_FAVICON_ATTR}="true"]`);
      if (existingLink && lastTaggedFaviconSourceHref === originalHref && lastTaggedFaviconHref) {
        if (existingLink.parentElement !== head) head.appendChild(existingLink);
        const iconLinks = getIconLinks(true);
        if (iconLinks[iconLinks.length - 1] !== existingLink) head.appendChild(existingLink);
        return;
      }
      const renderId = ++taggedFaviconRenderId;
      void buildTaggedFaviconHref(originalHref).then((faviconHref) => {
        if (renderId !== taggedFaviconRenderId || !isTaggedIndicatorActive) return;
        if (!faviconHref) {
          removeTaggedFavicon();
          return;
        }
        const nextHead = document.head;
        if (!nextHead) return;
        let link = document.querySelector(`link[${TAGGED_FAVICON_ATTR}="true"]`);
        if (!link) {
          link = document.createElement("link");
          link.setAttribute(TAGGED_FAVICON_ATTR, "true");
          link.rel = "icon";
          link.type = "image/png";
          link.setAttribute("sizes", `${TAGGED_FAVICON_SIZE_PX}x${TAGGED_FAVICON_SIZE_PX}`);
        }
        if (lastTaggedFaviconHref !== faviconHref || link.getAttribute("href") !== faviconHref) {
          link.href = faviconHref;
          lastTaggedFaviconHref = faviconHref;
          lastTaggedFaviconSourceHref = originalHref;
        }
        if (link.parentElement !== nextHead) nextHead.appendChild(link);
        const iconLinks = getIconLinks(true);
        if (iconLinks[iconLinks.length - 1] !== link) nextHead.appendChild(link);
      });
    }
    function removeTaggedPill() {
      document.getElementById(TAGGED_PILL_ID)?.remove();
    }
    function updateTaggedPillLabel(pill, cycleScope) {
      const label = pill.querySelector(".tw-tagged-label");
      if (label) label.textContent = `In-Wheel List (Cycle Mode: ${cycleScopeLabel(cycleScope)})`;
    }
    function ensureTaggedPill(cycleScope) {
      const existingPill = document.getElementById(TAGGED_PILL_ID);
      if (existingPill) {
        updateTaggedPillLabel(existingPill, cycleScope);
        return;
      }
      const pill = document.createElement("div");
      pill.id = TAGGED_PILL_ID;
      pill.setAttribute("aria-hidden", "true");
      pill.innerHTML = '<span class="tw-tagged-dot"></span><span class="tw-tagged-label"></span>';
      pill.style.cssText = [
        "position:fixed",
        "top:clamp(8px,1.5vh,14px)",
        "left:50vw",
        "transform:translateX(-50%)",
        "z-index:2147483644",
        "min-height:22px",
        "display:inline-flex",
        "align-items:center",
        "gap:6px",
        "padding:3px 8px",
        "max-width:calc(100vw - 24px)",
        "border-radius:999px",
        "border:1px solid rgba(50,215,75,0.22)",
        "background:rgba(18,18,18,0.18)",
        "backdrop-filter:blur(6px)",
        "color:rgba(255,255,255,0.54)",
        "box-shadow:0 6px 18px rgba(0,0,0,0.12)",
        "font:10px/1.2 'SF Mono','JetBrains Mono','Fira Code','Consolas',monospace",
        "font-weight:600",
        "letter-spacing:0",
        "opacity:0.82",
        "pointer-events:none",
        "user-select:none"
      ].join(";");
      const dot = pill.querySelector(".tw-tagged-dot");
      if (dot) {
        dot.style.cssText = [
          "width:6px",
          "height:6px",
          "border-radius:999px",
          "background:#32d74b",
          "box-shadow:0 0 0 3px rgba(50,215,75,0.12)",
          "flex:0 0 auto"
        ].join(";");
      }
      updateTaggedPillLabel(pill, cycleScope);
      document.documentElement.appendChild(pill);
    }
    function scheduleTaggedIndicatorRender() {
      if (taggedIndicatorRenderTimer) window.clearTimeout(taggedIndicatorRenderTimer);
      taggedIndicatorRenderTimer = window.setTimeout(() => {
        taggedIndicatorRenderTimer = 0;
        applyTaggedIndicators(isTaggedIndicatorActive, activeTaggedCycleScope);
      }, TAGGED_INDICATOR_DEBOUNCE_MS);
    }
    function observeFaviconChanges() {
      const target = document.head || document.documentElement;
      if (!target || faviconObserverTarget === target) return;
      faviconObserver?.disconnect();
      faviconObserverTarget = target;
      faviconObserver = new MutationObserver(() => {
        if (!isTaggedIndicatorActive) return;
        observeFaviconChanges();
        scheduleTaggedIndicatorRender();
      });
      faviconObserver.observe(target, target === document.head ? { childList: true, subtree: true, attributes: true, attributeFilter: ["href", "rel"] } : { childList: true });
    }
    function stopFaviconObserver() {
      faviconObserver?.disconnect();
      faviconObserver = null;
      faviconObserverTarget = null;
    }
    function applyTaggedIndicators(isTagged, cycleScope = settings.cycleScope) {
      isTaggedIndicatorActive = isTagged;
      activeTaggedCycleScope = cycleScope;
      if (!isTagged) {
        removeTaggedPill();
        removeTaggedFavicon();
        stopFaviconObserver();
        return;
      }
      ensureTaggedPill(cycleScope);
      observeFaviconChanges();
      ensureTaggedFavicon();
    }
    async function refreshTaggedIndicators() {
      try {
        const overview = await getTabWheelOverviewWithRetry();
        applyTaggedIndicators(overview.isCurrentTagged, overview.cycleScope);
      } catch (_) {
        applyTaggedIndicators(false);
      }
    }
    function sendScrollSnapshot() {
      if (Date.now() < suppressScrollSaveUntil) return;
      const scrollX = Math.max(0, window.scrollX);
      const scrollY = Math.max(0, window.scrollY);
      if (scrollX === lastScrollSaveX && scrollY === lastScrollSaveY) return;
      lastScrollSaveX = scrollX;
      lastScrollSaveY = scrollY;
      void saveTabWheelScrollPosition(scrollX, scrollY).catch(() => {
      });
    }
    function flushScrollSnapshot() {
      if (scrollSaveTimer) {
        window.clearTimeout(scrollSaveTimer);
        scrollSaveTimer = 0;
      }
      sendScrollSnapshot();
    }
    function scheduleScrollSnapshot() {
      if (Date.now() < suppressScrollSaveUntil) return;
      if (scrollSaveTimer) window.clearTimeout(scrollSaveTimer);
      scrollSaveTimer = window.setTimeout(() => {
        scrollSaveTimer = 0;
        sendScrollSnapshot();
      }, SCROLL_SAVE_DEBOUNCE_MS);
    }
    async function restoreWindowScroll(scrollX, scrollY, smooth) {
      const token = ++scrollRestoreToken;
      const targetX = Math.max(0, Number(scrollX) || 0);
      const targetY = Math.max(0, Number(scrollY) || 0);
      for (const delay of SCROLL_RESTORE_DELAYS_MS) {
        if (token !== scrollRestoreToken) return;
        if (delay > 0) await sleep2(delay);
        if (token !== scrollRestoreToken) return;
        suppressScrollSaveUntil = Date.now() + SCROLL_RESTORE_SUPPRESS_SAVE_MS;
        if (scrollSaveTimer) {
          window.clearTimeout(scrollSaveTimer);
          scrollSaveTimer = 0;
        }
        window.scrollTo({
          left: targetX,
          top: clampScrollY(targetY),
          behavior: smooth && delay === 0 ? "smooth" : "auto"
        });
        await new Promise((resolve) => window.requestAnimationFrame(() => resolve()));
        if (Math.abs(window.scrollY - targetY) <= 2) return;
      }
    }
    function isGestureBlockedTarget(target) {
      return !settings.allowGesturesInEditableFields && isEditableTarget(target);
    }
    function isKeyboardWheelEvent(event) {
      return areSettingsLoaded && event.isTrusted && isTabWheelModifier(event, settings.gestureModifier, settings.gestureWithShift) && !isGestureBlockedTarget(event.target);
    }
    function resolveMouseGestureAction(event) {
      if (!areSettingsLoaded) return null;
      if (!event.isTrusted) return null;
      if (!isTabWheelModifier(event, settings.gestureModifier, settings.gestureWithShift)) return null;
      if (isGestureBlockedTarget(event.target)) return null;
      if (event.button === 0) return "tag";
      if (event.button === 2) return "scope";
      return null;
    }
    function isMouseGestureStartEvent(event) {
      return event.type === "pointerdown" || event.type === "mousedown";
    }
    function getActiveMouseGestureClaim(event) {
      if (!claimedMouseGesture) return null;
      if (Date.now() - claimedMouseGesture.startedAt > MOUSE_GESTURE_CLAIM_MS) {
        claimedMouseGesture = null;
        return null;
      }
      if (event.type === "contextmenu" && claimedMouseGesture.button === 2) return claimedMouseGesture;
      return event.button === claimedMouseGesture.button ? claimedMouseGesture : null;
    }
    function runMouseGestureAction(action) {
      if (action === "tag") {
        void toggleCurrentTabWheelTag().then((result) => {
          if (!result.ok || typeof result.isCurrentTagged !== "boolean") return;
          applyTaggedIndicators(result.isCurrentTagged, result.cycleScope || settings.cycleScope);
        }).catch(() => showStatus("Tag failed"));
        return;
      }
      void toggleTabWheelCycleScope().catch(() => showStatus("Mode switch failed"));
    }
    function getTabCycleWheelDelta(event) {
      return normalizeWheelDelta(event, window.innerHeight, window.innerWidth, settings.horizontalWheel);
    }
    function getEffectiveCooldown(now) {
      if (!settings.wheelAcceleration) return settings.wheelCooldownMs;
      const gap = now - lastWheelCycleAt;
      const nextBurstCount = gap <= WHEEL_ACCELERATION_WINDOW_MS ? Math.min(wheelBurstCount + 1, 6) : 0;
      const acceleratedCooldown = settings.wheelCooldownMs - nextBurstCount * 18;
      return Math.max(MIN_ACCELERATED_COOLDOWN_MS, acceleratedCooldown);
    }
    function runWheelCycle(direction) {
      const now = Date.now();
      if (settings.overshootGuard && direction === overshootGuardDirection && now < overshootGuardUntil) {
        return;
      }
      const effectiveCooldown = getEffectiveCooldown(now);
      if (now - lastWheelCycleAt < effectiveCooldown) return;
      wheelBurstCount = now - lastWheelCycleAt <= WHEEL_ACCELERATION_WINDOW_MS ? Math.min(wheelBurstCount + 1, 6) : 0;
      lastWheelCycleAt = now;
      overshootGuardDirection = direction;
      overshootGuardUntil = settings.overshootGuard ? now + OVERSHOOT_GUARD_MS : 0;
      void cycleTabWheel(direction).catch(() => {
      });
    }
    function wheelHandler(event) {
      if (!isKeyboardWheelEvent(event)) return;
      const wheelDelta = getTabCycleWheelDelta(event);
      if (wheelDelta === 0) return;
      suppressPageEvent(event);
      wheelAccumulator += wheelDelta * settings.wheelSensitivity;
      if (Math.abs(wheelAccumulator) < WHEEL_TRIGGER_THRESHOLD_PX) return;
      const direction = resolveWheelDirection(wheelAccumulator, settings.invertScroll);
      wheelAccumulator = 0;
      runWheelCycle(direction);
    }
    function mouseGestureHandler(event) {
      const activeClaim = getActiveMouseGestureClaim(event);
      if (activeClaim) {
        suppressPageEvent(event);
        if (event.type === "click" || event.type === "contextmenu" || event.type === "auxclick") {
          claimedMouseGesture = null;
        }
        return;
      }
      const action = resolveMouseGestureAction(event);
      if (!action) return;
      suppressPageEvent(event);
      if (isMouseGestureStartEvent(event) || event.type === "click" || event.type === "contextmenu") {
        claimedMouseGesture = {
          button: event.button,
          startedAt: Date.now()
        };
        runMouseGestureAction(action);
      }
    }
    function storageChangedHandler(changes, areaName) {
      if (areaName !== "local") return;
      const settingsChange = changes[TABWHEEL_STORAGE_KEYS.settings];
      if (settingsChange) {
        settings = normalizeTabWheelSettings(settingsChange.newValue);
        activeTaggedCycleScope = settings.cycleScope;
        wheelAccumulator = 0;
        wheelBurstCount = 0;
        overshootGuardDirection = null;
        overshootGuardUntil = 0;
        claimedMouseGesture = null;
        if (isTaggedIndicatorActive) applyTaggedIndicators(true, settings.cycleScope);
      }
    }
    function messageHandler(message) {
      const receivedMessage = message;
      switch (receivedMessage.type) {
        case "TABWHEEL_PING":
          return Promise.resolve({ ok: true });
        case "GET_SCROLL":
          return Promise.resolve({
            scrollX: window.scrollX,
            scrollY: window.scrollY
          });
        case "SET_SCROLL":
          void restoreWindowScroll(
            receivedMessage.scrollX,
            receivedMessage.scrollY,
            receivedMessage.smooth
          );
          return Promise.resolve({ ok: true });
        case "TABWHEEL_STATUS":
          showStatus(receivedMessage.message);
          return Promise.resolve({ ok: true });
        case "TABWHEEL_TAG_STATE_CHANGED":
          applyTaggedIndicators(receivedMessage.isTagged, receivedMessage.cycleScope);
          return Promise.resolve({ ok: true });
        case "OPEN_TABWHEEL_HELP":
          void openTabWheelHelpOverlay();
          return Promise.resolve({ ok: true });
      }
    }
    function visibilityHandler() {
      if (document.visibilityState === "hidden") {
        flushScrollSnapshot();
        dismissPanel();
      }
    }
    window.addEventListener("pointerdown", mouseGestureHandler, true);
    window.addEventListener("mousedown", mouseGestureHandler, true);
    window.addEventListener("pointerup", mouseGestureHandler, true);
    window.addEventListener("mouseup", mouseGestureHandler, true);
    window.addEventListener("click", mouseGestureHandler, true);
    window.addEventListener("auxclick", mouseGestureHandler, true);
    window.addEventListener("contextmenu", mouseGestureHandler, true);
    document.addEventListener("pointerdown", mouseGestureHandler, true);
    document.addEventListener("mousedown", mouseGestureHandler, true);
    document.addEventListener("pointerup", mouseGestureHandler, true);
    document.addEventListener("mouseup", mouseGestureHandler, true);
    document.addEventListener("click", mouseGestureHandler, true);
    document.addEventListener("auxclick", mouseGestureHandler, true);
    document.addEventListener("contextmenu", mouseGestureHandler, true);
    window.addEventListener("wheel", wheelHandler, { passive: false, capture: true });
    document.addEventListener("wheel", wheelHandler, { passive: false, capture: true });
    import_webextension_polyfill4.default.storage.onChanged.addListener(storageChangedHandler);
    if (isTopFrameContext) {
      document.addEventListener("visibilitychange", visibilityHandler);
      window.addEventListener("scroll", scheduleScrollSnapshot, { passive: true, capture: true });
      window.addEventListener("pagehide", flushScrollSnapshot);
      window.addEventListener("beforeunload", flushScrollSnapshot);
      import_webextension_polyfill4.default.runtime.onMessage.addListener(messageHandler);
    }
    window.__tabWheelCleanup = () => {
      window.removeEventListener("pointerdown", mouseGestureHandler, true);
      window.removeEventListener("mousedown", mouseGestureHandler, true);
      window.removeEventListener("pointerup", mouseGestureHandler, true);
      window.removeEventListener("mouseup", mouseGestureHandler, true);
      window.removeEventListener("click", mouseGestureHandler, true);
      window.removeEventListener("auxclick", mouseGestureHandler, true);
      window.removeEventListener("contextmenu", mouseGestureHandler, true);
      document.removeEventListener("pointerdown", mouseGestureHandler, true);
      document.removeEventListener("mousedown", mouseGestureHandler, true);
      document.removeEventListener("pointerup", mouseGestureHandler, true);
      document.removeEventListener("mouseup", mouseGestureHandler, true);
      document.removeEventListener("click", mouseGestureHandler, true);
      document.removeEventListener("auxclick", mouseGestureHandler, true);
      document.removeEventListener("contextmenu", mouseGestureHandler, true);
      window.removeEventListener("wheel", wheelHandler, true);
      document.removeEventListener("wheel", wheelHandler, true);
      import_webextension_polyfill4.default.storage.onChanged.removeListener(storageChangedHandler);
      if (isTopFrameContext) {
        document.removeEventListener("visibilitychange", visibilityHandler);
        window.removeEventListener("scroll", scheduleScrollSnapshot, true);
        window.removeEventListener("pagehide", flushScrollSnapshot);
        window.removeEventListener("beforeunload", flushScrollSnapshot);
        import_webextension_polyfill4.default.runtime.onMessage.removeListener(messageHandler);
      }
      if (scrollSaveTimer) window.clearTimeout(scrollSaveTimer);
      if (statusTimer) window.clearTimeout(statusTimer);
      if (taggedIndicatorRenderTimer) window.clearTimeout(taggedIndicatorRenderTimer);
      document.getElementById(STATUS_ID)?.remove();
      applyTaggedIndicators(false);
      dismissPanel();
    };
    if (isTopFrameContext) {
      void import_webextension_polyfill4.default.runtime.sendMessage({ type: "TABWHEEL_CONTENT_READY" }).catch(() => {
      });
      void refreshTaggedIndicators();
    }
  }

  // src/entryPoints/contentScript/contentScript.ts
  initApp();
})();
