import {
  ANCHOR_TAG_CYCLE_TOLERANCE_PX,
  calculateAnchorPagePercent,
  sortAndCompactAnchorTags,
} from "../../core/anchorTags/anchorTagsCore";
import { escapeHtml } from "../../common/utils/helpers";
import { listAnchorTagsWithRetry } from "../../adapters/runtime/anchorTagsApi";
import anchorTagPageOverlayStyles from "./anchorTagPageOverlay.css";

const HOST_ID = "ht-anchor-page-overlay";
const ACTIVE_PULSE_MS = 720;

export interface AnchorTagPageOverlayController {
  destroy(): void;
  refresh(): Promise<void>;
  update(entries: AnchorTagEntry[], activeSlot?: number): void;
}

function getMaxScrollY(): number {
  const documentElement = document.documentElement;
  const body = document.body;
  const scrollHeight = Math.max(
    documentElement?.scrollHeight || 0,
    body?.scrollHeight || 0,
    documentElement?.offsetHeight || 0,
    body?.offsetHeight || 0,
  );
  return Math.max(0, scrollHeight - window.innerHeight);
}

function getMountParent(): HTMLElement {
  return document.body || document.documentElement;
}

function removeExistingHost(): void {
  const existing = document.getElementById(HOST_ID);
  if (existing) existing.remove();
}

export function initAnchorTagPageOverlay(): AnchorTagPageOverlayController {
  removeExistingHost();

  let host: HTMLDivElement | null = null;
  let shadow: ShadowRoot | null = null;
  let tags: AnchorTagEntry[] = [];
  let renderFrame = 0;
  let refreshRequestId = 0;
  let activePulseSlot: number | null = null;
  let activePulseTimeout = 0;
  let contentResizeObserver: ResizeObserver | null = null;
  let lastMaxScrollY = getMaxScrollY();
  let destroyed = false;

  function ensureHost(): ShadowRoot {
    if (host && shadow) return shadow;

    host = document.createElement("div");
    host.id = HOST_ID;
    host.style.cssText = [
      "position:fixed",
      "top:0",
      "right:0",
      "width:0",
      "height:0",
      "z-index:2147483644",
      "pointer-events:none",
      "isolation:isolate",
    ].join(";");
    shadow = host.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = anchorTagPageOverlayStyles;
    shadow.appendChild(style);

    getMountParent().appendChild(host);
    return shadow;
  }

  function removeHost(): void {
    if (host) host.remove();
    host = null;
    shadow = null;
  }

  function getActiveSlot(): number | null {
    if (activePulseSlot != null) return activePulseSlot;
    if (tags.length === 0) return null;

    const currentScrollY = window.scrollY + ANCHOR_TAG_CYCLE_TOLERANCE_PX;
    let activeTag = tags[0];
    for (const tag of tags) {
      if (tag.scrollY > currentScrollY) break;
      activeTag = tag;
    }
    return activeTag.slot;
  }

  function setActivePulse(slot?: number): void {
    window.clearTimeout(activePulseTimeout);
    activePulseSlot = typeof slot === "number" ? slot : null;
    if (activePulseSlot == null) return;
    activePulseTimeout = window.setTimeout(() => {
      activePulseSlot = null;
      scheduleRender();
    }, ACTIVE_PULSE_MS);
  }

  function render(): void {
    renderFrame = 0;
    if (destroyed) return;
    if (tags.length === 0) {
      removeHost();
      return;
    }

    const nextShadow = ensureHost();
    const maxScrollY = getMaxScrollY();
    lastMaxScrollY = maxScrollY;
    const activeSlot = getActiveSlot();
    const markers = tags.map((tag) => {
      const percent = calculateAnchorPagePercent(tag.scrollY, maxScrollY);
      const classes = ["ht-anchor-page-marker"];
      if (tag.slot === activeSlot) classes.push("active");
      if (tag.slot === activePulseSlot) classes.push("pulse");

      return `<span class="${classes.join(" ")}" style="top:${percent}%" aria-label="Anchor ${tag.slot}: ${escapeHtml(tag.label)}">${tag.slot}</span>`;
    }).join("");

    const currentStyle = nextShadow.querySelector("style");
    nextShadow.innerHTML = "";
    if (currentStyle) nextShadow.appendChild(currentStyle);
    const rail = document.createElement("div");
    rail.className = "ht-anchor-page-rail";
    rail.setAttribute("aria-hidden", "true");
    rail.innerHTML = `<div class="ht-anchor-page-track"></div>${markers}`;
    nextShadow.appendChild(rail);
  }

  function scheduleRender(): void {
    if (destroyed || renderFrame) return;
    renderFrame = requestAnimationFrame(render);
  }

  function scheduleRenderIfScrollDomainChanged(): void {
    if (destroyed) return;
    const maxScrollY = getMaxScrollY();
    if (maxScrollY === lastMaxScrollY) return;
    lastMaxScrollY = maxScrollY;
    scheduleRender();
  }

  function observeScrollDomain(): void {
    if (typeof ResizeObserver === "undefined") return;

    contentResizeObserver = new ResizeObserver(scheduleRenderIfScrollDomainChanged);
    contentResizeObserver.observe(document.documentElement);
    if (document.body && document.body !== document.documentElement) {
      contentResizeObserver.observe(document.body);
    }
  }

  function update(entries: AnchorTagEntry[], activeSlot?: number): void {
    if (destroyed) return;
    tags = sortAndCompactAnchorTags(entries).slice(0, 4);
    setActivePulse(activeSlot);
    render();
  }

  async function refresh(): Promise<void> {
    const requestId = ++refreshRequestId;
    try {
      const entries = await listAnchorTagsWithRetry();
      if (destroyed || requestId !== refreshRequestId) return;
      update(entries);
    } catch (_) {
      if (!destroyed) update([]);
    }
  }

  function destroy(): void {
    destroyed = true;
    window.clearTimeout(activePulseTimeout);
    if (renderFrame) cancelAnimationFrame(renderFrame);
    window.removeEventListener("scroll", scheduleRender, true);
    window.removeEventListener("resize", scheduleRender);
    window.removeEventListener("orientationchange", scheduleRender);
    contentResizeObserver?.disconnect();
    contentResizeObserver = null;
    removeHost();
  }

  window.addEventListener("scroll", scheduleRender, { passive: true, capture: true });
  window.addEventListener("resize", scheduleRender);
  window.addEventListener("orientationchange", scheduleRender);
  observeScrollDomain();
  void refresh();

  return {
    destroy,
    refresh,
    update,
  };
}
