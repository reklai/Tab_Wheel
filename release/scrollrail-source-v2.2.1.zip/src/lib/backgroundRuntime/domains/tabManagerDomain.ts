import browser, { Tabs } from "webextension-polyfill";
import {
  MAX_TAB_MANAGER_SLOTS,
  MAX_TAB_MANAGER_TITLE_LENGTH,
} from "../../common/contracts/keybindings";
import { TabManagerState } from "./sessionDomain";
import { normalizeUrlForMatch } from "../../common/utils/helpers";

export interface TabManagerDomain {
  state: TabManagerState;
  list(): TabManagerEntry[];
  ensureLoaded(): Promise<void>;
  reconcile(): Promise<void>;
  add(tab: Tabs.Tab): Promise<{ ok: boolean; reason?: string; slot?: number }>;
  remove(tabId: number): Promise<void>;
  rename(tabId: number, label: string): Promise<{ ok: boolean; reason?: string }>;
  jump(slot: number): Promise<void>;
  cycle(direction: "prev" | "next"): Promise<{ ok: boolean }>;
  saveCurrentTabScroll(): Promise<void>;
  saveTabScrollPosition(tabId: number, scrollX: number, scrollY: number): Promise<boolean>;
  ensureManagedForAnchorTag(
    tab: Tabs.Tab,
    scroll: ScrollData,
  ): Promise<{ ok: boolean; reason?: string; added?: boolean }>;
  reorder(list: TabManagerEntry[]): Promise<void>;
  consumePendingScrollRestore(tabId: number): Promise<{ scrollX: number; scrollY: number } | null>;
  clearAll(): Promise<void>;
  captureInitialActiveTab(): Promise<void>;
  registerLifecycleListeners(): void;
}

export function createTabManagerDomain(): TabManagerDomain {
  const PENDING_SCROLL_RESTORE_STORAGE_KEY = "tabManagerPendingScrollRestores";
  const SCROLL_RESTORE_INTENT_TTL_MS = 30_000;
  const SCROLL_RESTORE_SAVE_TOLERANCE_PX = 2;

  let tabManagerList: TabManagerEntry[] = [];
  let tabManagerLoaded = false;
  let lastActiveTabId: number | null = null;
  let onUpdatedSaveTimer: ReturnType<typeof setTimeout> | null = null;
  let scrollRestoreSeq = 0;

  // Pending scroll restores are consumed once a content script confirms readiness.
  const pendingScrollRestore = new Map<number, { scrollX: number; scrollY: number }>();
  const pendingScrollRestoreTokens = new Map<number, number>();
  const pendingScrollRestoreStorageMisses = new Set<number>();

  type PendingScrollRestoreStore = Record<string, {
    tabId: number;
    scrollX: number;
    scrollY: number;
    expiresAt: number;
  }>;

  async function ensureTabManagerLoaded(): Promise<void> {
    if (!tabManagerLoaded) {
      const data = await browser.storage.local.get("tabManagerList");
      tabManagerList = (data.tabManagerList as TabManagerEntry[]) || [];
      tabManagerLoaded = true;
    }
  }

  async function saveTabManager(): Promise<void> {
    await browser.storage.local.set({ tabManagerList });
  }

  function sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function normalizeScroll(scrollX: number, scrollY: number): { scrollX: number; scrollY: number } {
    return {
      scrollX: Math.max(0, Number(scrollX) || 0),
      scrollY: Math.max(0, Number(scrollY) || 0),
    };
  }

  function scrollsAreNear(
    left: { scrollX: number; scrollY: number },
    right: { scrollX: number; scrollY: number },
  ): boolean {
    return Math.abs(left.scrollX - right.scrollX) <= SCROLL_RESTORE_SAVE_TOLERANCE_PX
      && Math.abs(left.scrollY - right.scrollY) <= SCROLL_RESTORE_SAVE_TOLERANCE_PX;
  }

  function normalizePendingScrollRestoreStore(
    rawValue: unknown,
    now = Date.now(),
  ): PendingScrollRestoreStore {
    if (typeof rawValue !== "object" || rawValue === null || Array.isArray(rawValue)) return {};

    const normalized: PendingScrollRestoreStore = {};
    for (const [key, rawEntry] of Object.entries(rawValue as Record<string, unknown>)) {
      if (typeof rawEntry !== "object" || rawEntry === null) continue;
      const entry = rawEntry as Partial<PendingScrollRestoreStore[string]>;
      const tabId = Number(entry.tabId);
      const expiresAt = Number(entry.expiresAt);
      if (!Number.isInteger(tabId) || tabId <= 0) continue;
      if (!Number.isFinite(expiresAt) || expiresAt <= now) continue;

      const scroll = normalizeScroll(Number(entry.scrollX), Number(entry.scrollY));
      if (!scroll.scrollX && !scroll.scrollY) continue;
      normalized[key] = {
        tabId,
        scrollX: scroll.scrollX,
        scrollY: scroll.scrollY,
        expiresAt,
      };
    }
    return normalized;
  }

  async function readPendingScrollRestoreStore(): Promise<PendingScrollRestoreStore> {
    const stored = await browser.storage.local.get(PENDING_SCROLL_RESTORE_STORAGE_KEY);
    return normalizePendingScrollRestoreStore(stored[PENDING_SCROLL_RESTORE_STORAGE_KEY]);
  }

  async function writePendingScrollRestoreStore(store: PendingScrollRestoreStore): Promise<void> {
    if (Object.keys(store).length === 0) {
      await browser.storage.local.remove(PENDING_SCROLL_RESTORE_STORAGE_KEY);
      return;
    }
    await browser.storage.local.set({ [PENDING_SCROLL_RESTORE_STORAGE_KEY]: store });
  }

  async function persistPendingScrollRestore(
    tabId: number,
    scrollX: number,
    scrollY: number,
  ): Promise<void> {
    const scroll = normalizeScroll(scrollX, scrollY);
    if (!scroll.scrollX && !scroll.scrollY) {
      await clearStoredPendingScrollRestore(tabId);
      return;
    }

    const store = await readPendingScrollRestoreStore();
    store[String(tabId)] = {
      tabId,
      scrollX: scroll.scrollX,
      scrollY: scroll.scrollY,
      expiresAt: Date.now() + SCROLL_RESTORE_INTENT_TTL_MS,
    };
    pendingScrollRestoreStorageMisses.delete(tabId);
    await writePendingScrollRestoreStore(store);
  }

  async function clearStoredPendingScrollRestore(tabId: number): Promise<void> {
    const store = await readPendingScrollRestoreStore();
    delete store[String(tabId)];
    pendingScrollRestoreStorageMisses.add(tabId);
    await writePendingScrollRestoreStore(store);
  }

  async function peekStoredPendingScrollRestore(
    tabId: number,
  ): Promise<{ scrollX: number; scrollY: number } | null> {
    if (pendingScrollRestoreStorageMisses.has(tabId)) return null;
    const store = await readPendingScrollRestoreStore();
    const pending = store[String(tabId)];
    if (!pending) {
      pendingScrollRestoreStorageMisses.add(tabId);
      return null;
    }
    pendingScrollRestoreStorageMisses.delete(tabId);
    return { scrollX: pending.scrollX, scrollY: pending.scrollY };
  }

  async function consumeStoredPendingScrollRestore(
    tabId: number,
  ): Promise<{ scrollX: number; scrollY: number } | null> {
    const store = await readPendingScrollRestoreStore();
    const pending = store[String(tabId)];
    if (!pending) {
      pendingScrollRestoreStorageMisses.add(tabId);
      return null;
    }
    delete store[String(tabId)];
    pendingScrollRestoreStorageMisses.add(tabId);
    await writePendingScrollRestoreStore(store);
    return { scrollX: pending.scrollX, scrollY: pending.scrollY };
  }

  function recompactSlots(): void {
    tabManagerList.forEach((entry, index) => {
      entry.slot = index + 1;
    });
  }

  function normalizeCustomTitle(label: string): string {
    return label.replace(/\s+/g, " ").trim().slice(0, MAX_TAB_MANAGER_TITLE_LENGTH);
  }

  async function reconcileTabManager(): Promise<void> {
    await ensureTabManagerLoaded();
    const tabs = await browser.tabs.query({});
    const tabIds = new Set(tabs.map((tab) => tab.id));
    let changed = false;
    for (const entry of tabManagerList) {
      const shouldBeClosed = !tabIds.has(entry.tabId);
      if (entry.closed !== shouldBeClosed) {
        entry.closed = shouldBeClosed;
        changed = true;
      }
    }
    for (let i = 0; i < tabManagerList.length; i++) {
      const nextSlot = i + 1;
      if (tabManagerList[i].slot !== nextSlot) {
        tabManagerList[i].slot = nextSlot;
        changed = true;
      }
    }
    if (changed) await saveTabManager();
  }

  async function tabManagerAdd(
    tab: Tabs.Tab,
  ): Promise<{ ok: boolean; reason?: string; slot?: number }> {
    if (tab.id == null) {
      return { ok: false, reason: "Active tab unavailable." };
    }

    await reconcileTabManager();
    if (tabManagerList.length >= MAX_TAB_MANAGER_SLOTS) {
      try {
        await browser.tabs.sendMessage(tab.id, {
          type: "TAB_MANAGER_FULL_FEEDBACK",
          max: MAX_TAB_MANAGER_SLOTS,
        });
      } catch (_) {
        // Toast delivery is best-effort.
      }
      return { ok: false, reason: `Tab Manager list is full (max ${MAX_TAB_MANAGER_SLOTS}).` };
    }

    const normalizedTabUrl = normalizeUrlForMatch(tab.url || "");
    const existing = tabManagerList.find((entry) =>
      entry.tabId === tab.id
      || (
        normalizedTabUrl.length > 0
        && normalizeUrlForMatch(entry.url) === normalizedTabUrl
      ));
    if (existing) {
      if (existing.closed && normalizedTabUrl.length > 0 && normalizeUrlForMatch(existing.url) === normalizedTabUrl) {
        existing.tabId = tab.id;
        existing.closed = false;
        if (!existing.isCustomTitle) existing.title = tab.title || existing.title;
        await saveTabManager();
      }
      try {
        await browser.tabs.sendMessage(tab.id, {
          type: "TAB_MANAGER_ADDED_FEEDBACK",
          slot: existing.slot,
          title: tab.title,
          alreadyAdded: true,
        });
      } catch (_) {
        // Toast delivery is best-effort.
      }
      return { ok: false, reason: "Tab already in Tab Manager list." };
    }

    let scrollX = 0;
    let scrollY = 0;
    try {
      const response = (await browser.tabs.sendMessage(tab.id, {
        type: "GET_SCROLL",
      })) as ScrollData;
      scrollX = response.scrollX || 0;
      scrollY = response.scrollY || 0;
    } catch (_) {
      // Content script may be unavailable on restricted pages.
    }

    const slot = tabManagerList.length + 1;
    tabManagerList.push({
      tabId: tab.id,
      url: tab.url || "",
      title: tab.title || "",
      isCustomTitle: false,
      scrollX,
      scrollY,
      slot,
    });
    await saveTabManager();

    try {
      await browser.tabs.sendMessage(tab.id, {
        type: "TAB_MANAGER_ADDED_FEEDBACK",
        slot,
        title: tab.title,
      });
    } catch (_) {
      // Toast delivery is best-effort.
    }

    return { ok: true, slot };
  }

  async function tabManagerRemove(tabId: number): Promise<void> {
    await ensureTabManagerLoaded();
    tabManagerList = tabManagerList.filter((entry) => entry.tabId !== tabId);
    cancelPendingScrollRestore(tabId);
    recompactSlots();
    await saveTabManager();
  }

  async function tabManagerRename(
    tabId: number,
    label: string,
  ): Promise<{ ok: boolean; reason?: string }> {
    await ensureTabManagerLoaded();
    const trimmed = normalizeCustomTitle(label);
    if (!trimmed) return { ok: false, reason: "Name cannot be empty" };

    const entry = tabManagerList.find((candidate) => candidate.tabId === tabId);
    if (!entry) return { ok: false, reason: "Tab Manager entry not found" };

    entry.title = trimmed;
    entry.isCustomTitle = true;
    await saveTabManager();
    return { ok: true };
  }

  async function captureManagedTabScroll(tabId: number): Promise<boolean> {
    const entry = tabManagerList.find((candidate) => candidate.tabId === tabId);
    if (!entry || entry.closed) return false;

    try {
      const response = (await browser.tabs.sendMessage(tabId, {
        type: "GET_SCROLL",
      })) as ScrollData;
      const nextX = response.scrollX || 0;
      const nextY = response.scrollY || 0;
      if (entry.scrollX === nextX && entry.scrollY === nextY) return false;
      entry.scrollX = nextX;
      entry.scrollY = nextY;
      return true;
    } catch (_) {
      // Content script may be unavailable on restricted pages.
      return false;
    }
  }

  async function saveCurrentTabScroll(): Promise<void> {
    await ensureTabManagerLoaded();
    const [activeTab] = await browser.tabs.query({ active: true, currentWindow: true });
    if (!activeTab || activeTab.id == null) return;
    if (await captureManagedTabScroll(activeTab.id)) await saveTabManager();
  }

  async function saveTabScrollPosition(
    tabId: number,
    scrollX: number,
    scrollY: number,
  ): Promise<boolean> {
    await ensureTabManagerLoaded();
    const entry = tabManagerList.find((candidate) => candidate.tabId === tabId);
    if (!entry) return false;

    const nextScroll = normalizeScroll(scrollX, scrollY);
    const pendingRestore = pendingScrollRestore.get(tabId)
      || await peekStoredPendingScrollRestore(tabId);
    if (pendingRestore) {
      const nearTarget = scrollsAreNear(nextScroll, pendingRestore);
      const looksLikeInitialTop = nextScroll.scrollX <= SCROLL_RESTORE_SAVE_TOLERANCE_PX
        && nextScroll.scrollY <= SCROLL_RESTORE_SAVE_TOLERANCE_PX
        && (
          pendingRestore.scrollX > SCROLL_RESTORE_SAVE_TOLERANCE_PX
          || pendingRestore.scrollY > SCROLL_RESTORE_SAVE_TOLERANCE_PX
        );

      if (looksLikeInitialTop) return false;
      if (nearTarget) {
        cancelPendingScrollRestore(tabId);
        return false;
      }
    }

    const nextX = nextScroll.scrollX;
    const nextY = nextScroll.scrollY;
    if (entry.scrollX === nextX && entry.scrollY === nextY) return false;

    cancelPendingScrollRestore(tabId);
    entry.scrollX = nextX;
    entry.scrollY = nextY;
    await saveTabManager();
    return true;
  }

  async function ensureManagedForAnchorTag(
    tab: Tabs.Tab,
    scroll: ScrollData,
  ): Promise<{ ok: boolean; reason?: string; added?: boolean }> {
    if (tab.id == null) return { ok: false, reason: "Active tab unavailable." };

    await reconcileTabManager();
    const normalizedTabUrl = normalizeUrlForMatch(tab.url || "");
    const existingByTab = tabManagerList.find((entry) => entry.tabId === tab.id);
    if (existingByTab) return { ok: true, added: false };

    const existingByUrl = normalizedTabUrl
      ? tabManagerList.find((entry) => normalizeUrlForMatch(entry.url) === normalizedTabUrl)
      : undefined;
    if (existingByUrl) {
      existingByUrl.tabId = tab.id;
      existingByUrl.url = tab.url || existingByUrl.url;
      existingByUrl.closed = false;
      existingByUrl.scrollX = scroll.scrollX || 0;
      existingByUrl.scrollY = scroll.scrollY || 0;
      if (!existingByUrl.isCustomTitle) existingByUrl.title = tab.title || existingByUrl.title;
      await saveTabManager();
      return { ok: true, added: false };
    }

    if (tabManagerList.length >= MAX_TAB_MANAGER_SLOTS) {
      return { ok: false, reason: `Tab Manager list is full (max ${MAX_TAB_MANAGER_SLOTS}).` };
    }

    tabManagerList.push({
      tabId: tab.id,
      url: tab.url || "",
      title: tab.title || "",
      isCustomTitle: false,
      scrollX: scroll.scrollX || 0,
      scrollY: scroll.scrollY || 0,
      slot: tabManagerList.length + 1,
    });
    await saveTabManager();
    return { ok: true, added: true };
  }

  async function scheduleScrollRestore(tabId: number, scrollX: number, scrollY: number): Promise<void> {
    const scroll = normalizeScroll(scrollX, scrollY);
    if (!scroll.scrollX && !scroll.scrollY) {
      cancelPendingScrollRestore(tabId);
      return;
    }

    pendingScrollRestore.set(tabId, scroll);
    const token = ++scrollRestoreSeq;
    pendingScrollRestoreTokens.set(tabId, token);
    try {
      await persistPendingScrollRestore(tabId, scroll.scrollX, scroll.scrollY);
    } catch (_) {
      // In-memory restore still covers the common path if storage is unavailable.
    }
    const retryDelaysMs = [0, 80, 220, 420];

    void (async () => {
      for (const delay of retryDelaysMs) {
        if (pendingScrollRestoreTokens.get(tabId) !== token) return;
        if (delay > 0) await sleep(delay);

        try {
          await browser.tabs.sendMessage(tabId, {
            type: "SET_SCROLL",
            scrollX: scroll.scrollX,
            scrollY: scroll.scrollY,
          });
          if (pendingScrollRestoreTokens.get(tabId) !== token) return;
          pendingScrollRestore.delete(tabId);
          pendingScrollRestoreTokens.delete(tabId);
          await clearStoredPendingScrollRestore(tabId).catch(() => {});
          return;
        } catch (_) {
          // Content script may not be ready yet; keep retrying.
        }
      }
    })();
  }

  function cancelPendingScrollRestore(tabId: number): void {
    pendingScrollRestore.delete(tabId);
    pendingScrollRestoreTokens.delete(tabId);
    void clearStoredPendingScrollRestore(tabId).catch(() => {});
  }

  async function tabManagerJump(slot: number): Promise<void> {
    await ensureTabManagerLoaded();
    const entry = tabManagerList.find((candidate) => candidate.slot === slot);
    if (!entry) return;

    const [activeTab] = await browser.tabs.query({ active: true, currentWindow: true });
    const previousTabId = activeTab?.id;
    if (previousTabId === entry.tabId && !entry.closed) {
      cancelPendingScrollRestore(entry.tabId);
      if (await captureManagedTabScroll(entry.tabId)) await saveTabManager();
      return;
    }

    if (previousTabId != null && previousTabId !== entry.tabId) {
      if (await captureManagedTabScroll(previousTabId)) await saveTabManager();
    }

    if (entry.closed) {
      try {
        const newTab = await browser.tabs.create({ url: entry.url, active: true });
        if (newTab.id == null) return;
        entry.tabId = newTab.id;
        entry.closed = false;
        await saveTabManager();
        await scheduleScrollRestore(newTab.id, entry.scrollX, entry.scrollY);
      } catch (_) {
        tabManagerList = tabManagerList.filter((candidate) => candidate.slot !== slot);
        recompactSlots();
        await saveTabManager();
      }
      return;
    }

    const switched = await browser.tabs.update(entry.tabId, { active: true }).catch(() => null);

    if (!switched) {
      entry.closed = true;
      await saveTabManager();
      await tabManagerJump(slot);
      return;
    }

    await scheduleScrollRestore(entry.tabId, entry.scrollX, entry.scrollY);
  }

  async function tabManagerCycle(direction: "prev" | "next"): Promise<{ ok: boolean }> {
    await ensureTabManagerLoaded();
    if (tabManagerList.length === 0) return { ok: false };

    const [currentTab] = await browser.tabs.query({ active: true, currentWindow: true });
    const currentIdx = currentTab
      ? tabManagerList.findIndex((entry) => entry.tabId === currentTab.id)
      : -1;

    let targetIdx: number;
    if (currentIdx === -1) {
      targetIdx = direction === "next" ? 0 : tabManagerList.length - 1;
    } else {
      targetIdx =
        direction === "next"
          ? (currentIdx + 1) % tabManagerList.length
          : (currentIdx - 1 + tabManagerList.length) % tabManagerList.length;
    }

    await tabManagerJump(tabManagerList[targetIdx].slot);
    return { ok: true };
  }

  async function reorder(list: TabManagerEntry[]): Promise<void> {
    await ensureTabManagerLoaded();
    tabManagerList = list;
    recompactSlots();
    await saveTabManager();
  }

  async function consumePendingScrollRestore(
    tabId: number,
  ): Promise<{ scrollX: number; scrollY: number } | null> {
    const pending = pendingScrollRestore.get(tabId) || await consumeStoredPendingScrollRestore(tabId);
    if (pendingScrollRestore.has(tabId)) {
      pendingScrollRestore.delete(tabId);
      pendingScrollRestoreTokens.delete(tabId);
      await clearStoredPendingScrollRestore(tabId).catch(() => {});
    }
    return pending || null;
  }

  async function clearAll(): Promise<void> {
    await ensureTabManagerLoaded();
    tabManagerList = [];
    pendingScrollRestore.clear();
    pendingScrollRestoreTokens.clear();
    pendingScrollRestoreStorageMisses.clear();
    await browser.storage.local.remove(PENDING_SCROLL_RESTORE_STORAGE_KEY);
    await saveTabManager();
  }

  async function captureInitialActiveTab(): Promise<void> {
    try {
      const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
      if (tab?.id != null) lastActiveTabId = tab.id;
    } catch (_) {
      // Best effort only.
    }
  }

  function registerLifecycleListeners(): void {
    browser.tabs.onRemoved.addListener(async (tabId: number) => {
      await ensureTabManagerLoaded();
      cancelPendingScrollRestore(tabId);
      const entry = tabManagerList.find((candidate) => candidate.tabId === tabId);
      if (entry) {
        entry.closed = true;
        await saveTabManager();
      }
    });

    browser.tabs.onUpdated.addListener(async (tabId: number, changeInfo: Tabs.OnUpdatedChangeInfoType) => {
      await ensureTabManagerLoaded();
      const entry = tabManagerList.find((candidate) => candidate.tabId === tabId);
      if (!entry) return;

      let changed = false;
      if (changeInfo.url) {
        entry.url = changeInfo.url;
        changed = true;
      }
      if (changeInfo.title && !entry.isCustomTitle) {
        entry.title = changeInfo.title;
        changed = true;
      }

      if (!changed) return;
      if (onUpdatedSaveTimer) clearTimeout(onUpdatedSaveTimer);
      onUpdatedSaveTimer = setTimeout(() => {
        onUpdatedSaveTimer = null;
        saveTabManager();
      }, 500);
    });

    browser.tabs.onActivated.addListener(async (activeInfo: Tabs.OnActivatedActiveInfoType) => {
      const previousTabId = lastActiveTabId;
      lastActiveTabId = activeInfo.tabId;

      if (previousTabId == null) return;
      await ensureTabManagerLoaded();
      if (await captureManagedTabScroll(previousTabId)) await saveTabManager();
    });
  }

  const state: TabManagerState = {
    getList: () => tabManagerList,
    setList: (list) => { tabManagerList = list; },
    recompactSlots,
    save: saveTabManager,
    ensureLoaded: ensureTabManagerLoaded,
    queueScrollRestore: (tabId, scrollX, scrollY) => {
      return scheduleScrollRestore(tabId, scrollX, scrollY);
    },
  };

  return {
    state,
    list: () => tabManagerList,
    ensureLoaded: ensureTabManagerLoaded,
    reconcile: reconcileTabManager,
    add: tabManagerAdd,
    remove: tabManagerRemove,
    rename: tabManagerRename,
    jump: tabManagerJump,
    cycle: tabManagerCycle,
    saveCurrentTabScroll,
    saveTabScrollPosition,
    ensureManagedForAnchorTag,
    reorder,
    consumePendingScrollRestore,
    clearAll,
    captureInitialActiveTab,
    registerLifecycleListeners,
  };
}
