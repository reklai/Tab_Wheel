import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, "..");

function readText(pathFromRoot) {
  return readFileSync(resolve(root, pathFromRoot), "utf8");
}

test("background runtime entry composes handlers/domains/lifecycle modules", () => {
  const source = readText("src/entryPoints/backgroundRuntime/background.ts");

  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/handlers\/anchorTagsMessageHandler"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/handlers\/commandRouter"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/handlers\/runtimeRouter"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/handlers\/sessionMessageHandler"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/handlers\/tabManagerMessageHandler"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/domains\/anchorTagsDomain"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/domains\/tabManagerDomain"/);
  assert.match(source, /from "\.\.\/\.\.\/lib\/backgroundRuntime\/lifecycle\/startupRestore"/);

  assert.match(source, /const anchorTags = createAnchorTagsDomain\(tabManager\)/);
  assert.match(source, /registerRuntimeMessageRouter\(\s*\[/);
  assert.match(source, /createAnchorTagsMessageHandler\(anchorTags\)/);
  assert.match(source, /createTabManagerMessageHandler\(tabManager,\s*anchorTags\)/);
  assert.match(source, /createSessionMessageHandler\(tabManager\.state,\s*anchorTags\)/);
  assert.match(source, /miscMessageHandler/);

  assert.match(source, /registerStartupRestore\(/);
  assert.match(source, /clearTabManager:\s*async\s*\(\)\s*=>\s*await tabManager\.clearAll\(\)/);
});

test("anchor tags runtime handler preserves core message routing", () => {
  const source = readText("src/lib/backgroundRuntime/handlers/anchorTagsMessageHandler.ts");

  assert.match(source, /case "ANCHOR_TAG_ADD":[\s\S]*domain\.addCurrentTab\(\)/);
  assert.match(source, /case "ANCHOR_TAG_LIST":[\s\S]*domain\.listCurrentTab\(sender\.tab\?\.id,\s*sender\.tab\?\.url/);
  assert.match(source, /case "ANCHOR_TAG_REMOVE":[\s\S]*domain\.removeCurrentTabSlot\(message\.slot\)/);
  assert.match(source, /case "ANCHOR_TAG_RENAME":[\s\S]*domain\.renameCurrentTabSlot\(message\.slot,\s*message\.label\)/);
  assert.match(source, /case "ANCHOR_TAG_RESTORE":[\s\S]*domain\.restoreCurrentTabEntry\(message\.entry\)/);
  assert.match(source, /case "ANCHOR_TAG_CYCLE":[\s\S]*domain\.cycleCurrentTab\(message\.direction\)/);
  assert.match(source, /case "ANCHOR_TAG_JUMP":[\s\S]*domain\.jumpCurrentTabSlot\(message\.slot\)/);
});

test("tab manager runtime handler preserves core message routing", () => {
  const source = readText("src/lib/backgroundRuntime/handlers/tabManagerMessageHandler.ts");

  assert.match(source, /case "TAB_MANAGER_ADD":[\s\S]*domain\.add\(tab\)/);
  assert.match(source, /case "TAB_MANAGER_REMOVE":[\s\S]*domain\.remove\(message\.tabId\)/);
  assert.match(source, /case "TAB_MANAGER_RENAME":[\s\S]*domain\.rename\(message\.tabId,\s*message\.label\)/);
  assert.match(source, /case "TAB_MANAGER_LIST":[\s\S]*domain\.list\(\)/);
  assert.match(source, /case "TAB_MANAGER_JUMP":[\s\S]*domain\.jump\(message\.slot\)/);
  assert.match(source, /case "TAB_MANAGER_CYCLE":[\s\S]*domain\.cycle\(message\.direction\)/);
  assert.match(source, /case "TAB_MANAGER_SAVE_SCROLL_POSITION":[\s\S]*domain\.saveTabScrollPosition\(/);
  assert.match(source, /case "TAB_MANAGER_REORDER":[\s\S]*domain\.reorder\(message\.list\)/);
  assert.match(source, /case "CONTENT_SCRIPT_READY":[\s\S]*anchorTagsState\?\.consumeQueuedSessionRestore\(tabId\)/);
});

test("content script debounces managed tab scroll memory updates", () => {
  const appInitSource = readText("src/lib/appInit/appInit.ts");
  const apiSource = readText("src/lib/adapters/runtime/tabManagerApi.ts");
  const messageSource = readText("src/lib/common/contracts/runtimeMessages.ts");

  assert.match(apiSource, /saveTabManagerScrollPosition\(/);
  assert.match(messageSource, /TAB_MANAGER_SAVE_SCROLL_POSITION/);
  assert.match(appInitSource, /SCROLL_SAVE_DEBOUNCE_MS/);
  assert.match(appInitSource, /window\.addEventListener\("scroll",\s*scheduleScrollSnapshot/);
  assert.match(appInitSource, /saveTabManagerScrollPosition\(scrollX,\s*scrollY\)/);
  assert.match(appInitSource, /window\.addEventListener\("pagehide",\s*flushScrollSnapshot\)/);
  assert.match(appInitSource, /window\.addEventListener\("beforeunload",\s*flushScrollSnapshot\)/);
  assert.match(appInitSource, /SCROLL_RESTORE_DELAYS_MS = \[0,\s*80,\s*220,\s*500,\s*900,\s*1500,\s*2400,\s*3600\]/);
  assert.match(appInitSource, /function restoreWindowScroll\(/);
  assert.match(appInitSource, /suppressScrollSaveUntil = Date\.now\(\) \+ SCROLL_RESTORE_SUPPRESS_SAVE_MS/);
  assert.match(appInitSource, /case "SET_SCROLL":[\s\S]*restoreWindowScroll\(/);
});

test("tab manager slot jump does not rewind the already active managed tab", () => {
  const source = readText("src/lib/backgroundRuntime/domains/tabManagerDomain.ts");

  assert.match(source, /function cancelPendingScrollRestore\(tabId:\s*number\)/);
  assert.match(source, /previousTabId === entry\.tabId && !entry\.closed/);
  assert.match(source, /cancelPendingScrollRestore\(entry\.tabId\)/);
  assert.match(source, /captureManagedTabScroll\(entry\.tabId\)/);
  assert.match(source, /saveTabScrollPosition\(/);
});

test("tab manager keeps closed-tab scroll restore intent durable until content is ready", () => {
  const tabManagerSource = readText("src/lib/backgroundRuntime/domains/tabManagerDomain.ts");
  const handlerSource = readText("src/lib/backgroundRuntime/handlers/tabManagerMessageHandler.ts");
  const sessionSource = readText("src/lib/backgroundRuntime/domains/sessionDomain.ts");

  assert.match(tabManagerSource, /PENDING_SCROLL_RESTORE_STORAGE_KEY = "tabManagerPendingScrollRestores"/);
  assert.match(tabManagerSource, /SCROLL_RESTORE_INTENT_TTL_MS = 30_000/);
  assert.match(tabManagerSource, /persistPendingScrollRestore\(tabId,\s*scroll\.scrollX,\s*scroll\.scrollY\)/);
  assert.match(tabManagerSource, /consumeStoredPendingScrollRestore\(tabId\)/);
  assert.match(tabManagerSource, /looksLikeInitialTop/);
  assert.match(tabManagerSource, /if \(looksLikeInitialTop\) return false/);
  assert.match(tabManagerSource, /await scheduleScrollRestore\(newTab\.id,\s*entry\.scrollX,\s*entry\.scrollY\)/);
  assert.match(tabManagerSource, /queueScrollRestore: \(tabId,\s*scrollX,\s*scrollY\) => \{[\s\S]*return scheduleScrollRestore\(tabId,\s*scrollX,\s*scrollY\)/);
  assert.match(handlerSource, /const pending = await domain\.consumePendingScrollRestore\(tabId\)/);
  assert.match(sessionSource, /await state\.queueScrollRestore\(.*entry\.scrollX,\s*entry\.scrollY\)/);
});

test("session runtime handler preserves save-load-delete-rename routing", () => {
  const source = readText("src/lib/backgroundRuntime/handlers/sessionMessageHandler.ts");

  assert.match(source, /case "SESSION_SAVE":[\s\S]*sessionSave\(tabManagerState,\s*message\.name,\s*anchorTagsState\)/);
  assert.match(source, /case "SESSION_LIST":[\s\S]*sessionList\(\)/);
  assert.match(source, /case "SESSION_LOAD_PLAN":[\s\S]*sessionLoadPlan\(tabManagerState,\s*message\.name\)/);
  assert.match(source, /case "SESSION_LOAD":[\s\S]*sessionLoad\(tabManagerState,\s*message\.name,\s*anchorTagsState\)/);
  assert.match(source, /case "SESSION_DELETE":[\s\S]*sessionDelete\(message\.name\)/);
  assert.match(source, /case "SESSION_RENAME":[\s\S]*sessionRename\(message\.oldName,\s*message\.newName\)/);
  assert.match(source, /case "SESSION_UPDATE":[\s\S]*sessionUpdate\(tabManagerState,\s*message\.name,\s*anchorTagsState\)/);
  assert.match(source, /case "SESSION_REPLACE":[\s\S]*sessionReplace\(\s*tabManagerState,[\s\S]*message\.oldName,[\s\S]*message\.newName,[\s\S]*anchorTagsState/);
});

test("session domain snapshots and restores anchor tags", () => {
  const source = readText("src/lib/backgroundRuntime/domains/sessionDomain.ts");
  const anchorSource = readText("src/lib/backgroundRuntime/domains/anchorTagsDomain.ts");

  assert.match(source, /interface AnchorTagsSessionState/);
  assert.match(source, /buildSessionEntries\(currentList,\s*anchorTagsState\)/);
  assert.match(source, /anchorTagsState\.listForSession\(entry\.tabId,\s*entry\.url\)/);
  assert.match(source, /restoreSessionAnchorTags\(anchorTagsState,\s*entry,\s*loadedEntry,\s*"immediate"\)/);
  assert.match(source, /restoreSessionAnchorTags\(anchorTagsState,\s*entry,\s*loadedEntry,\s*"deferred"\)/);
  assert.match(source, /anchorTagsState\.queueSessionRestore\(/);
  assert.match(source, /anchorTagsState\.replaceForSession\(/);
  assert.match(source, /commitLoadedSessionList\(state,\s*newList\)/);
  assert.match(source, /newList\.push\(loadedEntry\);[\s\S]*await commitLoadedSessionList\(state,\s*newList\)/);

  assert.match(anchorSource, /listForSession\(tabId:\s*number,\s*url:\s*string\)/);
  assert.match(anchorSource, /queueSessionRestore\(/);
  assert.match(anchorSource, /consumeQueuedSessionRestore\(/);
  assert.match(anchorSource, /replaceForSession\(/);
  assert.match(anchorSource, /pendingSessionRestores/);
  assert.match(anchorSource, /getUrlEntriesAcrossTabs\(url\)/);
  assert.match(anchorSource, /ensureManagedForAnchorTag\(tab,\s*scroll\)/);
  assert.match(anchorSource, /sendTagsUpdated\(tabId,\s*getTabEntries\(tabId,\s*url\)\)/);
});

test("anchor tags are connected to tab manager session eligibility", () => {
  const tabManagerSource = readText("src/lib/backgroundRuntime/domains/tabManagerDomain.ts");
  const anchorSource = readText("src/lib/backgroundRuntime/domains/anchorTagsDomain.ts");

  assert.match(tabManagerSource, /ensureManagedForAnchorTag/);
  assert.match(tabManagerSource, /tabManagerList\.push\(\{[\s\S]*tabId:\s*tab\.id/);
  assert.match(tabManagerSource, /existingByUrl[\s\S]*existingByUrl\.tabId = tab\.id/);
  assert.match(anchorSource, /interface AnchorTagsTabManagerState/);
  assert.match(anchorSource, /createAnchorTagsDomain\(\s*tabManagerState\?:\s*AnchorTagsTabManagerState/);
});

test("session panel keeps save/load preflight + execution wiring", () => {
  const source = readText("src/lib/ui/panels/sessionMenu/session.ts");

  assert.match(source, /loadSessionPlanByName\(target\.name\)/);
  assert.match(source, /await loadSessionByName\(session\.name\)/);
  assert.match(source, /await saveSessionByName\(name\.trim\(\)\)/);
  assert.match(source, /await updateSession\(session\.name\)/);
  assert.match(source, /await deleteSessionByNameRemote\(name\)/);
});

test("anchor tags panel keeps add-cycle-editing wiring", () => {
  const source = readText("src/lib/ui/panels/anchorTags/anchorTags.ts");

  assert.match(source, /addCurrentAnchorTag\(\)/);
  assert.match(source, /jumpToAnchorTag\(tag\.slot\)/);
  assert.match(source, /renameAnchorTag\(renameSlot,\s*nextLabel\)/);
  assert.match(source, /removeAnchorTag\(slot\)/);
  assert.match(source, /restoreAnchorTag\(undoEntry\)/);
  assert.doesNotMatch(source, /buildMarkerRailHtml/);
});

test("tab manager panel keeps rename wiring", () => {
  const source = readText("src/lib/ui/panels/tabManager/tabManager.ts");

  assert.match(source, /renameTabManagerEntry\(renameTabId,\s*nextLabel\)/);
  assert.match(source, /matchesAction\(event,\s*config,\s*"tabManager",\s*"rename"\)/);
  assert.match(source, /class="ht-tab-manager-rename-input"/);
  assert.match(source, /config\.bindings\.tabManager\.rename\.key/);
});

test("help panel open section includes save actions", () => {
  const source = readText("src/lib/ui/panels/help/help.ts");

  assert.match(source, /title:\s*"Open Panels"/);
  assert.match(source, /label:\s*"Save Tab",\s*key:\s*k\(g\.addTab\)/);
  assert.match(source, /label:\s*"Save Anchor Tag",\s*key:\s*k\(g\.addAnchorTag\)/);
});

test("anchor tags page overlay is initialized and updated from content messages", () => {
  const appInitSource = readText("src/lib/appInit/appInit.ts");
  const overlaySource = readText("src/lib/ui/overlays/anchorTagPageOverlay.ts");

  assert.match(appInitSource, /from "\.\.\/ui\/overlays\/anchorTagPageOverlay"/);
  assert.match(appInitSource, /initAnchorTagPageOverlay\(\)/);
  assert.match(appInitSource, /case "ANCHOR_TAGS_UPDATED":[\s\S]*anchorTagPageOverlay\.update\(receivedMessage\.entries,\s*receivedMessage\.activeSlot\)/);
  assert.match(appInitSource, /anchorTagPageOverlay\.destroy\(\)/);

  assert.match(overlaySource, /listAnchorTagsWithRetry\(\)/);
  assert.match(overlaySource, /calculateAnchorPagePercent\(tag\.scrollY,\s*maxScrollY\)/);
  assert.match(overlaySource, /sortAndCompactAnchorTags\(entries\)/);
  assert.match(overlaySource, /ResizeObserver/);
  assert.match(overlaySource, /scheduleRenderIfScrollDomainChanged/);
  assert.match(overlaySource, /contentResizeObserver\?\.disconnect\(\)/);
});
