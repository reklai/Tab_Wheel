# Repository Guidelines


## name: grill-me
## description: Interview the user relentlessly about a plan or design until reaching shared understanding, resolving each branch of the decision tree. Use when user wants to stress-test a plan, get grilled on their design, or mentions "grill me".

Interview me relentlessly about every aspect of this plan until we reach a shared understanding. Walk down each branch of the design tree, resolving dependencies between decisions one-by-one. For each question, provide your recommended answer.

Ask the questions one at a time.

If a question can be answered by exploring the codebase, explore the codebase instead.


## Project Structure & Module Organization

`src/entryPoints/` contains browser-facing bundles for `backgroundRuntime`, `contentScript`, `optionsPage`, and `toolbarPopup`. Keep these files thin and push reusable logic into `src/lib/`, which is split into `backgroundRuntime`, `ui`, `core`, `adapters`, and `common`. Static assets live in `src/icons/`. Build scripts and browser manifests live in `esBuildConfig/`. Tests are under `test/`, with upgrade fixtures in `test/fixtures/upgrade/`. Treat `dist/` and `release/` as generated output, not source.

## Build, Test, and Development Commands

- `npm ci`: install lockfile-pinned dependencies; CI uses Node 22.
- `npm run watch:firefox` / `npm run watch:chrome`: rebuild on change for local extension development.
- `npm run build:firefox` / `npm run build:chrome`: emit production bundles into `dist/` using the MV2 or MV3 manifest.
- `npm run lint`: run repository-specific architecture and naming checks.
- `npm run test`: execute `node --test test/*.test.mjs`.
- `npm run typecheck`: run strict TypeScript validation with `tsc --noEmit`.
- `npm run ci`: run the full local gate, including compat, upgrade, store, and both browser builds.

## Coding Style & Naming Conventions

Use strict TypeScript with 2-space indentation, semicolons, and double quotes to match existing files in `src/`. Keep file and folder names in camelCase (`searchCurrentPage`, `tabManager`). Prefer verb-led function names such as `open...`, `load...`, `save...`, and descriptive payload names instead of `msg`. Use `event` for DOM event parameters, boolean prefixes like `is` and `has`, and `UPPER_SNAKE_CASE` for shared constants. Do not introduce UI frameworks; this project relies on browser primitives, Shadow DOM helpers, and shared panel tokens.

## Testing Guidelines

Add tests as `test/*.test.mjs` and name them after the behavior they guard, for example `runtime-wiring.test.mjs`. Use `node:test` and `node:assert/strict`. When changing storage migrations, update `test/fixtures/upgrade/` and run `npm run verify:upgrade`. If you touch performance-sensitive panels, keep instrumentation and `src/lib/common/utils/perfBudgets.json` in sync.

## Commit & Pull Request Guidelines

Commit only when permission is given explicitly given.
Recent commits use short, imperative subjects such as `Update README.md`; follow that pattern and keep each commit focused. Before opening a PR, run `npm run ci`. PR descriptions should summarize user-visible behavior, affected browser targets, and any manifest or policy changes. If permissions, storage, or privacy behavior changes, update `esBuildConfig/manifest_v2.json`, `esBuildConfig/manifest_v3.json`, `STORE.md`, and `PRIVACY.md` together.
