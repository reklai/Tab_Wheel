import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const ROOT = process.cwd();

function readText(pathFromRoot) {
  return readFileSync(resolve(ROOT, pathFromRoot), "utf8");
}

function readJson(pathFromRoot) {
  return JSON.parse(readText(pathFromRoot));
}

const budgets = readJson("src/lib/common/utils/perfBudgets.json");

const REQUIRED_BUDGETS = {
  "searchCurrentPage.renderResults": 30,
  "searchCurrentPage.renderVisibleItems": 16,
};

const REQUIRED_INSTRUMENTATION = {
  "src/lib/ui/panels/searchCurrentPage/searchCurrentPage.ts": [
    'withPerfTrace("searchCurrentPage.renderResults"',
    'withPerfTrace("searchCurrentPage.renderVisibleItems"',
  ],
};

test("perf budgets stay within capped thresholds", () => {
  for (const [key, maxMs] of Object.entries(REQUIRED_BUDGETS)) {
    assert.equal(typeof budgets[key], "number", `Missing perf budget: ${key}`);
    assert.ok(budgets[key] > 0, `Perf budget must be positive: ${key}`);
    assert.ok(
      budgets[key] <= maxMs,
      `Perf budget ${key}=${budgets[key]}ms exceeds cap ${maxMs}ms`,
    );
  }
});

test("hot paths are instrumented with withPerfTrace", () => {
  for (const [file, snippets] of Object.entries(REQUIRED_INSTRUMENTATION)) {
    const source = readText(file);
    for (const snippet of snippets) {
      assert.match(source, new RegExp(snippet.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
    }
  }
});
