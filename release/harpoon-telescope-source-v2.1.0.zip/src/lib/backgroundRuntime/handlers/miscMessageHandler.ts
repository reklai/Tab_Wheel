import browser from "webextension-polyfill";
import { loadKeybindings, saveKeybindings } from "../../common/contracts/keybindings";
import { grepCurrentTab, getPageContent } from "../domains/pageSearchDomain";
import { RuntimeMessageHandler, UNHANDLED } from "./runtimeRouter";

export const miscMessageHandler: RuntimeMessageHandler = async (message) => {
  switch (message.type) {
    case "GREP_CURRENT":
      return await grepCurrentTab(message.query, message.filters || []);

    case "GET_PAGE_CONTENT":
      return await getPageContent(message.tabId);

    case "GET_CURRENT_TAB": {
      const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
      return tab || null;
    }

    case "GET_KEYBINDINGS":
      return await loadKeybindings();

    case "SAVE_KEYBINDINGS":
      await saveKeybindings(message.config);
      return { ok: true };

    default:
      return UNHANDLED;
  }
};
