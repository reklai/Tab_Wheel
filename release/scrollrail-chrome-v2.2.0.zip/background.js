"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/backgroundRuntime/domains/anchorTagsDomain.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/keybindings.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var MAX_TAB_MANAGER_SLOTS = 4;
  var MAX_TAB_MANAGER_TITLE_LENGTH = 60;
  var MAX_ANCHOR_TAGS = 4;
  var MAX_SESSIONS = 4;
  var DEFAULT_KEYBINDINGS = {
    navigationMode: "standard",
    bindings: {
      global: {
        openTabManager: { key: "Alt+T", default: "Alt+T" },
        addTab: { key: "Alt+Shift+T", default: "Alt+Shift+T" },
        jumpSlot1: { key: "Alt+1", default: "Alt+1" },
        jumpSlot2: { key: "Alt+2", default: "Alt+2" },
        jumpSlot3: { key: "Alt+3", default: "Alt+3" },
        jumpSlot4: { key: "Alt+4", default: "Alt+4" },
        cyclePrev: { key: "Alt+-", default: "Alt+-" },
        cycleNext: { key: "Alt+=", default: "Alt+=" },
        openAnchorTags: { key: "Alt+A", default: "Alt+A" },
        addAnchorTag: { key: "Alt+Shift+A", default: "Alt+Shift+A" },
        cycleAnchorPrev: { key: "Alt+[", default: "Alt+[" },
        cycleAnchorNext: { key: "Alt+]", default: "Alt+]" },
        openSessions: { key: "Alt+S", default: "Alt+S" },
        openSessionSave: { key: "Alt+Shift+S", default: "Alt+Shift+S" },
        openHelp: { key: "Alt+M", default: "Alt+M" }
      },
      tabManager: {
        moveUp: { key: "ArrowUp", default: "ArrowUp" },
        moveDown: { key: "ArrowDown", default: "ArrowDown" },
        jump: { key: "Enter", default: "Enter" },
        remove: { key: "D", default: "D" },
        rename: { key: "R", default: "R" },
        swap: { key: "W", default: "W" },
        undo: { key: "U", default: "U" },
        close: { key: "Escape", default: "Escape" }
      },
      anchorTags: {
        moveUp: { key: "ArrowUp", default: "ArrowUp" },
        moveDown: { key: "ArrowDown", default: "ArrowDown" },
        jump: { key: "Enter", default: "Enter" },
        add: { key: "A", default: "A" },
        rename: { key: "R", default: "R" },
        remove: { key: "D", default: "D" },
        undo: { key: "U", default: "U" },
        close: { key: "Escape", default: "Escape" }
      },
      session: {
        focusList: { key: "Tab", default: "Tab" },
        focusSearch: { key: "F", default: "F" },
        clearSearch: { key: "Shift+Space", default: "Shift+Space" },
        rename: { key: "R", default: "R" },
        overwrite: { key: "O", default: "O" },
        confirmYes: { key: "Y", default: "Y" },
        confirmNo: { key: "N", default: "N" }
      }
    }
  };
  async function loadKeybindings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get("keybindings");
      if (data.keybindings) {
        return mergeWithDefaults(data.keybindings);
      }
    } catch (_) {
    }
    return JSON.parse(JSON.stringify(DEFAULT_KEYBINDINGS));
  }
  async function saveKeybindings(config) {
    await import_webextension_polyfill.default.storage.local.set({ keybindings: config });
  }
  function mergeWithDefaults(stored) {
    const merged = JSON.parse(
      JSON.stringify(DEFAULT_KEYBINDINGS)
    );
    merged.navigationMode = "standard";
    for (const scope of Object.keys(merged.bindings)) {
      if (!stored.bindings?.[scope]) continue;
      for (const action of Object.keys(merged.bindings[scope])) {
        const storedBinding = stored.bindings[scope]?.[action];
        if (storedBinding) {
          merged.bindings[scope][action].key = storedBinding.key;
        }
      }
    }
    return merged;
  }

  // src/lib/common/utils/helpers.ts
  var TRACKING_QUERY_PREFIXES = ["utm_"];
  var TRACKING_QUERY_KEYS = /* @__PURE__ */ new Set([
    "fbclid",
    "gclid",
    "mc_cid",
    "mc_eid"
  ]);
  function normalizeUrlForMatch(rawUrl) {
    const trimmed = rawUrl.trim();
    if (!trimmed) return "";
    try {
      const parsed = new URL(trimmed);
      const protocol = parsed.protocol.toLowerCase();
      let hostname = parsed.hostname.toLowerCase();
      if (hostname.startsWith("www.")) hostname = hostname.slice(4);
      const isDefaultPort = protocol === "http:" && parsed.port === "80" || protocol === "https:" && parsed.port === "443";
      const port = parsed.port && !isDefaultPort ? `:${parsed.port}` : "";
      let pathname = parsed.pathname || "/";
      pathname = pathname.replace(/\/{2,}/g, "/");
      if (pathname.length > 1 && pathname.endsWith("/")) pathname = pathname.slice(0, -1);
      const kept = [];
      for (const [key, value] of parsed.searchParams.entries()) {
        const lowerKey = key.toLowerCase();
        if (TRACKING_QUERY_KEYS.has(lowerKey)) continue;
        if (TRACKING_QUERY_PREFIXES.some((prefix) => lowerKey.startsWith(prefix))) continue;
        kept.push([key, value]);
      }
      kept.sort((a, b) => {
        const keyCompare = a[0].localeCompare(b[0]);
        if (keyCompare !== 0) return keyCompare;
        return a[1].localeCompare(b[1]);
      });
      const search = kept.length ? `?${kept.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&")}` : "";
      return `${protocol}//${hostname}${port}${pathname}${search}`;
    } catch (_) {
      return trimmed.toLowerCase().replace(/\/+$/, "");
    }
  }

  // src/lib/core/anchorTags/anchorTagsCore.ts
  var ANCHOR_TAG_DUPLICATE_DISTANCE_PX = 24;
  var ANCHOR_TAG_CYCLE_TOLERANCE_PX = 8;
  function sortAndCompactAnchorTags(entries) {
    return entries.slice().sort((left, right) => {
      if (left.scrollY !== right.scrollY) return left.scrollY - right.scrollY;
      return left.createdAt - right.createdAt;
    }).map((entry, index) => ({
      ...entry,
      slot: index + 1
    }));
  }
  function isDuplicateAnchorTag(entries, scrollY, thresholdPx = ANCHOR_TAG_DUPLICATE_DISTANCE_PX) {
    return entries.some((entry) => Math.abs(entry.scrollY - scrollY) <= thresholdPx);
  }
  function findAnchorCycleTarget(entries, currentScrollY, direction, tolerancePx = ANCHOR_TAG_CYCLE_TOLERANCE_PX) {
    const sorted = sortAndCompactAnchorTags(entries);
    if (sorted.length === 0) return null;
    if (direction === "next") {
      return sorted.find((entry) => entry.scrollY > currentScrollY + tolerancePx) || sorted[0];
    }
    for (let i = sorted.length - 1; i >= 0; i--) {
      if (sorted[i].scrollY < currentScrollY - tolerancePx) {
        return sorted[i];
      }
    }
    return sorted[sorted.length - 1];
  }

  // src/lib/backgroundRuntime/domains/anchorTagsDomain.ts
  var STORAGE_KEY = "anchorTagsByTabId";
  function tabKey(tabId) {
    return String(tabId);
  }
  function normalizeStoredEntry(rawEntry) {
    if (typeof rawEntry !== "object" || rawEntry === null) return null;
    const entry = rawEntry;
    const tabId = Number(entry.tabId);
    const slot = Number(entry.slot);
    const scrollX = Number(entry.scrollX);
    const scrollY = Number(entry.scrollY);
    const createdAt = Number(entry.createdAt);
    if (!Number.isInteger(tabId) || tabId <= 0) return null;
    if (!Number.isInteger(slot) || slot <= 0) return null;
    if (!Number.isFinite(scrollX) || !Number.isFinite(scrollY)) return null;
    if (!Number.isFinite(createdAt)) return null;
    if (typeof entry.url !== "string" || !entry.url) return null;
    const label = typeof entry.label === "string" && entry.label.trim() ? entry.label.trim().slice(0, 30) : "Anchor Tag";
    return {
      tabId,
      url: entry.url,
      slot,
      scrollX: Math.max(0, scrollX),
      scrollY: Math.max(0, scrollY),
      label,
      isCustomLabel: entry.isCustomLabel === true,
      createdAt
    };
  }
  function normalizeStoredMap(rawValue) {
    if (typeof rawValue !== "object" || rawValue === null || Array.isArray(rawValue)) {
      return {};
    }
    const normalized = {};
    for (const [key, rawEntries] of Object.entries(rawValue)) {
      const tabId = Number(key);
      if (!Number.isInteger(tabId) || tabId <= 0 || !Array.isArray(rawEntries)) continue;
      const entries = rawEntries.map(normalizeStoredEntry).filter((entry) => !!entry).filter((entry) => entry.tabId === tabId).slice(0, MAX_ANCHOR_TAGS);
      if (entries.length > 0) {
        normalized[key] = sortAndCompactAnchorTags(entries);
      }
    }
    return normalized;
  }
  function createAnchorTagsDomain(tabManagerState) {
    let anchorTagsByTabId = {};
    let loaded = false;
    const pendingSessionRestores = /* @__PURE__ */ new Map();
    async function ensureLoaded() {
      if (loaded) return;
      const stored = await import_webextension_polyfill2.default.storage.local.get(STORAGE_KEY);
      anchorTagsByTabId = normalizeStoredMap(stored[STORAGE_KEY]);
      loaded = true;
    }
    async function save() {
      await import_webextension_polyfill2.default.storage.local.set({ [STORAGE_KEY]: anchorTagsByTabId });
    }
    async function getActiveTab() {
      const [tab] = await import_webextension_polyfill2.default.tabs.query({ active: true, currentWindow: true });
      if (!tab || tab.id == null) return null;
      return tab;
    }
    function getTabEntries(tabId, url) {
      const entries = anchorTagsByTabId[tabKey(tabId)] || [];
      if (!url) return entries;
      const exactMatches = entries.filter((entry) => entry.url === url);
      if (exactMatches.length > 0) return exactMatches;
      const normalizedUrl = normalizeUrlForMatch(url);
      if (!normalizedUrl) return [];
      return entries.filter((entry) => normalizeUrlForMatch(entry.url) === normalizedUrl);
    }
    function getUrlEntriesAcrossTabs(url) {
      const normalizedUrl = normalizeUrlForMatch(url);
      if (!normalizedUrl) return [];
      return Object.values(anchorTagsByTabId).flat().filter((entry) => normalizeUrlForMatch(entry.url) === normalizedUrl);
    }
    function setTabEntries(tabId, entries) {
      const compacted = sortAndCompactAnchorTags(entries).slice(0, MAX_ANCHOR_TAGS);
      if (compacted.length === 0) {
        delete anchorTagsByTabId[tabKey(tabId)];
        return;
      }
      anchorTagsByTabId[tabKey(tabId)] = compacted;
    }
    function toSessionAnchorTags(entries) {
      return sortAndCompactAnchorTags(entries).slice(0, MAX_ANCHOR_TAGS).map((entry) => ({
        slot: entry.slot,
        scrollX: entry.scrollX,
        scrollY: entry.scrollY,
        label: entry.label,
        isCustomLabel: entry.isCustomLabel,
        createdAt: entry.createdAt
      }));
    }
    function copySessionAnchorTags(entries) {
      return entries.slice(0, MAX_ANCHOR_TAGS).map((entry, index) => ({
        slot: Number.isInteger(entry.slot) && entry.slot > 0 ? entry.slot : index + 1,
        scrollX: Math.max(0, Number(entry.scrollX) || 0),
        scrollY: Math.max(0, Number(entry.scrollY) || 0),
        label: typeof entry.label === "string" && entry.label.trim() ? entry.label.trim().slice(0, 30) : "Anchor Tag",
        isCustomLabel: entry.isCustomLabel === true,
        createdAt: Number.isFinite(Number(entry.createdAt)) ? Number(entry.createdAt) : Date.now() + index
      }));
    }
    function fromSessionAnchorTags(tabId, url, entries) {
      return entries.slice(0, MAX_ANCHOR_TAGS).map((entry, index) => ({
        tabId,
        url,
        slot: Number.isInteger(entry.slot) && entry.slot > 0 ? entry.slot : index + 1,
        scrollX: Math.max(0, Number(entry.scrollX) || 0),
        scrollY: Math.max(0, Number(entry.scrollY) || 0),
        label: typeof entry.label === "string" && entry.label.trim() ? entry.label.trim().slice(0, 30) : "Anchor Tag",
        isCustomLabel: entry.isCustomLabel === true,
        createdAt: Number.isFinite(Number(entry.createdAt)) ? Number(entry.createdAt) : Date.now() + index
      }));
    }
    async function sendFeedback(tabId, message) {
      try {
        await import_webextension_polyfill2.default.tabs.sendMessage(tabId, {
          type: "ANCHOR_TAG_FEEDBACK",
          message
        });
      } catch (_) {
      }
    }
    async function sendTagsUpdated(tabId, entries, activeSlot) {
      try {
        await import_webextension_polyfill2.default.tabs.sendMessage(tabId, {
          type: "ANCHOR_TAGS_UPDATED",
          entries,
          activeSlot
        });
      } catch (_) {
      }
    }
    async function getScroll(tabId) {
      try {
        return await import_webextension_polyfill2.default.tabs.sendMessage(tabId, { type: "GET_SCROLL" });
      } catch (_) {
        return { scrollX: 0, scrollY: 0 };
      }
    }
    async function getLabelContext(tab, scrollX, scrollY) {
      if (tab.id == null) return { label: tab.title || "Anchor Tag" };
      try {
        const context = await import_webextension_polyfill2.default.tabs.sendMessage(tab.id, {
          type: "GET_ANCHOR_LABEL_CONTEXT",
          scrollX,
          scrollY
        });
        if (context.label && context.label.trim()) {
          return { label: context.label.trim().slice(0, 30) };
        }
      } catch (_) {
      }
      return { label: (tab.title || "Anchor Tag").trim().slice(0, 30) };
    }
    async function scrollTabToAnchor(tabId, entry) {
      try {
        await import_webextension_polyfill2.default.tabs.sendMessage(tabId, {
          type: "SET_SCROLL",
          scrollX: entry.scrollX,
          scrollY: entry.scrollY,
          smooth: true
        });
        return true;
      } catch (_) {
        return false;
      }
    }
    async function listCurrentTab(tabId, url) {
      await ensureLoaded();
      if (tabId != null) {
        return getTabEntries(tabId, url || "");
      }
      const tab = await getActiveTab();
      if (!tab?.id) return [];
      return getTabEntries(tab.id, tab.url || "");
    }
    async function listForSession(tabId, url) {
      await ensureLoaded();
      const entries = toSessionAnchorTags(getTabEntries(tabId, url));
      if (entries.length > 0) return entries;
      const urlEntries = toSessionAnchorTags(getUrlEntriesAcrossTabs(url));
      if (urlEntries.length > 0) return urlEntries;
      const pending = pendingSessionRestores.get(tabId);
      if (pending && normalizeUrlForMatch(pending.url) === normalizeUrlForMatch(url)) {
        return copySessionAnchorTags(pending.entries);
      }
      return [];
    }
    async function queueSessionRestore(tabId, url, entries) {
      await ensureLoaded();
      const sessionEntries = copySessionAnchorTags(entries);
      pendingSessionRestores.set(tabId, { url, entries: sessionEntries });
      setTabEntries(tabId, fromSessionAnchorTags(tabId, url, sessionEntries));
      await save();
      await sendTagsUpdated(tabId, getTabEntries(tabId, url));
    }
    async function consumeQueuedSessionRestore(tabId) {
      await ensureLoaded();
      const pending = pendingSessionRestores.get(tabId);
      if (!pending) return;
      let currentUrl = pending.url;
      try {
        const tab = await import_webextension_polyfill2.default.tabs.get(tabId);
        currentUrl = tab.url || currentUrl;
      } catch (_) {
      }
      pendingSessionRestores.delete(tabId);
      if (normalizeUrlForMatch(currentUrl) !== normalizeUrlForMatch(pending.url)) {
        if (anchorTagsByTabId[tabKey(tabId)]) {
          delete anchorTagsByTabId[tabKey(tabId)];
          await save();
          await sendTagsUpdated(tabId, []);
        }
        return;
      }
      await replaceForSession(tabId, currentUrl, pending.entries);
    }
    async function replaceForSession(tabId, url, entries) {
      await ensureLoaded();
      pendingSessionRestores.delete(tabId);
      setTabEntries(tabId, fromSessionAnchorTags(tabId, url, entries));
      await save();
      await sendTagsUpdated(tabId, getTabEntries(tabId, url));
    }
    async function addCurrentTab() {
      await ensureLoaded();
      const tab = await getActiveTab();
      if (!tab?.id) return { ok: false, reason: "No active tab" };
      const url = tab.url || "";
      const entries = getTabEntries(tab.id, url);
      if (entries.length >= MAX_ANCHOR_TAGS) {
        await sendFeedback(tab.id, `Anchor Tags full (max ${MAX_ANCHOR_TAGS})`);
        return { ok: false, reason: `Anchor Tags full (max ${MAX_ANCHOR_TAGS})` };
      }
      const scroll = await getScroll(tab.id);
      if (isDuplicateAnchorTag(entries, scroll.scrollY)) {
        await sendFeedback(tab.id, "Anchor Tag already near here");
        return { ok: false, reason: "Anchor Tag already near here" };
      }
      const context = await getLabelContext(tab, scroll.scrollX, scroll.scrollY);
      const entry = {
        tabId: tab.id,
        url,
        slot: entries.length + 1,
        scrollX: scroll.scrollX,
        scrollY: scroll.scrollY,
        label: context.label || "Anchor Tag",
        isCustomLabel: false,
        createdAt: Date.now()
      };
      const nextEntries = sortAndCompactAnchorTags([...entries, entry]);
      setTabEntries(tab.id, nextEntries);
      await save();
      const savedEntry = nextEntries.find((candidate) => candidate.createdAt === entry.createdAt) || entry;
      await sendTagsUpdated(tab.id, getTabEntries(tab.id, url), savedEntry.slot);
      const tabManagerResult = await tabManagerState?.ensureManagedForAnchorTag(tab, scroll);
      const sessionNote = tabManagerResult && !tabManagerResult.ok ? " (not session-saved: Tab Manager full)" : "";
      await sendFeedback(tab.id, `Added Anchor Tag [${savedEntry.slot}]${sessionNote}`);
      return { ok: true, entry: savedEntry, slot: savedEntry.slot };
    }
    async function removeCurrentTabSlot(slot) {
      await ensureLoaded();
      const tab = await getActiveTab();
      if (!tab?.id) return { ok: false, reason: "No active tab" };
      const entries = getTabEntries(tab.id, tab.url || "");
      const removed = entries.find((entry) => entry.slot === slot);
      if (!removed) return { ok: false, reason: "Anchor Tag not found" };
      setTabEntries(tab.id, entries.filter((entry) => entry.slot !== slot));
      await save();
      await sendTagsUpdated(tab.id, getTabEntries(tab.id, tab.url || ""));
      return { ok: true, entry: removed };
    }
    async function renameCurrentTabSlot(slot, label) {
      await ensureLoaded();
      const tab = await getActiveTab();
      if (!tab?.id) return { ok: false, reason: "No active tab" };
      const trimmed = label.trim().slice(0, 30);
      if (!trimmed) return { ok: false, reason: "Name cannot be empty" };
      const entries = getTabEntries(tab.id, tab.url || "");
      const target = entries.find((entry) => entry.slot === slot);
      if (!target) return { ok: false, reason: "Anchor Tag not found" };
      target.label = trimmed;
      target.isCustomLabel = true;
      setTabEntries(tab.id, entries);
      await save();
      await sendTagsUpdated(tab.id, getTabEntries(tab.id, tab.url || ""), target.slot);
      return { ok: true, entry: target };
    }
    async function restoreCurrentTabEntry(entry) {
      await ensureLoaded();
      const tab = await getActiveTab();
      if (!tab?.id) return { ok: false, reason: "No active tab" };
      const url = tab.url || "";
      const entries = getTabEntries(tab.id, url);
      if (entries.length >= MAX_ANCHOR_TAGS) {
        return { ok: false, reason: `Anchor Tags full (max ${MAX_ANCHOR_TAGS})` };
      }
      if (isDuplicateAnchorTag(entries, entry.scrollY)) {
        return { ok: false, reason: "Anchor Tag already near here" };
      }
      const restored = {
        ...entry,
        tabId: tab.id,
        url
      };
      const nextEntries = sortAndCompactAnchorTags([...entries, restored]);
      setTabEntries(tab.id, nextEntries);
      await save();
      const savedEntry = nextEntries.find((candidate) => candidate.createdAt === entry.createdAt) || restored;
      await sendTagsUpdated(tab.id, getTabEntries(tab.id, url), savedEntry.slot);
      return { ok: true, entry: savedEntry, slot: savedEntry.slot };
    }
    async function cycleCurrentTab(direction) {
      await ensureLoaded();
      const tab = await getActiveTab();
      if (!tab?.id) return { ok: false, reason: "No active tab" };
      const entries = getTabEntries(tab.id, tab.url || "");
      const scroll = await getScroll(tab.id);
      const target = findAnchorCycleTarget(entries, scroll.scrollY, direction);
      if (!target) {
        await sendFeedback(tab.id, "No Anchor Tags in this tab");
        return { ok: false, reason: "No Anchor Tags in this tab" };
      }
      const ok = await scrollTabToAnchor(tab.id, target);
      if (!ok) return { ok: false, reason: "Jump failed" };
      await sendTagsUpdated(tab.id, entries, target.slot);
      return { ok: true, entry: target, slot: target.slot };
    }
    async function jumpCurrentTabSlot(slot) {
      await ensureLoaded();
      const tab = await getActiveTab();
      if (!tab?.id) return { ok: false, reason: "No active tab" };
      const entries = getTabEntries(tab.id, tab.url || "");
      const target = entries.find((entry) => entry.slot === slot);
      if (!target) return { ok: false, reason: "Anchor Tag not found" };
      const ok = await scrollTabToAnchor(tab.id, target);
      if (!ok) return { ok: false, reason: "Jump failed" };
      await sendTagsUpdated(tab.id, entries, target.slot);
      return { ok: true, entry: target, slot: target.slot };
    }
    async function clearAll() {
      await ensureLoaded();
      anchorTagsByTabId = {};
      pendingSessionRestores.clear();
      await save();
    }
    function registerLifecycleListeners() {
      import_webextension_polyfill2.default.tabs.onRemoved.addListener(async (tabId) => {
        await ensureLoaded();
        pendingSessionRestores.delete(tabId);
        if (!anchorTagsByTabId[tabKey(tabId)]) return;
        delete anchorTagsByTabId[tabKey(tabId)];
        await save();
      });
      import_webextension_polyfill2.default.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
        const changedUrl = changeInfo.url;
        if (!changedUrl) return;
        await ensureLoaded();
        const nextUrl = normalizeUrlForMatch(changedUrl);
        const pending = pendingSessionRestores.get(tabId);
        if (pending) {
          const pendingUrl = normalizeUrlForMatch(pending.url);
          if (nextUrl && pendingUrl && nextUrl === pendingUrl) return;
          pendingSessionRestores.delete(tabId);
        }
        const entries = anchorTagsByTabId[tabKey(tabId)] || [];
        if (entries.length === 0) return;
        const samePageEntries = entries.every(
          (entry) => normalizeUrlForMatch(entry.url) === nextUrl
        );
        if (nextUrl && samePageEntries) {
          anchorTagsByTabId[tabKey(tabId)] = entries.map((entry) => ({
            ...entry,
            url: changedUrl
          }));
          await save();
          await sendTagsUpdated(tabId, getTabEntries(tabId, changedUrl));
          return;
        }
        delete anchorTagsByTabId[tabKey(tabId)];
        await save();
        await sendTagsUpdated(tabId, []);
      });
      import_webextension_polyfill2.default.runtime.onStartup.addListener(async () => {
        await clearAll();
      });
    }
    return {
      ensureLoaded,
      listCurrentTab,
      listForSession,
      queueSessionRestore,
      consumeQueuedSessionRestore,
      replaceForSession,
      addCurrentTab,
      removeCurrentTabSlot,
      renameCurrentTabSlot,
      restoreCurrentTabEntry,
      cycleCurrentTab,
      jumpCurrentTabSlot,
      clearAll,
      registerLifecycleListeners
    };
  }

  // src/lib/backgroundRuntime/handlers/runtimeRouter.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());
  var UNHANDLED = Symbol("background-runtime-unhandled");
  function registerRuntimeMessageRouter(handlers) {
    import_webextension_polyfill3.default.runtime.onMessage.addListener(async (receivedMessage, sender) => {
      const message = receivedMessage;
      for (const handler of handlers) {
        const result = await handler(message, sender);
        if (result !== UNHANDLED) {
          return result;
        }
      }
      return null;
    });
  }

  // src/lib/backgroundRuntime/handlers/anchorTagsMessageHandler.ts
  function createAnchorTagsMessageHandler(domain) {
    return async (message, sender) => {
      switch (message.type) {
        case "ANCHOR_TAG_ADD":
          return await domain.addCurrentTab();
        case "ANCHOR_TAG_LIST":
          return await domain.listCurrentTab(sender.tab?.id, sender.tab?.url || "");
        case "ANCHOR_TAG_REMOVE":
          return await domain.removeCurrentTabSlot(message.slot);
        case "ANCHOR_TAG_RENAME":
          return await domain.renameCurrentTabSlot(message.slot, message.label);
        case "ANCHOR_TAG_RESTORE":
          return await domain.restoreCurrentTabEntry(message.entry);
        case "ANCHOR_TAG_CYCLE":
          return await domain.cycleCurrentTab(message.direction);
        case "ANCHOR_TAG_JUMP":
          return await domain.jumpCurrentTabSlot(message.slot);
        default:
          return UNHANDLED;
      }
    };
  }

  // src/lib/backgroundRuntime/handlers/commandRouter.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());
  var TAB_MANAGER_SLOT_COMMANDS = {
    "tab-manager-tab-1": 1,
    "tab-manager-tab-2": 2,
    "tab-manager-tab-3": 3,
    "tab-manager-tab-4": 4
  };
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function sendContentMessageWithRetry(tabId, message) {
    const retryDelaysMs = [0, 80, 220, 420];
    for (const delay of retryDelaysMs) {
      if (delay > 0) await sleep(delay);
      try {
        await import_webextension_polyfill4.default.tabs.sendMessage(tabId, message);
        return true;
      } catch (_) {
      }
    }
    return false;
  }
  function registerCommandRouter(deps) {
    import_webextension_polyfill4.default.commands.onCommand.addListener(async (command) => {
      const [activeTab] = await import_webextension_polyfill4.default.tabs.query({ active: true, currentWindow: true });
      if (!activeTab || activeTab.id == null) return;
      if (command === "open-tab-manager") {
        await sendContentMessageWithRetry(activeTab.id, { type: "OPEN_TAB_MANAGER" });
        return;
      }
      if (command === "tab-manager-add") {
        await deps.addTabManagerEntry(activeTab);
        return;
      }
      const slot = TAB_MANAGER_SLOT_COMMANDS[command];
      if (slot) {
        await deps.jumpToSlot(slot);
      }
    });
  }

  // src/lib/backgroundRuntime/domains/sessionDomain.ts
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());
  function resolveDisplayTitle(title, url) {
    const trimmedTitle = (title || "").trim();
    if (trimmedTitle) return trimmedTitle;
    const trimmedUrl = (url || "").trim();
    if (trimmedUrl) return trimmedUrl;
    return "Untitled";
  }
  function buildSessionSlotDiffs(currentList, incomingEntries) {
    const diffRows = [];
    const maxLen = Math.max(currentList.length, incomingEntries.length);
    for (let i = 0; i < maxLen; i++) {
      const current = currentList[i];
      const incoming = incomingEntries[i];
      const slot = i + 1;
      if (current && incoming) {
        diffRows.push({
          slot,
          change: "replace",
          currentTitle: resolveDisplayTitle(current.title, current.url),
          currentUrl: current.url,
          incomingTitle: resolveDisplayTitle(incoming.title, incoming.url),
          incomingUrl: incoming.url
        });
        continue;
      }
      if (current) {
        diffRows.push({
          slot,
          change: "remove",
          currentTitle: resolveDisplayTitle(current.title, current.url),
          currentUrl: current.url
        });
        continue;
      }
      if (incoming) {
        diffRows.push({
          slot,
          change: "add",
          incomingTitle: resolveDisplayTitle(incoming.title, incoming.url),
          incomingUrl: incoming.url
        });
      }
    }
    return diffRows;
  }
  function buildSessionReuseMatches(entries, reuseTabIds, currentList) {
    const matches = [];
    for (let i = 0; i < entries.length; i++) {
      const reusedTabId = reuseTabIds[i];
      if (reusedTabId == null) continue;
      const current = currentList[i];
      if (!current || current.tabId !== reusedTabId) continue;
      const entry = entries[i];
      matches.push({
        slot: i + 1,
        sessionTitle: resolveDisplayTitle(entry.title, entry.url),
        sessionUrl: entry.url,
        openTabTitle: resolveDisplayTitle(current.title, current.url),
        openTabUrl: current.url || entry.url
      });
    }
    return matches;
  }
  function computeSessionLoad(entries, currentList) {
    const reuseTabIds = [];
    let reuseCount = 0;
    let openCount = 0;
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i];
      const current = currentList[i];
      const incomingUrl = normalizeUrlForMatch(entry.url);
      const currentUrl = normalizeUrlForMatch(current?.url || "");
      const isUnchangedSlot = !!(current && !current.closed && incomingUrl && currentUrl && incomingUrl === currentUrl);
      if (isUnchangedSlot) {
        reuseTabIds.push(current.tabId);
        reuseCount++;
      } else {
        reuseTabIds.push(null);
        openCount++;
      }
    }
    return { reuseTabIds, reuseCount, openCount };
  }
  async function buildSessionEntries(currentList, anchorTagsState) {
    return await Promise.all(currentList.map(async (entry) => ({
      url: entry.url,
      title: entry.title,
      isCustomTitle: entry.isCustomTitle === true,
      scrollX: entry.scrollX,
      scrollY: entry.scrollY,
      anchorTags: anchorTagsState ? await anchorTagsState.listForSession(entry.tabId, entry.url) : []
    })));
  }
  function buildSessionSignature(entries) {
    return entries.map((entry) => JSON.stringify({
      url: normalizeUrlForMatch(entry.url),
      anchorTags: (entry.anchorTags || []).map((anchorTag) => ({
        scrollX: anchorTag.scrollX,
        scrollY: anchorTag.scrollY,
        label: anchorTag.label,
        isCustomLabel: anchorTag.isCustomLabel === true
      }))
    })).join("\n");
  }
  async function restoreSessionAnchorTags(anchorTagsState, sessionEntry, loadedEntry, timing) {
    if (!anchorTagsState || !Array.isArray(sessionEntry.anchorTags)) return;
    const sessionUrl = normalizeUrlForMatch(sessionEntry.url);
    const loadedUrl = normalizeUrlForMatch(loadedEntry.url);
    if (!sessionUrl || !loadedUrl || sessionUrl !== loadedUrl) return;
    if (timing === "deferred") {
      await anchorTagsState.queueSessionRestore(
        loadedEntry.tabId,
        loadedEntry.url,
        sessionEntry.anchorTags
      );
      return;
    }
    await anchorTagsState.replaceForSession(
      loadedEntry.tabId,
      loadedEntry.url,
      sessionEntry.anchorTags
    );
  }
  async function commitLoadedSessionList(state, loadedEntries) {
    state.setList(loadedEntries);
    state.recompactSlots();
    await state.save();
  }
  async function sessionSave(state, name, anchorTagsState) {
    await state.ensureLoaded();
    const currentList = state.getList();
    if (currentList.length === 0) {
      return { ok: false, reason: "Cannot save empty tab manager list" };
    }
    const sessionEntries = await buildSessionEntries(currentList, anchorTagsState);
    const session = {
      name,
      entries: sessionEntries,
      savedAt: Date.now()
    };
    const stored = await import_webextension_polyfill5.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const nameTaken = sessions.some(
      (existingSession) => existingSession.name.toLowerCase() === name.toLowerCase()
    );
    if (nameTaken) {
      return { ok: false, reason: `"${name}" already exists` };
    }
    const currentSignature = buildSessionSignature(sessionEntries);
    const identicalSession = sessions.find((existingSession) => {
      const sessionSignature = buildSessionSignature(existingSession.entries);
      return sessionSignature === currentSignature;
    });
    if (identicalSession) {
      return { ok: false, reason: `Identical to "${identicalSession.name}"` };
    }
    if (sessions.length >= MAX_SESSIONS) {
      return { ok: false, reason: `Max ${MAX_SESSIONS} sessions \u2014 delete one first` };
    }
    sessions.push(session);
    await import_webextension_polyfill5.default.storage.local.set({ tabManagerSessions: sessions });
    return { ok: true };
  }
  async function sessionList() {
    const stored = await import_webextension_polyfill5.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    return sessions.slice().sort((a, b) => b.savedAt - a.savedAt);
  }
  async function sessionLoadPlan(state, name) {
    await state.ensureLoaded();
    const stored = await import_webextension_polyfill5.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const session = sessions.find((savedSession) => savedSession.name === name);
    if (!session) return { ok: false, reason: "Session not found" };
    const currentList = state.getList();
    const computation = computeSessionLoad(session.entries, currentList);
    const slotDiffs = buildSessionSlotDiffs(currentList, session.entries);
    const reuseMatches = buildSessionReuseMatches(session.entries, computation.reuseTabIds, currentList);
    return {
      ok: true,
      summary: {
        sessionName: session.name,
        totalCount: session.entries.length,
        replaceCount: currentList.length,
        openCount: computation.openCount,
        reuseCount: computation.reuseCount,
        slotDiffs,
        reuseMatches
      }
    };
  }
  async function sessionLoad(state, name, anchorTagsState) {
    await state.ensureLoaded();
    const stored = await import_webextension_polyfill5.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const session = sessions.find((savedSession) => savedSession.name === name);
    if (!session) return { ok: false, reason: "Session not found" };
    const currentList = state.getList();
    const replaceCount = currentList.length;
    const loadPlan = computeSessionLoad(session.entries, currentList);
    const newList = [];
    let openedCount = 0;
    let reusedCount = 0;
    await commitLoadedSessionList(state, newList);
    for (let i = 0; i < session.entries.length; i++) {
      const entry = session.entries[i];
      const isCustomTitle = entry.isCustomTitle === true;
      const reusableTabId = loadPlan.reuseTabIds[i];
      if (reusableTabId != null) {
        try {
          const reusedTab = await import_webextension_polyfill5.default.tabs.get(reusableTabId);
          if (reusedTab.id == null) throw new Error("Reusable tab missing id");
          const loadedEntry = {
            tabId: reusedTab.id,
            url: reusedTab.url || entry.url,
            title: isCustomTitle ? entry.title : reusedTab.title || entry.title,
            isCustomTitle,
            scrollX: entry.scrollX,
            scrollY: entry.scrollY,
            slot: newList.length + 1
          };
          newList.push(loadedEntry);
          await commitLoadedSessionList(state, newList);
          await restoreSessionAnchorTags(anchorTagsState, entry, loadedEntry, "immediate");
          if (entry.scrollX || entry.scrollY) {
            state.queueScrollRestore(reusedTab.id, entry.scrollX, entry.scrollY);
          }
          reusedCount++;
          continue;
        } catch (_) {
        }
      }
      try {
        const tab = await import_webextension_polyfill5.default.tabs.create({ url: entry.url, active: false });
        const loadedEntry = {
          tabId: tab.id,
          url: entry.url,
          title: entry.title,
          isCustomTitle,
          scrollX: entry.scrollX,
          scrollY: entry.scrollY,
          slot: newList.length + 1
        };
        newList.push(loadedEntry);
        await commitLoadedSessionList(state, newList);
        await restoreSessionAnchorTags(anchorTagsState, entry, loadedEntry, "deferred");
        openedCount++;
        if (entry.scrollX || entry.scrollY) {
          state.queueScrollRestore(tab.id, entry.scrollX, entry.scrollY);
        }
      } catch (_) {
      }
    }
    await commitLoadedSessionList(state, newList);
    if (newList.length > 0) {
      await import_webextension_polyfill5.default.tabs.update(newList[0].tabId, { active: true });
    }
    return {
      ok: true,
      count: newList.length,
      replaceCount,
      openCount: openedCount,
      reuseCount: reusedCount
    };
  }
  async function sessionRename(oldName, newName) {
    const trimmed = newName.trim();
    if (!trimmed) return { ok: false, reason: "Name cannot be empty" };
    const stored = await import_webextension_polyfill5.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const session = sessions.find((savedSession) => savedSession.name === oldName);
    if (!session) return { ok: false, reason: "Session not found" };
    const nameTaken = sessions.some(
      (savedSession) => savedSession.name !== oldName && savedSession.name.toLowerCase() === trimmed.toLowerCase()
    );
    if (nameTaken) return { ok: false, reason: `"${trimmed}" already exists` };
    session.name = trimmed;
    await import_webextension_polyfill5.default.storage.local.set({ tabManagerSessions: sessions });
    return { ok: true };
  }
  async function sessionUpdate(state, name, anchorTagsState) {
    await state.ensureLoaded();
    if (state.getList().length === 0) {
      return { ok: false, reason: "Cannot update \u2014 tab manager list is empty" };
    }
    const stored = await import_webextension_polyfill5.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const session = sessions.find((savedSession) => savedSession.name === name);
    if (!session) return { ok: false, reason: "Session not found" };
    session.entries = await buildSessionEntries(state.getList(), anchorTagsState);
    session.savedAt = Date.now();
    await import_webextension_polyfill5.default.storage.local.set({ tabManagerSessions: sessions });
    return { ok: true };
  }
  async function sessionReplace(state, oldName, newName, anchorTagsState) {
    await state.ensureLoaded();
    if (state.getList().length === 0) {
      return { ok: false, reason: "Cannot replace \u2014 tab manager list is empty" };
    }
    const trimmed = newName.trim();
    if (!trimmed) return { ok: false, reason: "Name cannot be empty" };
    const stored = await import_webextension_polyfill5.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const targetIndex = sessions.findIndex((savedSession) => savedSession.name === oldName);
    if (targetIndex === -1) return { ok: false, reason: "Session not found" };
    const nameTaken = sessions.some(
      (savedSession, index) => index !== targetIndex && savedSession.name.toLowerCase() === trimmed.toLowerCase()
    );
    if (nameTaken) return { ok: false, reason: `"${trimmed}" already exists` };
    sessions[targetIndex] = {
      name: trimmed,
      entries: await buildSessionEntries(state.getList(), anchorTagsState),
      savedAt: Date.now()
    };
    await import_webextension_polyfill5.default.storage.local.set({ tabManagerSessions: sessions });
    return { ok: true };
  }
  async function sessionDelete(name) {
    const stored = await import_webextension_polyfill5.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const filtered = sessions.filter((savedSession) => savedSession.name !== name);
    await import_webextension_polyfill5.default.storage.local.set({ tabManagerSessions: filtered });
    return { ok: true };
  }

  // src/lib/backgroundRuntime/handlers/sessionMessageHandler.ts
  function createSessionMessageHandler(tabManagerState, anchorTagsState) {
    return async (message) => {
      switch (message.type) {
        case "SESSION_SAVE":
          return await sessionSave(tabManagerState, message.name, anchorTagsState);
        case "SESSION_LIST":
          return await sessionList();
        case "SESSION_LOAD_PLAN":
          return await sessionLoadPlan(tabManagerState, message.name);
        case "SESSION_LOAD":
          return await sessionLoad(tabManagerState, message.name, anchorTagsState);
        case "SESSION_DELETE":
          return await sessionDelete(message.name);
        case "SESSION_RENAME":
          return await sessionRename(message.oldName, message.newName);
        case "SESSION_UPDATE":
          return await sessionUpdate(tabManagerState, message.name, anchorTagsState);
        case "SESSION_REPLACE":
          return await sessionReplace(
            tabManagerState,
            message.oldName,
            message.newName,
            anchorTagsState
          );
        default:
          return UNHANDLED;
      }
    };
  }

  // src/lib/backgroundRuntime/domains/tabManagerDomain.ts
  var import_webextension_polyfill6 = __toESM(require_browser_polyfill());
  function createTabManagerDomain() {
    let tabManagerList = [];
    let tabManagerLoaded = false;
    let lastActiveTabId = null;
    let onUpdatedSaveTimer = null;
    let scrollRestoreSeq = 0;
    const pendingScrollRestore = /* @__PURE__ */ new Map();
    const pendingScrollRestoreTokens = /* @__PURE__ */ new Map();
    async function ensureTabManagerLoaded() {
      if (!tabManagerLoaded) {
        const data = await import_webextension_polyfill6.default.storage.local.get("tabManagerList");
        tabManagerList = data.tabManagerList || [];
        tabManagerLoaded = true;
      }
    }
    async function saveTabManager() {
      await import_webextension_polyfill6.default.storage.local.set({ tabManagerList });
    }
    function sleep2(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
    function recompactSlots() {
      tabManagerList.forEach((entry, index) => {
        entry.slot = index + 1;
      });
    }
    function normalizeCustomTitle(label) {
      return label.replace(/\s+/g, " ").trim().slice(0, MAX_TAB_MANAGER_TITLE_LENGTH);
    }
    async function reconcileTabManager() {
      await ensureTabManagerLoaded();
      const tabs = await import_webextension_polyfill6.default.tabs.query({});
      const tabIds = new Set(tabs.map((tab) => tab.id));
      let changed = false;
      for (const entry of tabManagerList) {
        const shouldBeClosed = !tabIds.has(entry.tabId);
        if (entry.closed !== shouldBeClosed) {
          entry.closed = shouldBeClosed;
          changed = true;
        }
      }
      for (let i = 0; i < tabManagerList.length; i++) {
        const nextSlot = i + 1;
        if (tabManagerList[i].slot !== nextSlot) {
          tabManagerList[i].slot = nextSlot;
          changed = true;
        }
      }
      if (changed) await saveTabManager();
    }
    async function tabManagerAdd(tab) {
      if (tab.id == null) {
        return { ok: false, reason: "Active tab unavailable." };
      }
      await reconcileTabManager();
      if (tabManagerList.length >= MAX_TAB_MANAGER_SLOTS) {
        try {
          await import_webextension_polyfill6.default.tabs.sendMessage(tab.id, {
            type: "TAB_MANAGER_FULL_FEEDBACK",
            max: MAX_TAB_MANAGER_SLOTS
          });
        } catch (_) {
        }
        return { ok: false, reason: `Tab Manager list is full (max ${MAX_TAB_MANAGER_SLOTS}).` };
      }
      const normalizedTabUrl = normalizeUrlForMatch(tab.url || "");
      const existing = tabManagerList.find((entry) => entry.tabId === tab.id || normalizedTabUrl.length > 0 && normalizeUrlForMatch(entry.url) === normalizedTabUrl);
      if (existing) {
        if (existing.closed && normalizedTabUrl.length > 0 && normalizeUrlForMatch(existing.url) === normalizedTabUrl) {
          existing.tabId = tab.id;
          existing.closed = false;
          if (!existing.isCustomTitle) existing.title = tab.title || existing.title;
          await saveTabManager();
        }
        try {
          await import_webextension_polyfill6.default.tabs.sendMessage(tab.id, {
            type: "TAB_MANAGER_ADDED_FEEDBACK",
            slot: existing.slot,
            title: tab.title,
            alreadyAdded: true
          });
        } catch (_) {
        }
        return { ok: false, reason: "Tab already in Tab Manager list." };
      }
      let scrollX = 0;
      let scrollY = 0;
      try {
        const response = await import_webextension_polyfill6.default.tabs.sendMessage(tab.id, {
          type: "GET_SCROLL"
        });
        scrollX = response.scrollX || 0;
        scrollY = response.scrollY || 0;
      } catch (_) {
      }
      const slot = tabManagerList.length + 1;
      tabManagerList.push({
        tabId: tab.id,
        url: tab.url || "",
        title: tab.title || "",
        isCustomTitle: false,
        scrollX,
        scrollY,
        slot
      });
      await saveTabManager();
      try {
        await import_webextension_polyfill6.default.tabs.sendMessage(tab.id, {
          type: "TAB_MANAGER_ADDED_FEEDBACK",
          slot,
          title: tab.title
        });
      } catch (_) {
      }
      return { ok: true, slot };
    }
    async function tabManagerRemove(tabId) {
      await ensureTabManagerLoaded();
      tabManagerList = tabManagerList.filter((entry) => entry.tabId !== tabId);
      pendingScrollRestore.delete(tabId);
      pendingScrollRestoreTokens.delete(tabId);
      recompactSlots();
      await saveTabManager();
    }
    async function tabManagerRename(tabId, label) {
      await ensureTabManagerLoaded();
      const trimmed = normalizeCustomTitle(label);
      if (!trimmed) return { ok: false, reason: "Name cannot be empty" };
      const entry = tabManagerList.find((candidate) => candidate.tabId === tabId);
      if (!entry) return { ok: false, reason: "Tab Manager entry not found" };
      entry.title = trimmed;
      entry.isCustomTitle = true;
      await saveTabManager();
      return { ok: true };
    }
    async function captureManagedTabScroll(tabId) {
      const entry = tabManagerList.find((candidate) => candidate.tabId === tabId);
      if (!entry || entry.closed) return false;
      try {
        const response = await import_webextension_polyfill6.default.tabs.sendMessage(tabId, {
          type: "GET_SCROLL"
        });
        const nextX = response.scrollX || 0;
        const nextY = response.scrollY || 0;
        if (entry.scrollX === nextX && entry.scrollY === nextY) return false;
        entry.scrollX = nextX;
        entry.scrollY = nextY;
        return true;
      } catch (_) {
        return false;
      }
    }
    async function saveCurrentTabScroll() {
      await ensureTabManagerLoaded();
      const [activeTab] = await import_webextension_polyfill6.default.tabs.query({ active: true, currentWindow: true });
      if (!activeTab || activeTab.id == null) return;
      if (await captureManagedTabScroll(activeTab.id)) await saveTabManager();
    }
    async function ensureManagedForAnchorTag(tab, scroll) {
      if (tab.id == null) return { ok: false, reason: "Active tab unavailable." };
      await reconcileTabManager();
      const normalizedTabUrl = normalizeUrlForMatch(tab.url || "");
      const existingByTab = tabManagerList.find((entry) => entry.tabId === tab.id);
      if (existingByTab) return { ok: true, added: false };
      const existingByUrl = normalizedTabUrl ? tabManagerList.find((entry) => normalizeUrlForMatch(entry.url) === normalizedTabUrl) : void 0;
      if (existingByUrl) {
        existingByUrl.tabId = tab.id;
        existingByUrl.url = tab.url || existingByUrl.url;
        existingByUrl.closed = false;
        existingByUrl.scrollX = scroll.scrollX || 0;
        existingByUrl.scrollY = scroll.scrollY || 0;
        if (!existingByUrl.isCustomTitle) existingByUrl.title = tab.title || existingByUrl.title;
        await saveTabManager();
        return { ok: true, added: false };
      }
      if (tabManagerList.length >= MAX_TAB_MANAGER_SLOTS) {
        return { ok: false, reason: `Tab Manager list is full (max ${MAX_TAB_MANAGER_SLOTS}).` };
      }
      tabManagerList.push({
        tabId: tab.id,
        url: tab.url || "",
        title: tab.title || "",
        isCustomTitle: false,
        scrollX: scroll.scrollX || 0,
        scrollY: scroll.scrollY || 0,
        slot: tabManagerList.length + 1
      });
      await saveTabManager();
      return { ok: true, added: true };
    }
    function scheduleScrollRestore(tabId, scrollX, scrollY) {
      if (!scrollX && !scrollY) {
        pendingScrollRestore.delete(tabId);
        pendingScrollRestoreTokens.delete(tabId);
        return;
      }
      pendingScrollRestore.set(tabId, { scrollX, scrollY });
      const token = ++scrollRestoreSeq;
      pendingScrollRestoreTokens.set(tabId, token);
      const retryDelaysMs = [0, 80, 220, 420];
      void (async () => {
        for (const delay of retryDelaysMs) {
          if (pendingScrollRestoreTokens.get(tabId) !== token) return;
          if (delay > 0) await sleep2(delay);
          try {
            await import_webextension_polyfill6.default.tabs.sendMessage(tabId, {
              type: "SET_SCROLL",
              scrollX,
              scrollY
            });
            if (pendingScrollRestoreTokens.get(tabId) !== token) return;
            pendingScrollRestore.delete(tabId);
            pendingScrollRestoreTokens.delete(tabId);
            return;
          } catch (_) {
          }
        }
      })();
    }
    async function tabManagerJump(slot) {
      await ensureTabManagerLoaded();
      const entry = tabManagerList.find((candidate) => candidate.slot === slot);
      if (!entry) return;
      const [activeTab] = await import_webextension_polyfill6.default.tabs.query({ active: true, currentWindow: true });
      const previousTabId = activeTab?.id;
      if (previousTabId != null && previousTabId !== entry.tabId) {
        if (await captureManagedTabScroll(previousTabId)) await saveTabManager();
      }
      if (entry.closed) {
        try {
          const newTab = await import_webextension_polyfill6.default.tabs.create({ url: entry.url, active: true });
          if (newTab.id == null) return;
          entry.tabId = newTab.id;
          entry.closed = false;
          await saveTabManager();
          scheduleScrollRestore(newTab.id, entry.scrollX, entry.scrollY);
        } catch (_) {
          tabManagerList = tabManagerList.filter((candidate) => candidate.slot !== slot);
          recompactSlots();
          await saveTabManager();
        }
        return;
      }
      const switched = await import_webextension_polyfill6.default.tabs.update(entry.tabId, { active: true }).catch(() => null);
      if (!switched) {
        entry.closed = true;
        await saveTabManager();
        await tabManagerJump(slot);
        return;
      }
      scheduleScrollRestore(entry.tabId, entry.scrollX, entry.scrollY);
    }
    async function tabManagerCycle(direction) {
      await ensureTabManagerLoaded();
      if (tabManagerList.length === 0) return { ok: false };
      const [currentTab] = await import_webextension_polyfill6.default.tabs.query({ active: true, currentWindow: true });
      const currentIdx = currentTab ? tabManagerList.findIndex((entry) => entry.tabId === currentTab.id) : -1;
      let targetIdx;
      if (currentIdx === -1) {
        targetIdx = direction === "next" ? 0 : tabManagerList.length - 1;
      } else {
        targetIdx = direction === "next" ? (currentIdx + 1) % tabManagerList.length : (currentIdx - 1 + tabManagerList.length) % tabManagerList.length;
      }
      await tabManagerJump(tabManagerList[targetIdx].slot);
      return { ok: true };
    }
    async function reorder(list) {
      await ensureTabManagerLoaded();
      tabManagerList = list;
      recompactSlots();
      await saveTabManager();
    }
    function consumePendingScrollRestore(tabId) {
      const pending = pendingScrollRestore.get(tabId) || null;
      if (pending) {
        pendingScrollRestore.delete(tabId);
        pendingScrollRestoreTokens.delete(tabId);
      }
      return pending;
    }
    async function clearAll() {
      await ensureTabManagerLoaded();
      tabManagerList = [];
      await saveTabManager();
    }
    async function captureInitialActiveTab() {
      try {
        const [tab] = await import_webextension_polyfill6.default.tabs.query({ active: true, currentWindow: true });
        if (tab?.id != null) lastActiveTabId = tab.id;
      } catch (_) {
      }
    }
    function registerLifecycleListeners() {
      import_webextension_polyfill6.default.tabs.onRemoved.addListener(async (tabId) => {
        await ensureTabManagerLoaded();
        pendingScrollRestore.delete(tabId);
        pendingScrollRestoreTokens.delete(tabId);
        const entry = tabManagerList.find((candidate) => candidate.tabId === tabId);
        if (entry) {
          entry.closed = true;
          await saveTabManager();
        }
      });
      import_webextension_polyfill6.default.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
        await ensureTabManagerLoaded();
        const entry = tabManagerList.find((candidate) => candidate.tabId === tabId);
        if (!entry) return;
        let changed = false;
        if (changeInfo.url) {
          entry.url = changeInfo.url;
          changed = true;
        }
        if (changeInfo.title && !entry.isCustomTitle) {
          entry.title = changeInfo.title;
          changed = true;
        }
        if (!changed) return;
        if (onUpdatedSaveTimer) clearTimeout(onUpdatedSaveTimer);
        onUpdatedSaveTimer = setTimeout(() => {
          onUpdatedSaveTimer = null;
          saveTabManager();
        }, 500);
      });
      import_webextension_polyfill6.default.tabs.onActivated.addListener(async (activeInfo) => {
        const previousTabId = lastActiveTabId;
        lastActiveTabId = activeInfo.tabId;
        if (previousTabId == null) return;
        await ensureTabManagerLoaded();
        if (await captureManagedTabScroll(previousTabId)) await saveTabManager();
      });
    }
    const state = {
      getList: () => tabManagerList,
      setList: (list) => {
        tabManagerList = list;
      },
      recompactSlots,
      save: saveTabManager,
      ensureLoaded: ensureTabManagerLoaded,
      queueScrollRestore: (tabId, scrollX, scrollY) => {
        scheduleScrollRestore(tabId, scrollX, scrollY);
      }
    };
    return {
      state,
      list: () => tabManagerList,
      ensureLoaded: ensureTabManagerLoaded,
      reconcile: reconcileTabManager,
      add: tabManagerAdd,
      remove: tabManagerRemove,
      rename: tabManagerRename,
      jump: tabManagerJump,
      cycle: tabManagerCycle,
      saveCurrentTabScroll,
      ensureManagedForAnchorTag,
      reorder,
      consumePendingScrollRestore,
      clearAll,
      captureInitialActiveTab,
      registerLifecycleListeners
    };
  }

  // src/lib/backgroundRuntime/handlers/tabManagerMessageHandler.ts
  var import_webextension_polyfill7 = __toESM(require_browser_polyfill());
  function createTabManagerMessageHandler(domain, anchorTagsState) {
    return async (message, sender) => {
      switch (message.type) {
        case "TAB_MANAGER_ADD": {
          const [tab] = await import_webextension_polyfill7.default.tabs.query({ active: true, currentWindow: true });
          if (!tab) return { ok: false, reason: "No active tab" };
          return await domain.add(tab);
        }
        case "TAB_MANAGER_REMOVE":
          await domain.remove(message.tabId);
          return { ok: true };
        case "TAB_MANAGER_RENAME":
          return await domain.rename(message.tabId, message.label);
        case "TAB_MANAGER_LIST":
          await domain.reconcile();
          return domain.list();
        case "TAB_MANAGER_JUMP":
          await domain.jump(message.slot);
          return { ok: true };
        case "TAB_MANAGER_CYCLE":
          return await domain.cycle(message.direction);
        case "TAB_MANAGER_SAVE_SCROLL":
          await domain.saveCurrentTabScroll();
          return { ok: true };
        case "TAB_MANAGER_REORDER":
          await domain.reorder(message.list);
          return { ok: true };
        case "CONTENT_SCRIPT_READY": {
          const tabId = sender.tab?.id;
          if (tabId == null) return { ok: true };
          const pending = domain.consumePendingScrollRestore(tabId);
          if (pending) {
            import_webextension_polyfill7.default.tabs.sendMessage(tabId, {
              type: "SET_SCROLL",
              scrollX: pending.scrollX,
              scrollY: pending.scrollY
            }).catch(() => {
            });
          }
          await anchorTagsState?.consumeQueuedSessionRestore(tabId);
          return { ok: true };
        }
        default:
          return UNHANDLED;
      }
    };
  }

  // src/lib/backgroundRuntime/handlers/miscMessageHandler.ts
  var import_webextension_polyfill8 = __toESM(require_browser_polyfill());
  var miscMessageHandler = async (message) => {
    switch (message.type) {
      case "GET_CURRENT_TAB": {
        const [tab] = await import_webextension_polyfill8.default.tabs.query({ active: true, currentWindow: true });
        return tab || null;
      }
      case "GET_KEYBINDINGS":
        return await loadKeybindings();
      case "SAVE_KEYBINDINGS":
        await saveKeybindings(message.config);
        return { ok: true };
      default:
        return UNHANDLED;
    }
  };

  // src/lib/backgroundRuntime/lifecycle/startupRestore.ts
  var import_webextension_polyfill9 = __toESM(require_browser_polyfill());
  function registerStartupRestore(deps) {
    import_webextension_polyfill9.default.runtime.onStartup.addListener(async () => {
      const stored = await import_webextension_polyfill9.default.storage.local.get("tabManagerSessions");
      const sessions = stored.tabManagerSessions || [];
      if (sessions.length === 0) return;
      await deps.clearTabManager();
      let attempts = 0;
      const tryPrompt = async () => {
        attempts += 1;
        const [tab] = await import_webextension_polyfill9.default.tabs.query({ active: true, currentWindow: true });
        if (!tab?.id) {
          if (attempts < 5) setTimeout(tryPrompt, 1e3);
          return;
        }
        try {
          await import_webextension_polyfill9.default.tabs.sendMessage(tab.id, { type: "SHOW_SESSION_RESTORE" });
        } catch (_) {
          if (attempts < 5) setTimeout(tryPrompt, 1e3);
        }
      };
      setTimeout(tryPrompt, 1500);
    });
  }

  // src/lib/common/utils/storageMigrationsRuntime.ts
  var import_webextension_polyfill10 = __toESM(require_browser_polyfill());

  // src/lib/common/utils/storageMigrations.ts
  var STORAGE_SCHEMA_VERSION_KEY = "storageSchemaVersion";
  var STORAGE_SCHEMA_VERSION = 2;
  var MAX_TAB_MANAGER_SLOTS2 = 4;
  var MAX_ANCHOR_TAGS2 = 4;
  var MAX_SESSIONS2 = 4;
  function hasKey(storage, key) {
    return Object.prototype.hasOwnProperty.call(storage, key);
  }
  function toNonNegativeNumber(value, fallback) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.max(0, numeric);
  }
  function toPositiveInteger(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return null;
    const rounded = Math.floor(numeric);
    if (rounded <= 0) return null;
    return rounded;
  }
  function asString(value) {
    return typeof value === "string" ? value : "";
  }
  function readSchemaVersion(storage) {
    const value = toPositiveInteger(storage[STORAGE_SCHEMA_VERSION_KEY]);
    return value || 0;
  }
  function deepEqual(left, right) {
    return JSON.stringify(left) === JSON.stringify(right);
  }
  function normalizeTabManagerList(rawValue) {
    if (!Array.isArray(rawValue)) return null;
    const normalized = [];
    for (const rawEntry of rawValue) {
      if (typeof rawEntry !== "object" || rawEntry === null) continue;
      const entry = rawEntry;
      const tabId = toPositiveInteger(entry.tabId);
      const url = asString(entry.url);
      if (!tabId || !url) continue;
      const normalizedEntry = {
        tabId,
        url,
        title: asString(entry.title),
        scrollX: toNonNegativeNumber(entry.scrollX, 0),
        scrollY: toNonNegativeNumber(entry.scrollY, 0),
        slot: normalized.length + 1
      };
      if (entry.isCustomTitle === true) {
        normalizedEntry.isCustomTitle = true;
      }
      if (entry.closed === true) {
        normalizedEntry.closed = true;
      }
      normalized.push(normalizedEntry);
      if (normalized.length >= MAX_TAB_MANAGER_SLOTS2) break;
    }
    return normalized;
  }
  function normalizeSessionAnchorTags(rawValue) {
    if (!Array.isArray(rawValue)) return void 0;
    const normalized = [];
    for (const rawAnchorTag of rawValue) {
      if (typeof rawAnchorTag !== "object" || rawAnchorTag === null) continue;
      const anchorTag = rawAnchorTag;
      normalized.push({
        slot: normalized.length + 1,
        scrollX: toNonNegativeNumber(anchorTag.scrollX, 0),
        scrollY: toNonNegativeNumber(anchorTag.scrollY, 0),
        label: asString(anchorTag.label).trim().slice(0, 30) || "Anchor Tag",
        isCustomLabel: anchorTag.isCustomLabel === true,
        createdAt: toNonNegativeNumber(anchorTag.createdAt, 0)
      });
      if (normalized.length >= MAX_ANCHOR_TAGS2) break;
    }
    return normalized.length > 0 ? normalized : void 0;
  }
  function normalizeSessions(rawValue) {
    if (!Array.isArray(rawValue)) return null;
    const normalized = [];
    const seenSessionNames = /* @__PURE__ */ new Set();
    for (const rawSession of rawValue) {
      if (typeof rawSession !== "object" || rawSession === null) continue;
      const session = rawSession;
      const name = asString(session.name).trim();
      if (!name) continue;
      const lowerName = name.toLowerCase();
      if (seenSessionNames.has(lowerName)) continue;
      const rawEntries = Array.isArray(session.entries) ? session.entries : [];
      const entries = [];
      for (const rawEntry of rawEntries) {
        if (typeof rawEntry !== "object" || rawEntry === null) continue;
        const entry = rawEntry;
        const url = asString(entry.url);
        if (!url) continue;
        const normalizedEntry = {
          url,
          title: asString(entry.title),
          scrollX: toNonNegativeNumber(entry.scrollX, 0),
          scrollY: toNonNegativeNumber(entry.scrollY, 0)
        };
        if (entry.isCustomTitle === true) {
          normalizedEntry.isCustomTitle = true;
        }
        const anchorTags = normalizeSessionAnchorTags(entry.anchorTags);
        if (anchorTags) {
          normalizedEntry.anchorTags = anchorTags;
        }
        entries.push(normalizedEntry);
      }
      if (entries.length === 0) continue;
      normalized.push({
        name,
        entries,
        savedAt: toNonNegativeNumber(session.savedAt, 0)
      });
      seenSessionNames.add(lowerName);
      if (normalized.length >= MAX_SESSIONS2) break;
    }
    return normalized;
  }
  function normalizeKey(storage, key, normalizer) {
    if (!hasKey(storage, key)) return false;
    const normalized = normalizer(storage[key]);
    if (normalized === null) return false;
    if (deepEqual(storage[key], normalized)) return false;
    storage[key] = normalized;
    return true;
  }
  function deleteKey(storage, key) {
    if (!hasKey(storage, key)) return false;
    delete storage[key];
    return true;
  }
  function migrateV0ToV1(storage) {
    let changed = false;
    changed = normalizeKey(storage, "tabManagerList", normalizeTabManagerList) || changed;
    changed = normalizeKey(storage, "tabManagerSessions", normalizeSessions) || changed;
    return changed;
  }
  function migrateV1ToV2(storage) {
    return deleteKey(storage, "frecencyData");
  }
  function migrateStorageSnapshot(input) {
    const migratedStorage = { ...input };
    const fromVersion = readSchemaVersion(input);
    if (fromVersion > STORAGE_SCHEMA_VERSION) {
      return {
        fromVersion,
        toVersion: fromVersion,
        changed: false,
        migratedStorage
      };
    }
    let changed = false;
    let workingVersion = fromVersion;
    while (workingVersion < STORAGE_SCHEMA_VERSION) {
      if (workingVersion === 0) {
        changed = migrateV0ToV1(migratedStorage) || changed;
        workingVersion = 1;
        continue;
      }
      if (workingVersion === 1) {
        changed = migrateV1ToV2(migratedStorage) || changed;
        workingVersion = 2;
        continue;
      }
      break;
    }
    if (migratedStorage[STORAGE_SCHEMA_VERSION_KEY] !== workingVersion) {
      migratedStorage[STORAGE_SCHEMA_VERSION_KEY] = workingVersion;
      changed = true;
    }
    return {
      fromVersion,
      toVersion: workingVersion,
      changed,
      migratedStorage
    };
  }

  // src/lib/common/utils/storageMigrationsRuntime.ts
  async function migrateStorageIfNeeded() {
    const snapshot = await import_webextension_polyfill10.default.storage.local.get(null);
    const result = migrateStorageSnapshot(snapshot);
    if (!result.changed) return result;
    const deletedKeys = Object.keys(snapshot).filter((key) => !(key in result.migratedStorage));
    if (deletedKeys.length > 0) {
      await import_webextension_polyfill10.default.storage.local.remove(deletedKeys);
    }
    await import_webextension_polyfill10.default.storage.local.set(result.migratedStorage);
    return result;
  }

  // src/entryPoints/backgroundRuntime/background.ts
  async function bootstrapBackground() {
    const migration = await migrateStorageIfNeeded();
    if (migration.changed) {
      console.log(
        `[Anchor Tags] Storage migration applied (${migration.fromVersion} -> ${migration.toVersion}).`
      );
    }
    const tabManager = createTabManagerDomain();
    const anchorTags = createAnchorTagsDomain(tabManager);
    tabManager.registerLifecycleListeners();
    anchorTags.registerLifecycleListeners();
    registerCommandRouter({
      addTabManagerEntry: async (tab) => await tabManager.add(tab),
      jumpToSlot: async (slot) => await tabManager.jump(slot)
    });
    registerRuntimeMessageRouter([
      createAnchorTagsMessageHandler(anchorTags),
      createTabManagerMessageHandler(tabManager, anchorTags),
      createSessionMessageHandler(tabManager.state, anchorTags),
      miscMessageHandler
    ]);
    void anchorTags.ensureLoaded();
    void tabManager.ensureLoaded();
    void tabManager.captureInitialActiveTab();
    registerStartupRestore({
      clearTabManager: async () => await tabManager.clearAll()
    });
  }
  void bootstrapBackground().catch((error) => {
    console.error("[Anchor Tags] Background bootstrap failed:", error);
  });
})();
